# 系統架構 + 關鍵函式說明

## 🗂️ 整體架構

單一 HTML 檔案,所有 CSS + JS 內嵌。透過 fetch 載入 5 個 JSON(各家公司商品資料 + 費率表)。

```
保險建議書系統_v3_19.html
├── HTML 頁面結構
│   ├── #personCard (投保人員資料)
│   ├── #productSelect (商品選擇 — 各公司主約/附約清單)
│   ├── #resultCard (建議內容彙整 — 大表格)
│   ├── 走勢圖 + 各年度保費明細表
│   └── #benefitsCard (建議保障內容 — 簡易/詳細模式)
├── CSS (整段內嵌, line ~50-2500)
│   ├── 一般樣式
│   ├── @media (max-width: 767px) 響應式
│   └── @media print 列印專用
└── <script> (整段內嵌, line ~3000+)
    ├── 全域常數: state, db, MAX_AGE 等
    ├── 主要計算函式
    └── 渲染函式
```

---

## 🔑 關鍵全域物件

| 物件 | 內容 |
|------|------|
| `state` | 當前 UI 狀態(被保人/要保人資訊、benefitsMode、選擇的商品) |
| `state.db` | 從 5 個 JSON 合併後的商品資料庫 |
| `state.db.benefitsLib` | 給付項目細項定義(僅全球 10 個商品有完整內嵌定義) |
| `state.selections` | `{ companyId: { main, riders[] } }` 已勾選的商品 |

---

## 📐 主要計算函式

### `evalCalc(calc, amount)` (~5910)
**輸入**:item.calc 物件 + 商品保額  
**輸出**:`{type: 'num', val: 數字}` 或 `{type: 'note', text: 字串}`

支援的 calc.type:
- `ratio`:val = amount × ratio(amount 已是元數)
- `ratioWan`:val = amount × 10000 × ratio(amount 是萬元數)
- `plan`:val = planMap[amount](按計畫別映射)
- `unit`:val = amount × perUnit(計畫單位)
- `note`:純文字說明

### `calcBenefitValue(item, product, amount)` (~6007)
組合 item.calc 與 product 商品資訊,呼叫 evalCalc。

### `convertProductClaims(product)` (~5983)
**功能**:把 product.claims.items(JSON 內定義)轉換成 benefitsLib 格式  
**重點**:處理 `amountUnit` 差異
- `'萬元' / '萬' / '10萬'` → 改用 ratioWan
- `'百元'` → ratio × 100
- `'元'` → 直接 ratio

如果 product.code 在 `state.db.benefitsLib` 沒對應(非全球商品),就會走這條兜底邏輯。

### `classifyItem(item)` (~6049)
**功能**:把單個 item 分類成 cls.key  
**輸出**:`{ key, icon, title }`

cls.key 列表:
- `waiver`:豁免保費
- `burn`:重大燒燙傷
- `dislocation`:脫臼/骨折
- `transplant`:重大器官移植
- `critical`:重大傷病/癌症一次金
- `death`:身故/喪葬
- `disability`:失能
- `daily`:住院日額
- `reimburse`:實支實付/雜費
- `surgery`:住院手術
- `opsurg`:門診手術
- `icu_daily`:加護病房日額
- `maturity`:滿期/祝壽
- `chemo`:化學/放射治療(癌症專用)
- `targeting`:癌症標靶治療
- `reconstruct`:義乳重建手術
- `other`:其他給付

**優先順序很重要**:先判斷 burn/transplant/critical 等特殊類,再判斷 death/disability,最後到 daily/reimburse/surgery。

癌症特殊處理:含「癌症」字眼但**同時含手術/日額/化學/標靶**等的 item,**不歸 critical**,改細分。

### `categorize5(product)` (~6128)
**功能**:把商品歸到 4+1 大類(life/medical/critical/cancer/accident/other)  
**輸出**:`{ mainKey, mainTitle, subTitle }`

**順序很重要**:
1. 豁免類 → other(隱藏)
2. 意外/傷害(name 字眼 + code 白名單)→ accident
3. 壽險/身故 → life
4. 重大傷病 → critical
5. 癌症療程/一次金 → cancer
6. 實支實付/自負額 → medical 實支實付型
7. 定額醫療/住院日額/手術(+ HSV/YHA/H2D code)→ medical 定額型
8. 兜底 → other

---

## 🎨 主要渲染函式

### `renderBenefits(rows)` (~5921)
**入口**:渲染整個「建議保障內容」區塊。
- 簡易模式:呼叫 `renderCardsForMain` 對每個大類渲染 → masonry 堆疊
- 詳細模式:渲染 type-grouped 卡片(每個 cls.key 一張)+ 各公司分組

### `renderSubCard(cls, items, mainKey, subKey, titleOverride)` (~6248)
**功能**:渲染單一給付類型的小卡(住院日額、雜費、意外身故...)

**核心邏輯**:
1. 對每個 row 建立 bucket: `{ limit, deduct, unit }`
2. 同 row 同 cls 的多個 item — limit 取最大、deduct 取最大
3. **淨給付 = limit − deduct**(自負額型扣除)
4. 對所有 row 的淨給付加總(若 unit 同 + `[次日年天]` regex 通過)
5. 拼 tooltip: 各 row 的「限額 − 自負額 = 淨給付」明細

### `renderCardsForMain(mainKey, mainConf)` (~6334)
**功能**:渲染單一大類框 + 內含所有子組

**對 medical 大類特殊處理**:按 row.subTitle 分「實支實付型/定額型」兩個子組,各自配白名單 + 標題覆寫

---

## 🛡️ 保護機制

### `aggregateUnderwriteCheck` (~3781)
**功能**:跨商品累計核保檢查
1. 醫療附約日額累計上限
2. 重大傷病保額累計需體檢
3. **未滿 15 歲身故金額累計**(《保險法》107 條,本期新增)

### `hasBlockingIssue(product, age, jobLevel, period, amount)` (~3991)
單一商品核保檢查 — 是否有 block 等級的違規。如果有,該商品保費計算回傳 0。

### XAB 法令過濾
在 item 分發階段(~6168),如果被保人未滿 16 歲且 product.code === 'XAB' 且 cls.key === 'death',直接跳過該 item(不顯示在卡片上)。

---

## 🎛️ 設定常數

### `ALLOWED_CARDS` (~6175)
各大類及子組的「白名單」cls.key,只顯示這些。

### `TITLE_OVERRIDE` (~6191)
針對特定大類/子組,覆寫 cls 的預設標題(例:在 cancer 大類下,critical 改名「癌症單筆金」)。

### `PRIMARY_CLS` (~6207)
各大類的「主要保障」cls.key,該卡片用品牌橘色強調。

### `MAIN_CATEGORIES` (~6147)
4 個顯示的大類(順序 + icon + color)。`other` 已排除不顯示。

---

## 🔁 資料流

```
[使用者勾選商品]
    ↓
state.selections 更新
    ↓
calculateAll() — 算保費 + 累計檢查
    ↓
renderResultTable() — 渲染建議內容彙整大表
    ↓
renderBenefits() — 渲染建議保障內容
    ↓
    對每個 row,呼叫 classifyItem 分類 items
    ↓
    對每個 item,呼叫 calcBenefitValue 算金額
    ↓
    按 categorize5 把 row 歸大類
    ↓
    按白名單過濾 + 標題覆寫
    ↓
    renderSubCard 算淨給付 + tooltip
    ↓
    masonry column-count: 2 堆疊輸出
```

---

## 🧪 Debug 技巧

需要排查邏輯時,在 `renderSubCard` 內加 console.log 印 buckets 跟 perRowMax(範例見 transcript 後段),從 F12 console 看實際數值,定位問題。
