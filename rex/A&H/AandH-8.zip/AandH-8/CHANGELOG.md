# A&H-8 變更紀錄(從 A&H-7 接續)

## 📅 時間軸

### Phase A:列印 PDF 優化(承接自 A&H-7)
- ✅ 投保人員資料改三欄 grid(被保險人 / 關係方塊 / 要保人)
- ✅ 沒勾選要保人時,被保險人占滿一行,粉紅圓圈隱藏
- ✅ 建議內容彙整 `overflow-x:auto` 包覆容器改 `overflow:visible`,確保完整顯示
- ✅ tfoot「應繳合計」`page-break-inside: avoid`,不被切斷
- ✅ 列印隱藏:複製按鈕、分期係數註解、走勢圖「依公司分/依商品分」
- ✅ summary-bar 半年/季/月繳直向堆疊靠右,字體從 16pt → 9pt
- ✅ #benefitsCard 強制 `page-break-before: always`(從新頁開始)

### Phase B:卡片視覺改造(降躁化)
- ✅ 5 大類左色條從多色 → 統一淡灰品牌色 `#B8C5D1`
- ✅ 大類框背景 `#F7F9FB`,移除虛線分隔
- ✅ 卡片去 1px 邊框,改 `box-shadow: 0 1px 3px rgba(20,40,60,0.04)`
- ✅ icon 透明度降至 0.7
- ✅ 數字字體從 Bebas Neue → Inter/Roboto + tabular-nums
- ✅ 數字色從鮮紅 → 深藍 navy,只「主要保障」用品牌橘
- ✅ 公司標籤從深底白字 → 淡灰底深灰字 + 左側偽元素小色點(`--company-color`)
- ✅ 詳細模式總額條從黑底黃字 → 淡橘底深橘字
- ✅ 詳細模式項目列表行距從 7px → 9px

### Phase C:分類重構(5 大類 → 4+1)
**初版方案(中途版本)**:
- 嘗試合併「重大傷病/癌症」為一大類含 3 子組
- 嘗試合併「壽險+意外失能」為「人身/失能保障」用子組區分

**最終方案**:
- ✅ 拆回「重大傷病」+「癌症險」為獨立大類
- ✅ 「人身/失能保障」只保留壽險身故/失能
- ✅ XAB(意外險)整張歸入「意外醫療」大類,意外身故/失能排第一格
- ✅ 「住院醫療」內細分子組:實支實付型 / 定額型
- ✅ 移除「其他保障」大類

### Phase D:Masonry 堆疊版面
- ✅ `.benefits-section` 從 `grid 2 欄等高` → `column-count: 2; column-gap: 14px`
- ✅ `.benefits-main-cat` 加 `break-inside: avoid; page-break-inside: avoid`
- ✅ 卡片 grid `minmax(170px → 140px)` 提高密度
- ✅ 卡片內距從 `16px 14px` → `12px 10px`
- ✅ 數字 22px → 19px、icon 26px → 22px

### Phase E:資料層修正(從 PDF 對照建議書)
- ✅ XHO benefitsLib 從 6 項 → 12 項(限額/自負額配對 + 義齒義肢/住院照護)
- ✅ XCF benefitsLib 從 3 項 → 5 項(首年/續年金額分開)
- ✅ NIR 住院日額合併住院雜費補助(計4 = 6000 元/天)
- ✅ NIR 外科手術定額直接寫 90000(條款 3 倍)
- ✅ XHD item names 改觸發正確 classifyItem cls(住院日額/住院實支)
- ✅ XHO item names 同步改名

### Phase F:核心計算邏輯修正
- ✅ `renderSubCard` 重寫 perRowMax:用 `rowItemBuckets` 分 limit/deduct,計算淨給付
- ✅ 自負額判斷:item.note 含「被保人自行負擔」 → 視為 deduct
- ✅ tooltip 加上組成明細(滑入卡片時顯示「XHD: 1,000 | XHO: 4,000 − 自負 1,000 = 3,000 = 4,000元/天」)
- ✅ `[次日年]` regex bug 修正 → `[次日年天]`(原本「元/天」永遠匹配失敗)
- ✅ classifyItem 對「癌症」項目細分(癌症日額/手術不再被吃進 critical)

### Phase G:法規檢查
- ✅ XAB 未滿 16 歲意外身故給付 0(從顯示中過濾)
- ✅ aggregateUnderwriteCheck 新增第 3 類:**未滿 15 歲身故金額累計**
  - 超過 690,000 → block 紅色警告
  - 超過 552,000 (80%) → warn 黃色警告
  - 例外:XAB 排除(條款已說明 16 歲前不給付)

### Phase H:多公司商品支援
- ✅ categorize5 加入意外/傷害 code 白名單(5DD/R1D/L6D/MRE/XHQ/RHG/TMR/ADG)
- ✅ 醫療類加入 code 白名單(HSV/YHA/H2D)
- ✅ 豁免類(94A/95A/WRA/WRB)歸 'other' 不顯示在簡易卡
- ✅ `convertProductClaims` 加 amountUnit 多單位支援:
  - `'萬元'/'萬'/'10萬'` → ratioWan(視同萬元)
  - `'百元'` → ratio × 100
  - `'元'` → 直接 ratio
  - 其他(`'單位'/'計劃'/'計畫'`) → 由 plan 計算

### Phase I:走勢圖
- ✅ 預設範圍從 30 年改 20 年
- ✅ 加按鈕「20/30/60 年」三選一
- ✅ 各年度保費明細表自動連動

---

## 🐛 過程中找到的關鍵 bug

1. **regex `[次日年]` 漏「天」**(影響所有「元/天」單位的累計加總)
   - 雜費(元/次)正確累加 — 因為「次」在字符類內
   - 住院日額(元/天)永遠 fallback 到 max 而非 sum
   - 解法:改成 `[次日年天]`,影響 3 處

2. **classifyItem「癌症」優先級過高**
   - 含「癌症」字眼一律歸 critical → 癌症日額/手術都被併入單一卡
   - 解法:癌症項目走子規則細分,critical 只給「純癌症一次金」

3. **convertProductClaims 不認識 `'10萬'` `'百元'`**
   - 這兩個 unit 都被當「元」處理,造成 ratio × amount 直接得到極小數字
   - SKL M4D 100 萬 重大傷病 變成 100 元
   - 解法:擴充 unit 對照表

4. **categorize5 規則順序**
   - 原本「壽險」優先於「意外」,FUBON ADG 意外險 category 寫「終身壽險」 → 被歸 life
   - 解法:先檢查意外/傷害字眼 + code 白名單,再判斷其他類別

5. **XAB 未滿 16 歲法令**
   - 條款明訂 16 歲前不給付意外身故,但系統照算 200 萬
   - 解法:在 item 分發階段過濾,不顯示卡片

6. **XHO「每日病房費」name 不命中 daily 規則**
   - classifyItem 的 daily 規則需含「保險金」或「住院.*日額」
   - 「每日病房費」沒含這兩者 → 跑到 reimburse 規則 → 進錯卡
   - 解法:item name 改為「住院日額(限額)」「住院日額(自負額)」

---

## 📋 從 A&H-7 帶過來的歷史

A&H-7 transcript 摘要:
- 保險建議書系統 HTML 客製化任務
- 從原本 XWA 豁免保費精算整合 → 移除 XWA 功能
- 清理 JSON 檔(transglobe 從 548KB → 145KB,XW費率 從 548KB → 263KB)
- 修改建議保障內容版面為 5 大類分組
- 列印 PDF 樣式優化
- UI 視覺重構(初版)
- 4 大類版面合併與 Masonry 堆疊(部分完成,A&H-8 完成剩下)

完整 transcript:`/mnt/transcripts/2026-05-08-09-03-59-insurance-html-customization.txt`
