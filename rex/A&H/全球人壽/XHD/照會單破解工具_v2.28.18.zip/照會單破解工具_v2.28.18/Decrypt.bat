@echo off
chcp 65001 >nul 2>&1
title Insurance File Decryptor
cd /d "%~dp0"
setlocal enabledelayedexpansion

set "PYCMD="

where python >nul 2>&1
if not errorlevel 1 (
    set "PYCMD=python"
    goto found
)

where py >nul 2>&1
if not errorlevel 1 (
    set "PYCMD=py"
    goto found
)

for %%v in (3.14 3.13 3.12 3.11 3.10) do (
    if exist "%LOCALAPPDATA%\Python\pythoncore-%%v-64\python.exe" (
        set "PYCMD=%LOCALAPPDATA%\Python\pythoncore-%%v-64\python.exe"
        goto found
    )
)

for /d %%d in ("%LOCALAPPDATA%\Microsoft\WindowsApps\PythonSoftwareFoundation.Python.*") do (
    if exist "%%d\python.exe" (
        set "PYCMD=%%d\python.exe"
        goto found
    )
)

cls
echo.
echo ============================================================
echo   X  Python not found!
echo ============================================================
echo.
echo  Please install Python:
echo  1. Download from https://www.python.org/downloads/
echo  2. CHECK "Add python.exe to PATH" during install
echo  3. Run this .bat again
echo.
echo ============================================================
pause
exit /b 1

:found
echo [ Using Python: %PYCMD% ]
echo.

"%PYCMD%" -c "import pikepdf, msoffcrypto, pyzipper" >nul 2>&1
if errorlevel 1 (
    echo [ First run: installing packages, takes 1-2 minutes ... ]
    echo.
    "%PYCMD%" -m pip install --upgrade pip
    "%PYCMD%" -m pip install pikepdf msoffcrypto-tool pyzipper
    if errorlevel 1 (
        echo.
        echo X  Package install failed.
        pause
        exit /b 1
    )
    echo.
    echo [ OK Packages installed ]
    echo.
)

"%PYCMD%" "%~dp0decrypt.py" %*

if errorlevel 1 (
    echo.
    pause
)
