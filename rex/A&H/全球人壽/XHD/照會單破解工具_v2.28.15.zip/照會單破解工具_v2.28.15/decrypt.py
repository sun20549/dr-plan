# -*- coding: utf-8 -*-
"""
照會單自動破解工具 v2.0
================================
作者：為李育松（鼎綸保經/恩宇營運區）量身打造

功能：
  ✓ 自動解壓有密碼的 ZIP 檔
  ✓ 自動破解 PDF / Excel 密碼
  ✓ 智慧辨識保險公司（從 zip 名稱或內部檔名）
  ✓ 自動計算動態密碼（含日期變數）
  ✓ 失敗時可手動輸入密碼
  ✓ 批次處理整個資料夾

使用方式：
  方式一：雙擊執行 → 進入互動模式
  方式二：拖曳檔案/資料夾到 .bat 圖示 → 自動處理
  方式三：命令列  python 照會單破解.py <檔案或資料夾>

需要套件：pikepdf, msoffcrypto-tool, pyzipper
安裝指令：pip install pikepdf msoffcrypto-tool pyzipper
"""

import os
import sys
import re
import json
import shutil
import zipfile
import tempfile
import subprocess
from pathlib import Path
from datetime import datetime, timedelta
from typing import List, Optional, Tuple

# ============ 載入相依套件 ============
MISSING_PACKAGES = []
try:
    import pikepdf
except ImportError:
    MISSING_PACKAGES.append("pikepdf")

try:
    import msoffcrypto
except ImportError:
    MISSING_PACKAGES.append("msoffcrypto-tool")

try:
    import pyzipper
except ImportError:
    MISSING_PACKAGES.append("pyzipper")

# pdfplumber 為選用套件（用於讀 PDF 內容自動命名）
PDFPLUMBER_AVAILABLE = False
try:
    import pdfplumber
    PDFPLUMBER_AVAILABLE = True
except ImportError:
    pass

# rarfile 為選用套件（處理 .rar 檔，需要 unrar.exe 或 7-Zip）
RARFILE_AVAILABLE = False
try:
    import rarfile
    RARFILE_AVAILABLE = True
except ImportError:
    pass

# py7zr 為選用套件（處理 .7z 檔，純 Python 不需外部工具）
PY7ZR_AVAILABLE = False
try:
    import py7zr
    PY7ZR_AVAILABLE = True
except ImportError:
    pass

# openpyxl + reportlab 為選用套件（用於 Excel 轉 PDF）
EXCEL_TO_PDF_AVAILABLE = False
try:
    import openpyxl
    from reportlab.lib.pagesizes import A4, landscape
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
    from reportlab.lib import colors as rl_colors
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.cidfonts import UnicodeCIDFont
    pdfmetrics.registerFont(UnicodeCIDFont('STSong-Light'))
    EXCEL_TO_PDF_AVAILABLE = True
except ImportError:
    pass

# xlrd 為選用套件（用於讀 .xls 老格式 Excel）
XLRD_AVAILABLE = False
try:
    import xlrd
    XLRD_AVAILABLE = True
except ImportError:
    pass

if MISSING_PACKAGES:
    print("❌ 缺少必要套件，請執行以下指令安裝：")
    print(f"   pip install {' '.join(MISSING_PACKAGES)}")
    input("\n按 Enter 結束...")
    sys.exit(1)


# ============ 路徑設定 ============
def get_base_dir() -> Path:
    if getattr(sys, 'frozen', False):
        return Path(sys.executable).parent
    return Path(__file__).parent


BASE_DIR = get_base_dir()
# 優先用英文檔名，找不到再用中文
_eng_config = BASE_DIR / "passwords.json"
_chi_config = BASE_DIR / "密碼規則.json"
CONFIG_FILE = _eng_config if _eng_config.exists() else _chi_config
LOG_FILE = BASE_DIR / "decrypt.log"
HISTORY_FILE = BASE_DIR / "history.json"  # 處理過的檔案指紋紀錄


# === 自動偵測 RAR 解壓工具 ===
# 支援多種後端：WinRAR / 7-Zip / Bandizip
# 順序：rarfile 原生（unrar） > 7-Zip > Bandizip
RAR_TOOL_PATH: Optional[str] = None
RAR_TOOL_TYPE: Optional[str] = None  # "unrar" / "7zip" / "bandizip"

if RARFILE_AVAILABLE:
    # unrar 系列（rarfile 套件原生支援）
    _unrar_tools = [
        str(BASE_DIR / 'UnRAR.exe'),
        r'C:\Program Files\WinRAR\UnRAR.exe',
        r'C:\Program Files (x86)\WinRAR\UnRAR.exe',
        r'C:\Program Files\WinRAR\Rar.exe',
    ]
    # 7-Zip 系列
    _7zip_tools = [
        r'C:\Program Files\7-Zip\7z.exe',
        r'C:\Program Files (x86)\7-Zip\7z.exe',
    ]
    # Bandizip 命令列工具
    _bandizip_tools = [
        r'C:\Program Files\Bandizip\bz.exe',
        r'C:\Program Files (x86)\Bandizip\bz.exe',
        r'C:\Program Files\Bandizip\Bandizip.exe',
        r'C:\Program Files (x86)\Bandizip\Bandizip.exe',
    ]
    import shutil as _sh

    # 優先試 unrar（rarfile 原生支援）
    for _tool in _unrar_tools:
        if os.path.exists(_tool):
            RAR_TOOL_PATH = _tool
            RAR_TOOL_TYPE = "unrar"
            rarfile.UNRAR_TOOL = _tool
            break
    # PATH 中的 unrar
    if not RAR_TOOL_PATH:
        _path_unrar = _sh.which('unrar') or _sh.which('UnRAR.exe')
        if _path_unrar:
            RAR_TOOL_PATH = _path_unrar
            RAR_TOOL_TYPE = "unrar"
            rarfile.UNRAR_TOOL = _path_unrar

    # 沒 unrar 就試 7-Zip
    if not RAR_TOOL_PATH:
        for _tool in _7zip_tools:
            if os.path.exists(_tool):
                RAR_TOOL_PATH = _tool
                RAR_TOOL_TYPE = "7zip"
                break

    # 沒 7-Zip 就試 Bandizip
    if not RAR_TOOL_PATH:
        for _tool in _bandizip_tools:
            if os.path.exists(_tool):
                RAR_TOOL_PATH = _tool
                RAR_TOOL_TYPE = "bandizip"
                break

    if not RAR_TOOL_PATH:
        RARFILE_AVAILABLE = False


def load_rules() -> dict:
    if not CONFIG_FILE.exists():
        print(f"❌ 找不到密碼規則檔：{CONFIG_FILE}")
        print("   請確認『密碼規則.json』和本程式在同一資料夾。")
        input("按 Enter 結束...")
        sys.exit(1)
    with open(CONFIG_FILE, 'r', encoding='utf-8') as f:
        return json.load(f)


def write_log(message: str):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    try:
        with open(LOG_FILE, 'a', encoding='utf-8') as f:
            f.write(f"[{timestamp}] {message}\n")
    except Exception:
        pass


# ============ 歷史紀錄（防止重複處理）============
import hashlib

# 保留 30 天的歷史紀錄
HISTORY_RETENTION_DAYS = 30


def load_history() -> dict:
    """載入歷史紀錄。格式：{保單號碼: [{content_hash, filename, date}, ...]}"""
    if not HISTORY_FILE.exists():
        return {}
    try:
        with open(HISTORY_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
        # 清理超過 30 天的舊紀錄
        cutoff = datetime.now() - timedelta(days=HISTORY_RETENTION_DAYS)
        cleaned = {}
        for policy, records in data.items():
            kept = []
            for r in records:
                try:
                    dt = datetime.fromisoformat(r.get("date", ""))
                    if dt >= cutoff:
                        kept.append(r)
                except Exception:
                    kept.append(r)  # 保留無法解析日期的紀錄
            if kept:
                cleaned[policy] = kept
        return cleaned
    except Exception:
        return {}


def save_history(history: dict):
    """儲存歷史紀錄"""
    try:
        with open(HISTORY_FILE, 'w', encoding='utf-8') as f:
            json.dump(history, f, ensure_ascii=False, indent=2)
    except Exception as e:
        write_log(f"儲存歷史紀錄失敗: {e}")


def compute_content_hash(file_path: Path) -> Optional[str]:
    """計算 PDF 內容的指紋（MD5）。用 PDF 文字內容算，避免格式差異影響"""
    if not PDFPLUMBER_AVAILABLE:
        # 沒 pdfplumber 就用檔案二進位算
        try:
            with open(file_path, 'rb') as f:
                return hashlib.md5(f.read()).hexdigest()
        except Exception:
            return None
    try:
        # 用 PDF 文字內容算指紋（比較不會受 metadata 影響）
        text_parts = []
        with pdfplumber.open(str(file_path)) as pdf:
            for page in pdf.pages:
                t = page.extract_text() or ""
                text_parts.append(t)
        text = "\n".join(text_parts)
        if not text.strip():
            # 文字抓不到就用檔案二進位
            with open(file_path, 'rb') as f:
                return hashlib.md5(f.read()).hexdigest()
        return hashlib.md5(text.encode('utf-8')).hexdigest()
    except Exception as e:
        write_log(f"計算指紋失敗 {file_path.name}: {e}")
        return None


def check_duplicate(history: dict, policy: Optional[str],
                    content_hash: Optional[str]) -> Tuple[str, Optional[dict]]:
    """檢查是否重複。
    
    回傳 (狀態, 重複紀錄)：
    - "new"          → 全新檔案
    - "duplicate"    → 完全重複（保單+內容都一樣）
    - "updated"      → 同保單但內容不同（保險公司可能更新）
    """
    if not policy or not content_hash:
        return ("new", None)

    records = history.get(policy, [])
    for r in records:
        if r.get("content_hash") == content_hash:
            return ("duplicate", r)

    if records:
        # 同保單但內容不同 → 視為更新版
        return ("updated", records[0])

    return ("new", None)


def add_history(history: dict, policy: str, content_hash: str, filename: str):
    """加入歷史紀錄"""
    if not policy or not content_hash:
        return
    if policy not in history:
        history[policy] = []
    history[policy].append({
        "content_hash": content_hash,
        "filename": filename,
        "date": datetime.now().isoformat()
    })


# 模組級的歷史紀錄變數（main 載入後設定）
_DEDUP_HISTORY: Optional[dict] = None


# ============ 日期處理 ============
def extract_date_from_text(text: str) -> Optional[datetime]:
    """從文字（檔名）抓日期。優先順序：YYYYMMDD → YYYY-MM-DD → YYYYMM"""
    patterns = [
        (r'(20\d{2})[-_]?(0[1-9]|1[0-2])[-_]?(0[1-9]|[12]\d|3[01])', 'ymd'),
        (r'(20\d{2})[-_]?(0[1-9]|1[0-2])(?!\d)', 'ym'),
    ]
    for pattern, fmt in patterns:
        match = re.search(pattern, text)
        if match:
            try:
                if fmt == 'ymd':
                    return datetime(int(match.group(1)), int(match.group(2)), int(match.group(3)))
                else:
                    return datetime(int(match.group(1)), int(match.group(2)), 1)
            except ValueError:
                continue
    # v2.28：民國格式 YYYMMDD（如 1140526），通常出現在檔名開頭
    # 用 anchored 模式：「字首或非數字後」緊接 1\d{2}[01]\d[0-3]\d
    m = re.search(r'(?:^|[^\d])(1\d{2})(0[1-9]|1[0-2])(0[1-9]|[12]\d|3[01])(?:[^\d]|$)', text)
    if m:
        try:
            roc_y = int(m.group(1))
            mo = int(m.group(2))
            d = int(m.group(3))
            return datetime(roc_y + 1911, mo, d)
        except ValueError:
            pass
    return None


def get_date_candidates(filename: str, date_source: str) -> List[datetime]:
    """取得要嘗試的日期清單"""
    file_date = extract_date_from_text(filename)
    today = datetime.now()
    candidates = []

    if date_source == "none":
        candidates = [today]
    elif date_source == "filename":
        if file_date:
            candidates = [file_date]
    elif date_source == "today":
        candidates = [today]
    elif date_source == "filename_plus_one":
        # 全球規則：密碼是「Email 收到日期」，通常是檔名 +1 天
        # （唯一例外：全球確實會 +1 天，因為密碼是 Email 收件日，比寄出日晚一天）
        if file_date:
            # 1. 最常見：檔名 +1 天（Email 收件日）
            candidates.append(file_date + timedelta(days=1))
            # 2. 檔名當天
            candidates.append(file_date)
            # 3. 往前推幾天（萬一 Email 延遲）
            for delta in range(1, 5):
                candidates.append(file_date - timedelta(days=delta))
            # 4. 今天日期當備援
            if file_date.date() != today.date():
                candidates.append(today)
        else:
            candidates.append(today)
    elif date_source == "filename_nearby":
        # 凱基類規則：密碼日期 ≤ 寄出日期（不會比寄出日還晚）
        # 嘗試順序：檔名當天 → 往前 1-7 天
        if file_date:
            # 1. 檔名當天（最常見）
            candidates.append(file_date)
            # 2. 往前推 7 天（涵蓋跨週末、隔週才處理等狀況）
            for delta in range(1, 8):
                candidates.append(file_date - timedelta(days=delta))
            # 3. 今天日期當備援
            if file_date.date() != today.date():
                candidates.append(today)
        else:
            candidates.append(today)
    elif date_source == "any":
        # 通用規則：以收到當月/當日為準，不行就往前推
        # 不嘗試未來日期（保險公司不會用未來日期當密碼）
        if file_date:
            candidates.append(file_date)
            # 往前推 7 天
            for delta in range(1, 8):
                candidates.append(file_date - timedelta(days=delta))
        candidates.append(today)
        # 往前推 1-2 個月（適用月為單位的密碼）
        for delta_m in [-1, -2]:
            new_month = today.month + delta_m
            new_year = today.year
            while new_month < 1:
                new_month += 12
                new_year -= 1
            candidates.append(datetime(new_year, new_month, 1))

    # 去重保序
    seen = set()
    result = []
    for d in candidates:
        key = d.strftime("%Y-%m-%d")
        if key not in seen:
            seen.add(key)
            result.append(d)
    return result


def fill_password_template(template: str, date: datetime) -> str:
    """套用密碼樣板"""
    roc_year = date.year - 1911
    replacements = {
        '{YYYY}': str(date.year),
        '{YY}': str(date.year)[-2:],
        '{MM}': f"{date.month:02d}",
        '{DD}': f"{date.day:02d}",
        '{YYYYMM}': f"{date.year}{date.month:02d}",
        '{YYYYMMDD}': f"{date.year}{date.month:02d}{date.day:02d}",
        '{ROC_YYYMM}': f"{roc_year:03d}{date.month:02d}",
    }
    result = template
    for key, value in replacements.items():
        result = result.replace(key, value)
    return result


# ============ 公司辨識 ============
def identify_company(text: str, rules: dict) -> List[dict]:
    """從文字（檔名）辨識可能的保險公司。
    
    支援辨識優先級（priority），優先級高的會先嘗試。
    若 zip 外層 + 內部檔名同時匹配多家，優先級決定先試哪家。
    """
    matched = []
    text_lower = text.lower()
    for company in rules["公司清單"]:
        # 略過停用條目
        if company.get("公司", "").startswith("_停用_"):
            continue
        # 略過空關鍵字
        keywords = company.get("關鍵字", [])
        if not keywords:
            continue
        for keyword in keywords:
            if keyword in text or keyword.lower() in text_lower:
                if company not in matched:
                    matched.append(company)
                break

    # 依「辨識優先級」排序（高→低），沒設定的視為 0
    matched.sort(key=lambda c: c.get("辨識優先級", 0), reverse=True)
    return matched


def build_password_candidates(filename: str, file_type: str, rules: dict,
                              identified_companies: Optional[List[dict]] = None
                              ) -> List[Tuple[str, str]]:
    """產生 (公司名, 密碼) 候選清單"""
    if identified_companies is None:
        companies = identify_company(filename, rules)
    else:
        companies = identified_companies

    if not companies:
        # 沒辨識出 → 試所有公司（但排除停用條目）
        companies = [c for c in rules["公司清單"]
                     if not c.get("公司", "").startswith("_停用_")
                     and c.get("關鍵字")]

    candidates = []
    seen = set()
    key_field = f"{file_type}密碼"

    for company in companies:
        passwords = company.get(key_field, [])
        # zip 密碼若沒設定就用 PDF/EXCEL 密碼
        if file_type == "zip":
            passwords = company.get("zip密碼", company.get("PDF密碼", []))

        date_source = company.get("日期來源", "none")
        dates = get_date_candidates(filename, date_source)

        for pwd_template in passwords:
            if '{' in pwd_template:
                for d in dates:
                    pwd = fill_password_template(pwd_template, d)
                    key = (company["公司"], pwd)
                    if key not in seen:
                        seen.add(key)
                        candidates.append(key)
            else:
                key = (company["公司"], pwd_template)
                if key not in seen:
                    seen.add(key)
                    candidates.append(key)
    return candidates


# ============ PDF 處理 ============
def is_pdf_encrypted(file_path: Path) -> bool:
    try:
        with pikepdf.open(str(file_path)) as _:
            return False
    except pikepdf.PasswordError:
        return True
    except Exception:
        return False


def crack_pdf(input_path: Path, output_path: Path, password: str) -> bool:
    try:
        with pikepdf.open(str(input_path), password=password) as pdf:
            pdf.save(str(output_path))
        return True
    except pikepdf.PasswordError:
        return False
    except Exception as e:
        write_log(f"PDF 破解錯誤 {input_path.name}: {e}")
        return False


# ============ 從 PDF/Excel 內容抓出被保險人姓名、文件種類（用於智慧命名）============
def extract_text_from_pdf(pdf_path: Path, max_pages: int = 2) -> str:
    """從 PDF 抓前幾頁的文字。需要 pdfplumber，若未安裝回傳空字串"""
    if not PDFPLUMBER_AVAILABLE:
        return ""
    try:
        text_parts = []
        with pdfplumber.open(str(pdf_path)) as pdf:
            for page in pdf.pages[:max_pages]:
                t = page.extract_text() or ""
                text_parts.append(t)
        return "\n".join(text_parts)
    except Exception as e:
        write_log(f"讀 PDF 內容失敗 {pdf_path.name}: {e}")
        return ""


def parse_insured_name(text: str) -> Optional[str]:
    """從 PDF 文字中抓出「被保險人」姓名（純中文 2-4 字）"""
    if not text:
        return None

    # 保留原始文字，先用「未清空格」版本嘗試清冊解析（清冊資料行依賴空格分隔）
    text_raw = text

    # v2.28：先清掉私有區 PUA 字符（PDF 沒解碼好的怪字，如 \ue020），避免擋住人名
    text = re.sub(r'[\ue000-\uf8ff]', '', text)
    text_raw = re.sub(r'[\ue000-\uf8ff]', '', text_raw)

    # 先把中文字之間的單個空格清掉（用於 標籤式 規則）
    text_clean = re.sub(r'(?<=[\u4e00-\u9fff\uf900-\ufaff])\s+(?=[\u4e00-\u9fff\uf900-\ufaff])', '', text)

    # 過濾接續詞，避免抓到「趙崇聿在同業」這種
    # v2.28：補上「最後期限」「照會狀態」「照會編號」「之理賠」「先生」等更多 stop word
    # v2.28.9：姓名字元類別擴展（含中文 + 屏蔽符 * ○ Ｏ ＊）
    N = r'[一-鿿豈-﫿*○Ｏ＊]'

    # v2.28.12：高優先級標籤式抓取（最常見格式，最先試）
    # 「被保險人 : 吳芊儀 送件人員」/「被保險人：郭儀珊」等
    _top_priority = re.search(
        r'被保險人\s*[:：]\s*([一-鿿豈-﫿*○Ｏ＊]{2,4}?)(?=(?:送件|信函|要保|請於|敬請|服務|投保|險種|主約|附約|公司|招攬|經辦|完成|簽收|印章|代理|傳真|預計|分機|事故|受款|受益|理賠|匯款|帳號|銀行|通路|新光|台新|台灣|富邦|凱基|宏泰|安聯|友邦|保誠|法巴|安達|第一金|元大|全球|產物|人壽|分公司|核保|核賠|管理|第一次|頻請|煩請|該|本次|本件|本通知|至|為配合|為利|請查照|請以|依規定|依據|因|如|您|您所|請填寫|住院|身故|相關|新契約|體檢|簽章|聯絡|核保部|核賠部|台中|台北|台南|高雄|電子郵件)|\s|$|[A-Z]|\d|，|。|；|（)',
        text_clean
    )
    if _top_priority:
        _n = _top_priority.group(1).strip()
        if 2 <= len(_n) <= 4 and re.search(r'[一-鿿豈-﫿]', _n):
            if _n not in ('鼎綸恩宇', '恩宇', '鼎綸'):
                return _n
    # 全球理賠照會單「被保險人 X 之理賠案件」
    _top2 = re.search(
        r'被保險人\s+([一-鿿豈-﫿*○Ｏ＊]{2,4})\s+之理賠',
        text_clean
    )
    if _top2:
        _n = _top2.group(1).strip()
        if 2 <= len(_n) <= 4 and re.search(r'[一-鿿豈-﫿]', _n):
            return _n

    suffix_stop = r'(?:\s|$|回覆|保單|照會|身分|出生|本件|要保|金額|商品|主約|在|於|出險|住院|被保|ID|本保|業務|招攬|事故|聯絡|地址|電話|職業|核保|經辦|匯款|帳號|最後|主約|受理|商品|先生|小姐|之|的|先|身故|服務|投保|險種|中文|契變|契約|主約|附約|電子|紙本|招攬人|完成|簽收|印章|代理|傳真|預計|分機|請於|敬請)'
    patterns = [
        # v2.28：全球理賠通知書「提出被保險人 蕭博楷 之理賠申請」（text_clean 已清空格）
        r'提出被保險人\s*([\u4e00-\u9fff\uf900-\ufaff*\u25cb\uff2f\uff0a]{2,4})\s*之',
        # v2.28.12：全球理賠照會單「您所申請保單 IN007720 被保險人 許誼璇 之理賠案件」
        r'被保險人\s*([一-鿿豈-﫿*○Ｏ＊]{2,4})\s*之理賠',
        # v2.28：全球理賠通知書「受款人 蕭博楷 的理賠金」（fallback）
        r'受款人\s*([\u4e00-\u9fff\uf900-\ufaff*\u25cb\uff2f\uff0a]{2,4})\s*的理賠',
        r'主被保[險]?[人]?\s*[:：]\s*([\u4e00-\u9fff\uf900-\ufaff*\u25cb\uff2f\uff0a]{2,4})' + suffix_stop,
        r'被\s*保\s*險\s*人\s*[:：]\s*([\u4e00-\u9fff\uf900-\ufaff*\u25cb\uff2f\uff0a]{2,4})' + suffix_stop,
        r'被保[險]?[人]?\s*[:：]\s*([\u4e00-\u9fff\uf900-\ufaff*\u25cb\uff2f\uff0a]{2,4})' + suffix_stop,
        # 安聯：「被保人姓名: 林琬縈\n服務通路」或「被保人姓名: 林琬縈服務通路」（沒空白）
        r'被保人姓名\s*[:：]\s*([\u4e00-\u9fff\uf900-\ufaff*\u25cb\uff2f\uff0a]{2,4})(?=\s*\n|\s+|服務|保單|要保|$|[A-Z]|\d)',
        # 富邦格式：「被保險人」獨立一行，名字接著另一行
        r'被保險人\s*\n\s*([\u4e00-\u9fff\uf900-\ufaff*\u25cb\uff2f\uff0a]{2,4})\s+被保險人\s+ID',
        # 富邦另一格式：「要保險人姓名 陳家豪」
        r'要保險人姓名\s+([\u4e00-\u9fff\uf900-\ufaff*\u25cb\uff2f\uff0a]{2,4})\b',
        # 宏泰表格格式（全形管道符）：「│被保險人 │高巧芯 │」
        r'被保險人\s*│\s*([\u4e00-\u9fff\uf900-\ufaff*\u25cb\uff2f\uff0a]{2,4})',
        # 宏泰表格格式（一般）：「被保險人 高巧芯」
        r'被保險人\s+([\u4e00-\u9fff\uf900-\ufaff*\u25cb\uff2f\uff0a]{2,4})(?:\s+|$|被保險|要保險|招攬|核保|經辦)',
        r'被保人姓名\s+([\u4e00-\u9fff\uf900-\ufaff*\u25cb\uff2f\uff0a]{2,4})(?:\s+|$|被保|要保|招攬|核保)',
        r'被保人\s+([\u4e00-\u9fff\uf900-\ufaff*\u25cb\uff2f\uff0a]{2,4})(?:\s+|$|被保|要保|招攬|核保|保戶|簽收)',
        # 台壽理賠：「事故人 : 林欣慧 事故日期」
        r'事故人\s*[:：]\s*([\u4e00-\u9fff\uf900-\ufaff*\u25cb\uff2f\uff0a]{2,4})(?=\s+事故|\s+受益|\s+受款|\s*\n|\s*$)',
        # 富邦理賠：「事故人:陳宥叡 事故人ID」（沒空格）
        r'事故人\s*[:：]\s*([\u4e00-\u9fff\uf900-\ufaff*\u25cb\uff2f\uff0a]{2,4})(?=事故|受益|受款|案件|理賠|\s|\d|[A-Z])',
        # v2.28：強制險「被 保 險 人\n廖伶凡\n(車主)」格式（text_clean 已清，所以靠『車主』錨點）
        r'被保險人\s*([\u4e00-\u9fff\uf900-\ufaff*\u25cb\uff2f\uff0a]{2,4})\s*\(?\s*車主',
        # v2.28：強制險的另一格式：「保險證號碼:XXX」前後抓被保險人
        r'被保險人\s*([\u4e00-\u9fff\uf900-\ufaff*\u25cb\uff2f\uff0a]{2,4})\s*\(?車主',
        # v2.28：富邦 RRN43F8 連續寄發失敗：「1 H224123091 王稔嘉 1076696285-00 王稔嘉 ...」
        #         索引 1 (序號) + 2 (要保人ID) + 3 (要保人) + 4 (保單號) + 5 (被保人)
        r'\b\d+\s+[A-Z]\d{8,12}\s+[\u4e00-\u9fff\uf900-\ufaff*\u25cb\uff2f\uff0a]{2,4}\s+\d{10,12}-\d{2}\s+([\u4e00-\u9fff\uf900-\ufaff*\u25cb\uff2f\uff0a]{2,4})\s',
        # v2.28.9 #11\uff1a\u5b89\u806f / \u5168\u7403\u9ad4\u6aa2\u300c\u88ab\u4fdd\u96aa\u4eba\u59d3\u540d:\u8521\u63da\u771f\u300d\uff085\u5b57\u6a19\u7c64\uff09
        r'\u88ab\u4fdd\u96aa\u4eba\u59d3\u540d\s*[:\uff1a]\s*([\u4e00-\u9fff\uf900-\ufaff*\u25cb\uff2f\uff0a]{2,4})(?=\s|$|[A-Z]|\d|\u6295\u4fdd|\u4e2d\u6587|\u96aa\u7a2e|\u670d\u52d9|\u4fdd\u55ae)',
    ]
    # v2.28：富邦電訪清單表格行 — 從 text_raw（含字間空格）抓
    # 原文格式：「1078914578-00 蕭 資 芮 林 珮 筠 林 珮 筠 OLA5」
    # 主 pattern：要保人 = 法代/代表人（常見），用 backreference 鎖定姓名邊界
    m_fb = re.search(
        r'\b\d{10,12}-\d{2}\s+'
        r'((?:[\u4e00-\u9fff\uf900-\ufaff]\s+){2,4})'  # 1: 被保人
        r'((?:[\u4e00-\u9fff\uf900-\ufaff]\s+){2,4})'  # 2: 要保人
        r'\2'                                              # 3: 法代 = 要保人
        r'[A-Z]{2,8}',
        text_raw
    )
    if m_fb:
        nm = re.sub(r'\s', '', m_fb.group(1)).strip()
        if 2 <= len(nm) <= 4 and nm not in ('鼎綸恩宇', '恩宇'):
            return nm
    # Fallback：3 個姓名各自獨立（要保人/法代不同）
    m_fb2 = re.search(
        r'\b\d{10,12}-\d{2}\s+'
        r'((?:[\u4e00-\u9fff\uf900-\ufaff]\s+){2,4}?)'  # 1: 非貪婪
        r'(?:[\u4e00-\u9fff\uf900-\ufaff]\s+){2,4}'
        r'(?:[\u4e00-\u9fff\uf900-\ufaff]\s+){2,4}'
        r'[A-Z]{2,8}',
        text_raw
    )
    if m_fb2:
        nm = re.sub(r'\s', '', m_fb2.group(1)).strip()
        if 2 <= len(nm) <= 4 and nm not in ('鼎綸恩宇', '恩宇'):
            return nm

    # v2.28.9 #3：富邦 2 名表格 backref（被保人=要保人，後接險種代號 + 日期）
    # 例：「1080767362-00 陳家豪 陳家豪 LTK1 2026/01/12」
    # 「1081229130-00 陳秀錦 陳秀錦 PAF 2026/02/06」
    m_fb3 = re.search(
        r'\b\d{10,12}-\d{2}\s+'
        r'((?:[一-鿿豈-﫿*○Ｏ＊]\s*){2,4})'  # 1: 被保人
        r'\1'                                                              # 2: 要保人 = 被保人
        r'\s*[A-Z]{2,8}',
        text_raw
    )
    if m_fb3:
        nm = re.sub(r'\s', '', m_fb3.group(1)).strip()
        if 2 <= len(nm) <= 4 and nm not in ('鼎綸恩宇', '恩宇'):
            return nm

    # v2.28.9 #5：富邦續期未繳費（3 名 + 後接日期 非險種代號）
    # 「1076696285-00 主約 王稔嘉 王稔嘉 王稔嘉 11/1/24 ...」
    m_fb4 = re.search(
        r'\b\d{10,12}-\d{2}\s+(?:主約|附約)\s+'
        r'((?:[一-鿿豈-﫿*○Ｏ＊]\s*){2,4})'  # 1: 要保人
        r'\1'                                                              # 2: 被保人 = 要保人
        r'(?:\1)?'                                                        # 3: 授權人 (可選, 同名)
        r'\s*\d{1,3}[/\-]\d{1,2}',
        text_raw
    )
    if m_fb4:
        nm = re.sub(r'\s', '', m_fb4.group(1)).strip()
        if 2 <= len(nm) <= 4 and nm not in ('鼎綸恩宇', '恩宇', '主約', '附約'):
            return nm

    # v2.28.9 #8：富邦續期應繳保件一覽表「保單號-NN 險種 名 名 NTD」
    # 「1076696285-00 LTM 王稔嘉 王稔嘉 NTD 20,285 ...」
    m_fb5 = re.search(
        r'\b\d{10,12}-\d{2}\s+[A-Z]{2,5}\s+'
        r'((?:[一-鿿豈-﫿*○Ｏ＊]\s*){2,4})'  # 1: 被保人
        r'\1'                                                              # 2: 要保人 = 被保人
        r'\s*(?:NTD|USD|AUD|CNY|EUR|JPY|HKD|GBP)',
        text_raw
    )
    if m_fb5:
        nm = re.sub(r'\s', '', m_fb5.group(1)).strip()
        if 2 <= len(nm) <= 4 and nm not in ('鼎綸恩宇', '恩宇'):
            return nm

    # v2.28.9 #6/#13：富邦結案明細 / 單位照會明細 2 行格式（保單號上、被保人下）
    # 「1080724367-00 PAF 114/12/18 ...\n董素華」
    for m in re.finditer(
        r'\b\d{10,12}-\d{2}\s+[A-Z]{2,5}\s+1\d{2}/\d{1,2}/\d{1,2}[^\n]*\n\s*([一-鿿豈-﫿*○Ｏ＊]{2,4})\b',
        text_raw
    ):
        nm = m.group(1).strip()
        if 2 <= len(nm) <= 4 and nm not in ('鼎綸恩宇', '恩宇'):
            return nm

    # v2.28.9 #19：富邦保單簽收追蹤表（單行多筆）
    # 「1081229130-00 PAF 陳秀錦 許意彤 0115/02/24」
    # 保單號 險種 被保人 業務員 日期
    m_fb6 = re.search(
        r'\b\d{10,12}-\d{2}\s+[A-Z]{2,5}\s+'
        r'([一-鿿豈-﫿*○Ｏ＊]{2,4})\s+'  # 1: 被保人
        r'[一-鿿豈-﫿*○Ｏ＊]{2,4}\s+'    # 業務員
        r'0?1\d{2}[/\-]\d{1,2}[/\-]\d{1,2}',
        text_raw
    )
    if m_fb6:
        nm = m_fb6.group(1).strip()
        if 2 <= len(nm) <= 4 and nm not in ('鼎綸恩宇', '恩宇'):
            return nm

    # v2.28.12：常見「應該被當作姓名後綴」的詞（會被誤吃進 group 1）
    # 例如 pattern 抓到「吳芊儀送」其中「送」是「送件人員」的開頭
    NAME_TAIL_STRIP = ('送件', '信函', '要保', '請於', '敬請', '服務', '投保',
                       '險種', '主約', '附約', '公司', '招攬', '經辦', '完成',
                       '簽收', '印章', '代理', '傳真', '預計', '分機', '事故',
                       '受款', '受益', '理賠', '匯款', '帳號', '銀行', '通路')

    def _strip_name_tail(n: str) -> str:
        for tail in NAME_TAIL_STRIP:
            if tail and len(n) > len(tail[:1]) and n.endswith(tail[:1]):
                # 只剝 1 個字（保守）
                trimmed = n[:-1]
                if 2 <= len(trimmed) <= 4 and re.search(r'[一-鿿豈-﫿]', trimmed):
                    return trimmed
        return n

    for p in patterns:
        m = re.search(p, text_clean)
        if m:
            name = m.group(1).strip()
            # v2.28.12：剝掉尾巴黏到的下一個欄位首字（如「送」「請」「服」「招」等）
            name = _strip_name_tail(name)
            # v2.28.9：要求至少 1 個是真正中文字
            if 2 <= len(name) <= 4 and re.search(r'[一-鿿豈-﫿]', name):
                return name

    # v2.28.9：擴展屏蔽符 — 半形 O 在中文之間（如「李O松」），但要求其他字是中文
    pat_half_o = re.compile(r'被保[險]?人?姓?名?\s*[:：]\s*([一-鿿豈-﫿][O][一-鿿豈-﫿])')
    m_o = pat_half_o.search(text_clean)
    if m_o:
        return m_o.group(1)

    # 清冊格式：從「資料行」抓被保人（用未清空格的原始文字，因為清冊依賴空格分隔欄位）
    name_from_clinic = _parse_name_from_list_row(text_raw)
    if name_from_clinic:
        return name_from_clinic

    # 表格欄位格式：「│被保險人姓名 │」的下面數行有「│ 中文姓名 │」
    # 用於宏泰體檢照會單這種「欄位標題在上、資料在下」的表格
    lines = text_raw.split('\n')
    for i, line in enumerate(lines):
        if '被保險人姓名' in line or '被 保 險 人 姓 名' in line:
            # 找下面 6 行內，「│ 純中文名 │」這樣的 cell
            for j in range(i+1, min(i+7, len(lines))):
                # 先試「│ XXX │」這種
                cells = [c.strip() for c in lines[j].split('│')]
                for c in cells:
                    # 排除「年齡」「招攬人員」等標題的 cell（先處理空格）
                    c_clean = re.sub(r'\s+', '', c)
                    if c_clean in ('年齡', '招攬人員', '業務單位', '身分證統一編號',
                                   '壽險投保總金額', '日期', '保單號碼'):
                        continue
                    # 抓純中文 2-4 字（清掉空格後）
                    if re.match(r'^[\u4e00-\u9fff\uf900-\ufaff*\u25cb\uff2f\uff0a]{2,4}$', c_clean):
                        return c_clean
            break

    # 退而求其次：抓「要保人」（**必須有冒號**，避免「要保人聯絡」這種誤抓）
    m = re.search(r'要\s*保\s*人\s*[:：]\s*([\u4e00-\u9fff\uf900-\ufaff*\u25cb\uff2f\uff0a]{2,4})' + suffix_stop, text_clean)
    if m:
        candidate = m.group(1).strip()
        # 排除誤抓的常見詞
        if candidate in ('聯絡', '地址', '電話', '基本', '相關', '簽收', '簽章', '保險', '名稱', '資料'):
            return None
        return candidate
    return None


def _parse_name_from_list_row(text: str) -> Optional[str]:
    """從清冊格式的資料行抓「被保人」姓名 + 保單號碼

    回傳被保人姓名（保單號碼用另一個函式處理）

    格式範例：
    - 凱基核保: 「恩宇 莊詠甯 王清俊 D2288977 115/05/01」
       → 第3個中文姓名是被保人
    - 凱基保服: 「11D2BE 洪唯竣 藍立揚 21289317 115/01/28」
       → 英數代號 + 業務員 + 被保人 + 保單號 + 日期
    - 宏泰簽收回條: 「I39035 鼎綸恩宇 1114207206 彭堯廷 彭家文 115/04/01」
       → 保單號之後 2 個中文姓名，最後一個是被保人
    - 宏泰下月應收: 「李育松 1114201302呂**豪 113/05/13」
       → 保單號之後第一個中文姓名（含*的也算）就是要保人
    """
    # v2.28：凱基取消通知書清冊格式
    # 「鼎綸－恩宇 翁苑萍 陳宥均 5802831 D2260261」
    # 鼎綸-XX 業務員 被保人 受理號 保單號
    # text 原文還有空格時試（清冊解析從 text_raw 進來時）
    m = re.search(
        r'鼎綸[-－—]\S+\s+'
        r'([\u4e00-\u9fff\uf900-\ufaff*\u25cb\uff2f\uff0a]{2,4})\s+'  # 業務員/SPONSOR1
        r'([\u4e00-\u9fff\uf900-\ufaff*\u25cb\uff2f\uff0a]{2,4})\s+'  # 被保人 ★
        r'\d{6,10}\s+'                                # 受理號
        r'[A-Z]{0,5}\d{6,12}',                            # 保單號
        text
    )
    if m:
        name = m.group(2).strip()
        if name not in ('鼎綸恩宇', '恩宇', '鼎綸', '保經') and 2 <= len(name) <= 4:
            return name
    # text 已清過空格時試（中文名連在一起）「鼎綸－恩宇翁苑萍陳宥均 5802831 D2260261」
    # \S+ 吃整段「鼎綸-XX名名名」，從中拆出最後 2-4 字為被保人
    m = re.search(
        r'鼎綸[-－—](\S+)\s+\d{6,10}\s+[A-Z]{0,5}\d{6,12}',
        text
    )
    if m:
        block = m.group(1)  # e.g.「恩宇翁苑萍陳宥均」
        # 去掉前面「恩宇/恩宇分行/南門育成」之類的單位名
        # 嘗試取最後 2-3 字為被保人
        clean = re.sub(r'^(恩宇|南門育成|鼎綸)', '', block)
        # 如果剩下 4-6 字（業務員+被保人）取後 2-3 字
        if 4 <= len(clean) <= 12:
            # 後 3 字 vs 後 2 字 — 偏好 3 字（多數中文姓名是 3 字）
            cand = clean[-3:] if len(clean) >= 6 else clean[-2:]
            if re.fullmatch(r'[\u4e00-\u9fff\uf900-\ufaff*\u25cb\uff2f\uff0a]{2,4}', cand):
                if cand not in ('鼎綸恩宇', '恩宇', '鼎綸', '保經'):
                    return cand

    # v2.28：富邦 RWLFN042 非新契約類案件結案通知格式
    # 「1 1071479012-00 114/10/28 114/10/30 理賠 11404I0218（詳給付明細）」
    # 下一行：「陳○安」 (被保人)
    # 再下一行：「李○芳」 (要保人)
    lines = text.split('\n')
    for i, line in enumerate(lines):
        m = re.match(r'\s*\d+\s+(\d{10,12})-\d{2}\s+1\d{2}[/\-]\d{1,2}[/\-]\d{1,2}', line)
        if m and i + 1 < len(lines):
            # 下一行應該是被保人姓名（純中文+/-屏蔽符 2-4 字）
            cand = lines[i+1].strip()
            cand_clean = re.sub(r'\s+', '', cand)
            if re.fullmatch(r'[\u4e00-\u9fff\uf900-\ufaff\*○Ｏ]{2,4}', cand_clean):
                if cand_clean not in ('鼎綸恩宇', '恩宇', '鼎綸', '保經'):
                    return cand_clean

    # 模式 0：凱基保服清冊「英數代號 姓名 姓名 保單號 日期」
    # 例：「11D2BE 洪唯竣 藍立揚 21289317 115/01/28」
    m = re.search(
        r'\b[A-Z0-9]{4,8}\s+'                                # 11D2BE
        r'([\u4e00-\u9fff\uf900-\ufaff*\u25cb\uff2f\uff0a]{2,4})\s+'           # 洪唯竣（業務員）
        r'([\u4e00-\u9fff\uf900-\ufaff*\u25cb\uff2f\uff0a]{2,4})\s+'           # 藍立揚（被保人）★
        r'(\d{7,12})\s+1\d{2}[/\-]',                        # 21289317 115/01/28
        text
    )
    if m:
        name = m.group(2).strip()  # 第 2 個是被保人
        if name not in ('鼎綸恩宇', '恩宇', '鼎綸', '保經') and 2 <= len(name) <= 4:
            return name

    # 模式 1：「X姓名 Y姓名 Z姓名 保單號 日期」 → 取 Z（被保人）
    patterns = [
        r'(?:[\u4e00-\u9fff\uf900-\ufaff*\u25cb\uff2f\uff0a]{2,4}\s+){2,}([\u4e00-\u9fff\uf900-\ufaff*\u25cb\uff2f\uff0a]{2,4})\s+([A-Z]{0,5}\d{6,12})\s+1\d{2}[/\-]',
    ]
    for p in patterns:
        m = re.search(p, text)
        if m:
            name = m.group(1).strip()
            if name in ('鼎綸恩宇', '恩宇', '鼎綸', '保經'):
                continue
            if 2 <= len(name) <= 4:
                return name

    # 模式 2：「保單號 姓名 ... 姓名 日期」 → 取最後一個姓名（被保人）
    # 例：「1114207206 彭堯廷 彭家文 115/04/01」
    m = re.search(
        r'\b[A-Z]?\d{7,12}\s+([\u4e00-\u9fff\uf900-\ufaff*\u25cb\uff2f\uff0a]{2,4})\s+([\u4e00-\u9fff\uf900-\ufaff*\u25cb\uff2f\uff0a]{2,4})\s+1\d{2}[/\-]',
        text
    )
    if m:
        return m.group(2).strip()

    # 模式 2.5：「保單號 要保人 被保人 文件種類」（簽收表格式）
    # 例：「1114207565 簡嘉均 簡嘉均 核保照會單 ＊ 1 呂怡瑩 陳周娜」
    m = re.search(
        r'\b[A-Z]?\d{7,12}\s+([\u4e00-\u9fff\uf900-\ufaff*\u25cb\uff2f\uff0a]{2,4})\s+([\u4e00-\u9fff\uf900-\ufaff*\u25cb\uff2f\uff0a]{2,4})\s+[\u4e00-\u9fff\uf900-\ufaff]{2,15}(?:單|書|表|通知|明細)',
        text
    )
    if m:
        return m.group(2).strip()  # 第 2 個是被保人

    # 模式 3：「保單號姓名（含 * 屏蔽）」例「1114201302呂**豪」
    m = re.search(r'\b\d{7,12}([\u4e00-\u9fff\uf900-\ufaff*]{2,5})\b', text)
    if m:
        name = m.group(1).strip()
        if 2 <= len(name) <= 5:
            return name

    return None


def _parse_all_rows_from_list(text: str, doctype: Optional[str] = None) -> List[Tuple[Optional[str], Optional[str]]]:
    """從清冊類 PDF 抽出**全部**資料行的 (被保人, 保單號) 配對

    用於拆分清冊類 PDF。
    回傳 List[(name, policy)]，每筆對應一筆資料。

    支援格式：
    - 宏泰下月應收件明細表：「李育松 1114201740蔡**鈞 113/06/06 20WLG ...」
      (含星號屏蔽姓名)
    - 宏泰簽收回條回覆清單：「I39035 鼎綸恩宇 1114207206 彭堯廷 彭家文 115/04/01」
    - 凱基保服清冊：「11D2BE 洪唯竣 藍立揚 21289317 115/01/28」
    - 凱基核保清冊：「恩宇 莊詠甯 王清俊 D2288977 115/05/01」
    """
    results = []
    if not text:
        return results

    # v2.28.13：把 (cid:NN) 轉成屏蔽符 ＊，方便姓名抓取
    import re as _re
    text = _re.sub(r'\(cid:\d+\)', '＊', text)

    seen = set()  # 避免重複 (name, policy)

    # 模式 1：宏泰下月應收件明細表 / 一年期傷害險到期 / 電子保單通知報表
    # 格式：「[業代] 1114201740蔡**鈞 113/06/06 20WLG ...」
    # 業代可能在第一行有，後面行省略（接前一行業代）
    # 保單號之後緊跟著姓名（無空格），含 * 屏蔽
    for m in re.finditer(
        r'(\d{10})([\u4e00-\u9fff\uf900-\ufaff*＊]{2,5})\s+\d{2,3}/\d{1,2}/\d{1,2}',
        text
    ):
        policy = m.group(1)
        name = m.group(2).strip()
        if 2 <= len(name) <= 5:
            key = (name, policy)
            if key not in seen:
                seen.add(key)
                results.append(key)

    # 模式 2：宏泰簽收回條回覆清單
    # 格式：「[單位] 1114207206 彭堯廷 彭家文 115/04/01」
    # 保單號 → 要保人 → 被保人 → 日期
    for m in re.finditer(
        r'\b(1\d{9})\s+[\u4e00-\u9fff\uf900-\ufaff*＊]{2,5}\s+([\u4e00-\u9fff\uf900-\ufaff*＊]{2,5})\s+1\d{2}[/\-]\d{1,2}[/\-]\d{1,2}',
        text
    ):
        policy = m.group(1)
        name = m.group(2).strip()
        if 2 <= len(name) <= 5:
            key = (name, policy)
            if key not in seen:
                seen.add(key)
                results.append(key)

    # 模式 3：凱基保服清冊「11D2BE 洪唯竣 藍立揚 21289317 115/01/28」
    for m in re.finditer(
        r'\b[A-Z0-9]{4,8}\s+[\u4e00-\u9fff\uf900-\ufaff*＊]{2,5}\s+([\u4e00-\u9fff\uf900-\ufaff*＊]{2,5})\s+(\d{7,12})\s+1\d{2}[/\-]\d{1,2}[/\-]\d{1,2}',
        text
    ):
        name = m.group(1).strip()
        policy = m.group(2).strip()
        if name in ('鼎綸恩宇', '恩宇', '鼎綸', '保經'):
            continue
        if 2 <= len(name) <= 5:
            key = (name, policy)
            if key not in seen:
                seen.add(key)
                results.append(key)

    # 模式 4：凱基核保清冊「恩宇 莊詠甯 王清俊 D2288977 115/05/01」
    for m in re.finditer(
        r'(?:[\u4e00-\u9fff\uf900-\ufaff*\u25cb\uff2f\uff0a]{2,4}\s+){2,}([\u4e00-\u9fff\uf900-\ufaff*＊]{2,5})\s+([A-Z]{0,5}\d{6,12})\s+1\d{2}[/\-]\d{1,2}[/\-]\d{1,2}',
        text
    ):
        name = m.group(1).strip()
        policy = m.group(2).strip()
        if name in ('鼎綸恩宇', '恩宇', '鼎綸', '保經'):
            continue
        if 2 <= len(name) <= 5:
            key = (name, policy)
            if key not in seen:
                seen.add(key)
                results.append(key)

    # 模式 5：宏泰電子保單通知報表 / 電子保單轉紙本明細表 / 首期信用卡扣款 / 保單簽收回條回覆清單
    # 格式 A：「2101348762黃冠綸 黃冠綸 陳玟君 IPA1 ...」(保單號緊接姓名，再空格姓名)
    # 格式 B：「2101342948許沛晴 許元穎 陳玟君 115/01/16」
    # 格式 C：「1114206432魯惠玲 114/11/02 12 8586李育松 ...」(扣款表，保單號+要保人)
    # 格式 D：「I39029 鼎綸... 2101361229 王慈玟 王慈玟 115/01/19」(簽收回條清單，保單號獨立)
    # 提取邏輯：找「10碼數字緊接2-4字中文姓名」
    for m in re.finditer(
        r'\b(1\d{9}|2\d{9})([\u4e00-\u9fff\uf900-\ufaff*＊]{2,5})\b',
        text
    ):
        policy = m.group(1)
        name = m.group(2).strip()
        # 排除一些誤抓
        if name in ('鼎綸恩宇', '恩宇', '鼎綸', '保經'):
            continue
        if 2 <= len(name) <= 5:
            key = (name, policy)
            if key not in seen:
                seen.add(key)
                results.append(key)

    # 模式 6：簽收回條回覆清單「I39029 鼎綸... 2101361229 王慈玟 王慈玟 115/01/19」
    # 保單號獨立(有空格)，後面跟要保人+被保人+日期
    for m in re.finditer(
        r'\b([12]\d{9})\s+([\u4e00-\u9fff\uf900-\ufaff*＊]{2,5})\s+([\u4e00-\u9fff\uf900-\ufaff*＊]{2,5})\s+1\d{2}/',
        text
    ):
        policy = m.group(1)
        name = m.group(3).strip()  # 第 3 個是被保人
        if name in ('鼎綸恩宇', '恩宇', '鼎綸', '保經'):
            continue
        if 2 <= len(name) <= 5:
            key = (name, policy)
            if key not in seen:
                seen.add(key)
                results.append(key)

    # 模式 7：宏泰保全照會簽收表「李育松 ___ /___ 1114206370 2828220 蕭**瓊」
    # 保單號(10碼) + 案號(7碼) + 被保人(含*)
    for m in re.finditer(
        r'\b(1\d{9})\s+\d{6,8}\s+([\u4e00-\u9fff\uf900-\ufaff*＊]{2,5})\b',
        text
    ):
        policy = m.group(1)
        name = m.group(2).strip()
        if name in ('鼎綸恩宇', '恩宇', '鼎綸', '保經'):
            continue
        if 2 <= len(name) <= 5:
            key = (name, policy)
            if key not in seen:
                seen.add(key)
                results.append(key)

    # 模式 8：傷害險到期通知「2101238995 2101350235 114/12/26 徐(cid:30) 禎 何政勳 IPA1」
    # 原保單號 + 續保保單號 + 日期 + 要保人 + 主被保險人
    # 用「兩個保單號 + 日期 + 兩個姓名」抓
    for m in re.finditer(
        r'\b(1\d{9}|2\d{9})\s+(?:1\d{9}|2\d{9})\s+1\d{2}/\d{1,2}/\d{1,2}\s+'
        r'[\u4e00-\u9fff\uf900-\ufaff(cid:\d)*＊\s]{2,15}?\s+([\u4e00-\u9fff\uf900-\ufaff*\u25cb\uff2f\uff0a]{2,4})\s+[A-Z]{2,4}\d?\s+',
        text
    ):
        policy = m.group(1)
        name = m.group(2).strip()
        if name in ('鼎綸恩宇', '恩宇', '鼎綸', '保經'):
            continue
        if 2 <= len(name) <= 5:
            key = (name, policy)
            if key not in seen:
                seen.add(key)
                results.append(key)


    # ========== v2.28.13 新增 ==========
    # 模式 9：富邦人壽單位照會明細表（2 行一筆）
    # 第 1 行：「7L2220 1080724367-00 PAF 114/12/18 114/12/19 NTD 128,880 許意彤」
    # 第 2 行：「董素華 6 114/12/18 0/00/00 核保照會 廖翊均」
    for mm in re.finditer(
        r'7L\d{4}\s+(\d{10})-\d{2}\s+[A-Z]{2,4}\d?\s+\d{2,3}/\d{1,2}/\d{1,2}\s+\d{2,3}/\d{1,2}/\d{1,2}\s+NTD\s+[\d,]+\s+\S+\s*\n\s*([\u4e00-\u9fff\uf900-\ufaff*\u25cb\uff2f\uff0a]{2,5})\s+\d',
        text
    ):
        policy = mm.group(1)
        name = mm.group(2).strip()
        if name in ('鼎綸恩宇', '恩宇', '鼎綸', '保經'):
            continue
        if 2 <= len(name) <= 5:
            key = (name, policy)
            if key not in seen:
                seen.add(key)
                results.append(key)

    # 模式 10：富邦續期應繳保件一覽表
    # 格式：「1076696285-00 LTM 王稔嘉 王稔嘉 NTD 20,285 115/01/24」
    for mm in re.finditer(
        r'(\d{10})-\d{2}\s+[A-Z]{2,5}\d?\s+[\u4e00-\u9fff\uf900-\ufaff*\u25cb\uff2f\uff0a]{2,5}\s+([\u4e00-\u9fff\uf900-\ufaff*\u25cb\uff2f\uff0a]{2,5})\s+NTD\s+[\d,]+',
        text
    ):
        policy = mm.group(1)
        name = mm.group(2).strip()
        if name in ('鼎綸恩宇', '恩宇', '鼎綸', '保經'):
            continue
        if 2 <= len(name) <= 5:
            key = (name, policy)
            if key not in seen:
                seen.add(key)
                results.append(key)

    # 模式 11：富邦續期保險費尚未繳費通知
    # 格式：「1076696285-00 王稔嘉 王稔嘉 王稔嘉 聯邦銀行 ...」
    for mm in re.finditer(
        r'(\d{10})-\d{2}\s+[\u4e00-\u9fff\uf900-\ufaff*\u25cb\uff2f\uff0a]{2,5}\s+([\u4e00-\u9fff\uf900-\ufaff*\u25cb\uff2f\uff0a]{2,5})\s+[\u4e00-\u9fff\uf900-\ufaff*\u25cb\uff2f\uff0a]{2,5}\s+[\u4e00-\u9fff]{2,5}銀行',
        text
    ):
        policy = mm.group(1)
        name = mm.group(2).strip()
        if name in ('鼎綸恩宇', '恩宇', '鼎綸', '保經'):
            continue
        if 2 <= len(name) <= 5:
            key = (name, policy)
            if key not in seen:
                seen.add(key)
                results.append(key)

    # 模式 12：富邦契約變更補費扣款通知
    # 格式：「洪唯竣 101476719500 洪明煥 信用卡 114/11/04 ...」
    for mm in re.finditer(
        r'[\u4e00-\u9fff\uf900-\ufaff*\u25cb\uff2f\uff0a]{2,5}\s+(\d{10})\d{2}\s+([\u4e00-\u9fff\uf900-\ufaff*\u25cb\uff2f\uff0a]{2,5})\s+(?:信用卡|轉帳|現金|自繳)',
        text
    ):
        policy = mm.group(1)
        name = mm.group(2).strip()
        if name in ('鼎綸恩宇', '恩宇', '鼎綸', '保經'):
            continue
        if 2 <= len(name) <= 5:
            key = (name, policy)
            if key not in seen:
                seen.add(key)
                results.append(key)

    # 模式 13：富邦理賠通知單「事故人:張琦英 事故人ID: B2*****778」
    for mm in re.finditer(
        r'事故人\s*:\s*([\u4e00-\u9fff\uf900-\ufaff*\u25cb\uff2f\uff0a]{2,5})\s+事故人ID\s*:\s*([A-Z0-9*]{8,15})',
        text
    ):
        name = mm.group(1).strip()
        policy = mm.group(2).strip()
        if 2 <= len(name) <= 5:
            key = (name, policy)
            if key not in seen:
                seen.add(key)
                results.append(key)

    # 模式 14：凱基理賠結案通知
    # 「114539098 個險 林文瑜 15000 11D2BE 鼎綸－恩宇 李育松 0101101902」
    for mm in re.finditer(
        r'\b(\d{8,10})\s+(?:個險|團險|個人|團體)\s+([\u4e00-\u9fff\uf900-\ufaff*\u25cb\uff2f\uff0a]{2,5})\s+\d',
        text
    ):
        policy = mm.group(1)
        name = mm.group(2).strip()
        if name in ('鼎綸恩宇', '恩宇', '鼎綸', '保經'):
            continue
        if 2 <= len(name) <= 5:
            key = (name, policy)
            if key not in seen:
                seen.add(key)
                results.append(key)


    # 模式 15：富邦新契約結案明細表
    # 「1080724417-00 PAF 114/12/18 - 0許意彤\n陳秀錦 38.0萬元 115/01/12 取消 0」
    # 保單號-NN 險種 受理日 - 應收金額 業務員\n被保人 ...
    for mm in re.finditer(
        r'(\d{10})-\d{2}\s+[A-Z]{2,4}\d?\s+\d{2,3}/\d{1,2}/\d{1,2}\s+-?\s*\d+\s*[\u4e00-\u9fff\uf900-\ufaff*\u25cb\uff2f\uff0a]{2,5}\s*\n\s*([\u4e00-\u9fff\uf900-\ufaff*\u25cb\uff2f\uff0a]{2,5})\s+[\d.]+',
        text
    ):
        policy = mm.group(1)
        name = mm.group(2).strip()
        if name in ('鼎綸恩宇', '恩宇', '鼎綸', '保經'):
            continue
        if 2 <= len(name) <= 5:
            key = (name, policy)
            if key not in seen:
                seen.add(key)
                results.append(key)

    # 模式 16：宏泰一年期傷害險到期通知明細表
    # 「2101233980 2101345878 114/12/22 徐＊禎 徐＊禎 IPA1 3,619 李育松」
    # 原保單號 續保保單號 期滿日 要保人 被保人 險種 ...
    # 注意：(cid:NN) 已在前面被換成 ＊
    for mm in re.finditer(
        r'\b(2\d{9})\s+(2\d{9})\s+1\d{2}/\d{1,2}/\d{1,2}\s+([\u4e00-\u9fff\uf900-\ufaff*\u25cb\uff2f\uff0a]{2,5})\s+([\u4e00-\u9fff\uf900-\ufaff*\u25cb\uff2f\uff0a]{2,5})\s+[A-Z]{2,4}\d?\s+[\d,]+',
        text
    ):
        policy = mm.group(2)  # 用續保保單號（新生效的）
        name = mm.group(4).strip()  # 被保人在第 4
        if name in ('鼎綸恩宇', '恩宇', '鼎綸', '保經'):
            continue
        if 2 <= len(name) <= 5:
            key = (name, policy)
            if key not in seen:
                seen.add(key)
                results.append(key)

    # 模式 17：宏泰電子保單通知報表
    # 「2101345878徐＊禎 徐＊禎 李育松 IPA1 3,619.00 114/12/22 114/12/24」
    # 保單號(10碼)緊接被保人(無空格) 業務員 險種 ...
    for mm in re.finditer(
        r'\b(2\d{9})([\u4e00-\u9fff\uf900-\ufaff*\u25cb\uff2f\uff0a]{2,5})\s+([\u4e00-\u9fff\uf900-\ufaff*\u25cb\uff2f\uff0a]{2,5})\s+[\u4e00-\u9fff\uf900-\ufaff]{2,5}\s+[A-Z]{2,4}\d?',
        text
    ):
        policy = mm.group(1)
        name = mm.group(2).strip()  # 緊接保單號的就是被保人(=要保人)
        if name in ('鼎綸恩宇', '恩宇', '鼎綸', '保經'):
            continue
        if 2 <= len(name) <= 5:
            key = (name, policy)
            if key not in seen:
                seen.add(key)
                results.append(key)

    # 模式 18：宏泰壽險保單簽收回條回覆清單
    # 「I39035 鼎綸恩宇 1114207073 馬向榮 馬向榮 114/12/22」
    # 跟模式 2 重疊但模式 2 用 1\d{9}，這裡明確
    pass  # 已被模式 2 / 6 涵蓋

    return results


def parse_doctype(text: str) -> str:
    """從 PDF 第一頁抓出文件標題（單/書/表/通知/明細 結尾的短行）

    自動辨識任何標題，不需維護關鍵字清單。
    範例：「新契約核保照會通知單」、「重要照會單」、「醫療理賠申請書」
    宏泰格式：「<<新契約照會簽收表>>」「<<下月應收件明細表 >>」
    台壽格式：「保險金理賠通知書 -- 保戶」（有後綴）
    安聯格式：「保戶服務部 契約內容變更補全照會單」（前面有部門名）
    富邦理賠格式：「ICMSIQFQ 富邦人壽... 理賠照會單 照會日期:...」（混雜在第 2-3 行）
    """
    if not text:
        return '文件'

    # v2.28：先清掉私有區 PUA 字符
    text = re.sub(r'[\ue000-\uf8ff]', '', text)
    # v2.28：建立「清過字間空格」的版本，用於關鍵字直抓
    text_nospace = re.sub(r'(?<=[\u4e00-\u9fff\uf900-\ufaff])\s+(?=[\u4e00-\u9fff\uf900-\ufaff])', '', text)

    # 富邦特殊：「XX照會單 照會日期:...」這種格式
    # v2.28.9 #30：宏泰 <<XXX>> / 《XXX》 包圍的標題優先抓
    _m_bracketed = re.search(r'[<《]{1,2}\s*([一-鿿豈-﫿]{4,25}(?:單|書|表|通知|明細|清單|清冊|報表|一覽表|問卷))\s*[>》]{1,2}', text_nospace[:800])
    if _m_bracketed:
        _r = _m_bracketed.group(1).strip()
        if 4 <= len(_r) <= 25:
            return _r

    # 例：「理賠照會單 照會日期:115/01/26」「核保照會單 照會日期:...」
    m = re.search(r'([\u4e00-\u9fff\uf900-\ufaff]{2,15}(?:單|書|表|通知|明細|清單|清冊|報表|一覽表|問卷))\s+照會日期', text_nospace[:500])
    if m:
        result = m.group(1).strip()
        # 排除短行誤抓
        if 3 <= len(result) <= 20:
            return result

    # v2.28：常見文件種類直抓（在 text_nospace 上搜，能跨字間空格）
    # v2.28.9：大幅擴充字典（+ 18 種新文件種類）
    doctype_keywords = [
        '保險金理賠給付通知書', '保險金理賠通知書',
        '強制汽車責任保險電子式保險證', '強制汽車責任保險證',
        '新契約照會單', '新契約照會催辦單', '新契約核保照會單', '新契約催辦照會單',
        '新契約核保通知書', '新契約核保照會逾期通知單',
        '新契約體檢照會催辦通知單',
        # v2.28.10 新增 ↓
        '無授權書通知', '新光人壽無授權書通知',
        # 台灣人壽 RL037 報表「新契約照會/保服照會/理賠照會」匯總表
        '新契約照會通知', '保服照會通知', '理賠照會通知',
        # v2.28.9 新增 ↓
        '新契約體檢照會通知單', '體檢照會通知單',
        '新契約保險費轉帳扣款授權書照會單', '保險費轉帳扣款授權書照會單',
        '首期轉帳扣款通知',
        '電子保單轉紙本保單明細表',
        '富邦人壽紙本保單以電子方式簽收之完成簽收通知', '紙本保單以電子方式簽收之完成簽收通知',
        '富邦人壽電子保單已簽收通知', '電子保單已簽收通知',
        '保單簽收追蹤表', '保單簽收追蹤第一次通知',
        '富邦人壽單位照會明細表', '單位照會明細表', '單位照會',
        '富邦人壽新契約結案明細表', '新契約結案明細表',
        '富邦人壽契約變更補費扣款通知', '契約變更補費扣款通知',
        '富邦人壽續期應繳保件一覽表', '續期應繳保件一覽表', '續期保件一覽表',
        '保全業務聯繫照會單', '保險費自動扣款約定銀行核驗結果通知書',
        '保全退件通知書',
        '照會表單簽收明細表',
        # v2.28 既有 ↓
        '契約內容變更補全照會單',
        '承保後電訪清單',
        '一年期個人傷害險到期通知明細表',
        '保全變更結案明細',
        '電子保單完成簽收明細表', '電子保單發單明細',
        '電子保單簽收回條簽收回執日明細表', '電子保單簽收回條回執日明細表',
        '簽收回條已回清冊',
        '續期保險費尚未繳費通知',
        '非新契約類案件結案通知', '非新契約案件結案通知',
        '客戶通知連續寄發失敗', '客戶通知連續寄發失敗３次以上之通知單',
        '富邦人壽催告通知', '催告通知',
        '富邦人壽核保通過暨電子保單發單', '核保通過暨電子保單發單',
        '取消通知書清冊', '保件取消通知單',
        '催繳通知書', '滿期通知書', '保戶服務通知書',
        '保單簽收管理報表', '非結構債現金配息日報表',
        '重要照會單', '保險金理賠通知書--保戶', '保險金理賠通知書--服務人員',
    ]
    m = re.search('(' + '|'.join(map(re.escape, doctype_keywords)) + ')', text_nospace[:2000])
    if m:
        result = m.group(1).strip()
        return result

    lines = text.split('\n')[:12]  # 看前 12 行

    # 跳過這類「公司全名」行
    company_suffixes = ['股份有限公司', '保險股份有限公司', '人壽保險公司']

    for line in lines:
        # 清掉中文字之間的所有空格（不只 1 個空格）
        line_clean = re.sub(r'(?<=[\u4e00-\u9fff\uf900-\ufaff])\s+(?=[\u4e00-\u9fff\uf900-\ufaff])', '', line.strip())
        # v2.28：先用 ※/，/( 等切，取首段（避免「契約內容變更補全照會單 ※各項照會...」被當作整行）
        for sep in ['※', '，', '。', '(', '（', '：', ':']:
            if sep in line_clean:
                first_part = line_clean.split(sep, 1)[0].strip()
                if first_part and re.search(r'(單|書|表|通知|明細|清單|清冊|報表|一覽表|問卷|證)\s*$', first_part):
                    line_clean = first_part
                    break
        # 移除 <<>>、《》 包圍符
        line_clean = line_clean.strip('<>《》 ')
        if not line_clean:
            continue
        # 跳過公司名全銜
        if any(suffix in line_clean for suffix in company_suffixes):
            continue
        # 跳過 (cid:xx) 這類解碼失敗的字
        if '(cid:' in line_clean:
            continue

        # 切掉「-- 保戶」「-- 服務人員」「(本體檢照會單請隨同...)」等後綴
        line_clean = re.sub(r'\s*[-─–—]+\s*[\u4e00-\u9fff\uf900-\ufaff]+\s*$', '', line_clean)
        line_clean = re.sub(r'\s*\([^)]*\)\s*$', '', line_clean)
        # v2.28：切掉全形括號後綴「（申辦單位聯）」「（本聯）」
        line_clean = re.sub(r'\s*（[^）]*）\s*$', '', line_clean)
        # 切掉前面的「保戶服務部」這種部門名（用空格隔開的）
        line_clean = re.sub(r'^[\u4e00-\u9fff\uf900-\ufaff]{3,5}部\s+', '', line_clean)
        # 切掉富邦的英文代碼前綴（如 ICMSIQFQ）
        line_clean = re.sub(r'^[A-Z]{4,12}\s+', '', line_clean)
        line_clean = line_clean.strip()

        if not line_clean or len(line_clean) > 25:
            continue
        # 跳過純數字/符號的行
        if re.match(r'^[\d\s\-/():：*A-Za-z]+$', line_clean):
            continue

        # 判斷是否以常見文件後綴結尾
        if re.search(r'(單|書|表|通知|明細|清單|清冊|公告|證明|聲明|報表|一覽表|問卷)\s*$', line_clean):
            # v2.28：拒絕內文條列／條款句子（不是真正的文件標題）
            #   富邦「１、上述所列示之電子保險單」「◎上述所列示之保險單」
            if re.match(r'^[０-９0-9]+[、,，.]|^[◎●※□△]', line_clean):
                continue
            if re.search(r'(上述|所列|所述|本通知|本公司|本批註|本保單|本契約|本附約|您於|請於|請至|請查照|為配合|根據|依據|關於|有關)', line_clean):
                continue
            # 去掉開頭可能的公司名前綴
            cleaned = re.sub(r'^[\u4e00-\u9fff\uf900-\ufaff*\u25cb\uff2f\uff0a]{2,4}人壽\s*', '', line_clean)
            cleaned = re.sub(r'^[\u4e00-\u9fff\uf900-\ufaff*\u25cb\uff2f\uff0a]{2,4}保險\s*', '', cleaned)
            cleaned = re.sub(r'^[\u4e00-\u9fff\uf900-\ufaff*\u25cb\uff2f\uff0a]{2,4}產物\s*', '', cleaned)
            # v2.28：清掉開頭的富邦類英數代碼前綴（如 RNBEPIPA1, RRN6520, RWLFN042, ICMSIQFQ）
            cleaned = re.sub(r'^[A-Z]{2,10}\d*[A-Z]*\d*\s+', '', cleaned)
            cleaned = re.sub(r'^[\u4e00-\u9fff\uf900-\ufaff*\u25cb\uff2f\uff0a]{2,4}人壽\s*', '', cleaned)  # 再切一次（避免代碼後又有人壽前綴）
            return cleaned

    return '文件'


def parse_company_from_pdf_text(text: str) -> Optional[str]:
    """從 PDF 內文判斷公司（最權威，比檔名準確）

    範例：「宏泰人壽保險股份有限公司」→「宏泰」
          「Allianz Taiwan Life」→「安聯」
    """
    if not text:
        return None

    # 把字間空格清掉
    text_clean = re.sub(r'(?<=[\u4e00-\u9fff\uf900-\ufaff])\s+(?=[\u4e00-\u9fff\uf900-\ufaff])', '', text[:1500])

    # 公司辨識（看 PDF 開頭 1500 字內）
    company_patterns = [
        ('宏泰', r'宏泰人壽'),
        ('凱基', r'凱基人壽'),
        ('全球', r'全球人壽'),
        ('新光', r'新光人壽'),
        ('台新', r'台新人壽'),
        ('富邦', r'富邦人壽'),
        ('安聯', r'安聯人壽|Allianz'),
        ('友邦', r'友邦人壽'),
        ('保誠', r'保誠人壽'),
        ('法巴', r'法巴人壽|BNP'),
        ('安達', r'安達人壽|Chubb'),
        ('第一金', r'第一金人壽'),
        ('元大', r'元大人壽'),
        ('台灣', r'台灣人壽|Taiwan\s*Life|台南分公司理賠'),  # v2.28.9：台壽→台灣
        ('台灣產物', r'台灣產物'),
    ]
    for name, pattern in company_patterns:
        if re.search(pattern, text_clean, re.IGNORECASE):
            return name

    return None


def sanitize_filename(s: str) -> str:
    """移除 Windows 檔名不允許的字元
    
    特殊處理：姓名中的「*」屏蔽符替換為全形「Ｏ」（保留屏蔽感）
    連續多個星號壓成單一「Ｏ」
    """
    # 連續星號壓成單一 Ｏ（如「呂**豪」→「呂Ｏ豪」）
    s = re.sub(r'\*+', 'Ｏ', s)
    # 移除 Windows 禁用字元
    return re.sub(r'[\\/:?"<>|]', '', s).strip()


def sanitize_policy(s: str) -> str:
    """v2.28.9：保單號專用 sanitize — 每個 `*` 換成全形 `＊`（不壓縮，保留長度）

    保單號的屏蔽資訊量要保留，不像姓名要簡化。
    例：「L2****668-1」→「L2＊＊＊＊668-1」（4 個 * 變 4 個 ＊）
    """
    # 每個 * 個別換成 ＊（保留長度）
    s = s.replace('*', '＊')
    # 移除 Windows 禁用字元
    return re.sub(r'[\\/:?"<>|]', '', s).strip()


def parse_policy_number(text: str) -> Optional[str]:
    """從 PDF 文字中抓出保單號碼

    支援各家公司的格式：
    - 全球: 「保 單 號 碼：88001967870」（有空格）
    - 凱基: 「保單號碼 ： N2876813」（含字母）
    - 新光: 「保單號碼：1680303160」
    - 宏泰: 「保 單 號 碼 : 1114207448」（表格內 10 碼數字）
    - 安聯: 「保單號碼: QL19052233」
    - 台壽: 「保單號 碼 : 1016***237」（帶屏蔽）
    """
    if not text:
        return None

    # v2.28：先清掉私有區 PUA 字符
    text = re.sub(r'[\ue000-\uf8ff]', '', text)

    # 先把字間空格清掉
    text_clean = re.sub(r'(?<=[\u4e00-\u9fff\uf900-\ufaff])\s+(?=[\u4e00-\u9fff\uf900-\ufaff])', '', text)

    patterns = [
        # 保單號碼：xxx（容許各種空格、半形/全形冒號）
        # 帶屏蔽星號的保單號（台壽理賠通知書 1016***237）優先
        r'保\s*單\s*號\s*碼\s*[:：]\s*(\d{4}\*+\d{3,4})',
        # v2.28.9 #1：富邦理賠通知書屏蔽保單號「L2****668-1」（字母+數字+星號+數字+(-N)）
        r'保\s*單\s*號\s*碼\s*[:：]\s*([A-Z]\d{1,2}\*+\d{3,6}(?:-\d)?)',
        # v2.28.12：全球理賠照會單「您所申請保單 IN007720 被保險人 ...」
        r'(?:申請保單|您所申請保單)\s+([A-Z]{2,4}\d{5,10})\s+被保險人',
        # v2.28：富邦表格行「1078914578-00 蕭資芮...」 — 抓 10-12 碼數字（前面緊接行首或換行）
        r'(?:^|\n)\s*(\d{10,12})-\d{2}\s+[\u4e00-\u9fff\uf900-\ufaff]',
        # v2.28：富邦 RWLFN042「1 1071479012-00 114/10/28」格式
        r'\b\d+\s+(\d{10,12})-\d{2}\s+1\d{2}[/\-]\d{1,2}[/\-]\d{1,2}',
        # v2.28：富邦 RRN43F8「1 H224123091 王稔嘉 1076696285-00 王稔嘉」
        r'\b\d+\s+[A-Z]\d{8,12}\s+[\u4e00-\u9fff\uf900-\ufaff*\u25cb\uff2f\uff0a]{2,4}\s+(\d{10,12})-\d{2}',
        # v2.28：凱基取消清冊「鼎綸－恩宇 翁苑萍 陳宥均 5802831 D2260261」
        # text_clean 後中文姓名會連在一起：「鼎綸－恩宇翁苑萍陳宥均 5802831 D2260261」
        # 所以用 \S+ 吃整段「鼎綸-XX名名名」直到第一個空白，再接受理號 + 保單號
        r'鼎綸[-－—]\S+\s+\d{6,10}\s+([A-Z]{0,5}\d{6,12})\b',
        # 一般格式
        r'保\s*單\s*號\s*碼\s*[:：]\s*([A-Z0-9]{6,20})',
        # v2.28：強制險「保險證號碼:1714M8210718」
        r'保\s*險\s*證\s*號\s*碼\s*[:：]\s*([A-Z0-9]{6,20})',
        # 「保單號碼 1114207448」（表格 cell 之間用空白隔開）
        r'保單號碼\s+([A-Z]?\d{7,15})\b',
        r'保單號\s*碼\s+([A-Z]?\d{7,15})\b',
        # v2.28.9 #21：新光「保單號碼9007130750」（無冒號可能無空格）
        r'保單號碼([A-Z]?\d{8,15})\b',
    ]
    for p in patterns:
        m = re.search(p, text_clean)
        if m:
            policy = m.group(1).strip()
            # v2.28.9：用屏蔽符清除版檢查長度，但回傳原始（含 * 屏蔽）讓 sanitize_policy 處理
            policy_check = re.sub(r'\*+', '', policy)
            if len(policy_check) >= 6:
                return policy

    # 清冊資料行：「姓名 姓名 姓名 D2288977 115/05/01」或「1114207206 姓名 姓名 115/...」
    # 模式 1: 中文姓名後跟保單號（凱基清冊）
    m = re.search(
        r'[\u4e00-\u9fff\uf900-\ufaff*\u25cb\uff2f\uff0a]{2,4}\s+([A-Z]{0,5}\d{6,12})\s+1\d{2}[/\-]\d{1,2}[/\-]\d{1,2}',
        text_clean
    )
    if m:
        return m.group(1).strip()
    # 模式 2: 保單號在中文姓名前（宏泰簽收回條）
    m = re.search(
        r'\b([A-Z]?\d{7,12})\s+[\u4e00-\u9fff\uf900-\ufaff*\u25cb\uff2f\uff0a]{2,4}\s+[\u4e00-\u9fff\uf900-\ufaff*\u25cb\uff2f\uff0a]{2,4}',
        text_clean
    )
    if m:
        return m.group(1).strip()
    # 模式 3: 簽收表「保單號 中文字串（要保人+被保人連在一起）」
    # 例：「1114207565 簡嘉均簡嘉均核保照會單」（PDF 抽取後中文字黏在一起）
    m = re.search(
        r'\b([A-Z]?\d{7,12})\s+[\u4e00-\u9fff\uf900-\ufaff]{4,10}(?:單|書|表|通知|明細)',
        text_clean
    )
    if m:
        return m.group(1).strip()
    # v2.28.9 #12：富邦契約變更補費扣款「保單號碼...10147671 9500」中間被空格切開
    m = re.search(r'保單號碼[^\n]{0,80}?(\d{8})\s+(\d{4})\b', text)
    if m:
        return m.group(1) + m.group(2)
    # v2.28.9 #24：宏泰 10 碼純數字保單號（無 -NN）— 換行後接 10-12 碼
    m = re.search(r'保單號碼[^\n]{0,40}?\n\s*(\d{10,12})\b', text)
    if m:
        return m.group(1)
    return None




def _parse_wide_table(file_path: Path) -> Optional[dict]:
    """v2.28：用 pdfplumber.extract_tables() 解析「橫式超寬表格」
    
    適用：保誠保戶服務名冊、保誠新美滿相傳外幣終身壽險清單 等
    這類 PDF 用 extract_text 會把字打散（一字一行），但表格結構是清楚的
    
    回傳 dict：{name, policy, doctype} 任一可能為 None
    """
    if not PDFPLUMBER_AVAILABLE:
        return None
    try:
        import pdfplumber
        result = {'name': None, 'policy': None, 'doctype': None}
        
        with pdfplumber.open(file_path) as p:
            for page in p.pages[:2]:  # 只看前兩頁
                tables = page.extract_tables()
                if not tables:
                    continue
                
                for table in tables:
                    if len(table) < 2:
                        continue
                    # v2.28.9 #25：處理宏泰雙行表頭（合併前 2 列）
                    header_cells = list(table[0])
                    data_row_idx = 1
                    if len(table) >= 3:
                        row2 = table[1]
                        # 若第 2 列含中文且無年月日數字，視為續表頭
                        is_header2 = all(
                            (not c) or (re.search(r'[一-鿿]', c) and not re.search(r'\d{3,}', c))
                            for c in row2 if c
                        )
                        if is_header2:
                            header_cells = [
                                (a or '') + (b or '')
                                for a, b in zip(table[0], row2)
                            ]
                            data_row_idx = 2
                    header = header_cells
                    data = table[data_row_idx] if data_row_idx < len(table) else []
                    
                    # 清掉表頭裡的 \n 和空白，做關鍵字比對
                    def _clean(c):
                        return re.sub(r'\s+', '', c or '')
                    
                    cleaned_header = [_clean(h) for h in header]
                    
                    # v2.28.9 #4/#26：擴展被保人欄位別名（被保人/主被保人/被保險人）
                    name_idx = None
                    policy_idx = None
                    doctype_idx = None
                    NAME_HEADERS = ('被保人姓名', '主被保險人', '被保險人姓名', '主被保人姓名',
                                    '主被保人', '被保險人', '被保人')
                    POLICY_HEADERS = ('續保保單號碼', '保單號碼', '保單號')
                    # v2.28.10：擴展 doctype 欄位（台灣 RL037「新契約/保服/理賠」+ 富邦處理狀態）
                    DOCTYPE_HEADERS = ('新契約/保服/理賠', '處理狀態', '商品中文名稱', '商品名稱', '主約險種',
                                       '新契約保服理賠', '案件類型')
                    for i, h in enumerate(cleaned_header):
                        if not h: continue
                        if name_idx is None:
                            for kw in NAME_HEADERS:
                                if kw in h:
                                    name_idx = i
                                    break
                        if policy_idx is None:
                            for kw in POLICY_HEADERS:
                                if kw in h:
                                    policy_idx = i
                                    break
                        if doctype_idx is None:
                            for kw in DOCTYPE_HEADERS:
                                if kw in h:
                                    doctype_idx = i
                                    break
                    
                    if name_idx is not None and name_idx < len(data):
                        raw = data[name_idx]
                        if raw:
                            cleaned = _clean(raw)
                            # 驗證：純中文 2-4 字
                            if re.fullmatch(r'[\u4e00-\u9fff\uf900-\ufaff\*Ｏ○]{2,4}', cleaned):
                                if cleaned not in ('鼎綸恩宇', '恩宇', '鼎綸'):
                                    result['name'] = cleaned
                    
                    if policy_idx is not None and policy_idx < len(data):
                        raw = data[policy_idx]
                        if raw:
                            cleaned = _clean(raw)
                            # v2.28.9 #24：接受 10-12 碼純數字（宏泰簽收表格式）
                            if re.fullmatch(r'[A-Z]{0,5}\d{6,15}', cleaned) or re.fullmatch(r'\d{10,12}', cleaned):
                                result['policy'] = cleaned
                    
                    if doctype_idx is not None and doctype_idx < len(data):
                        raw = data[doctype_idx]
                        if raw:
                            cleaned = _clean(raw)
                            # 清掉常見後綴雜訊
                            cleaned = re.sub(r'\([^)]*\)$', '', cleaned)
                            cleaned = re.sub(r'（[^）]*）$', '', cleaned)
                            # v2.28.10 #32\uff1a\u62d2\u7d55\u7d14\u82f1\u6578\u4ee3\u865f\uff08\u5982 L001871221, A123, NH0220\uff09
                            if re.fullmatch(r'[A-Z]{1,5}\d+', cleaned) or re.fullmatch(r'\d+', cleaned):
                                pass
                            elif 4 <= len(cleaned) <= 30 and re.search(r'[\u4e00-\u9fff]', cleaned):
                                # v2.28.10\uff1a\u300c\u65b0\u5951\u7d04\u300d\u300c\u4fdd\u670d\u300d\u300c\u7406\u8ce0\u300d\u77ed\u8a5e\u88dc\u5b8c
                                if cleaned in ('\u65b0\u5951\u7d04', '\u4fdd\u670d', '\u7406\u8ce0'):
                                    cleaned = cleaned + '\u7167\u6703'
                                result['doctype'] = cleaned
                            elif 2 <= len(cleaned) <= 4 and cleaned in ('\u65b0\u5951\u7d04', '\u4fdd\u670d', '\u7406\u8ce0'):
                                result['doctype'] = cleaned + '\u7167\u6703'
                    
                    # 一旦抓到至少 1 個欄位就先返回
                    if any(result.values()):
                        return result
        return None
    except Exception:
        return None


def _parse_wide_table_rows(file_path: Path) -> List[Tuple[Optional[str], Optional[str]]]:
    """v2.28.10：用 pdfplumber.extract_tables() 抽出**全部資料列**的 (被保人, 保單號)

    適用：新光無授權書通知（多筆）、台灣 RL037 匯總表（多筆）等寬表格 PDF
    回傳 List[(name, policy)]，每筆對應 1 筆保單
    """
    if not PDFPLUMBER_AVAILABLE:
        return []
    results = []
    seen = set()
    try:
        import pdfplumber
        with pdfplumber.open(file_path) as p:
            for page in p.pages[:3]:
                tables = page.extract_tables()
                if not tables:
                    continue
                for table in tables:
                    if len(table) < 2:
                        continue
                    # 找表頭 + 資料列起點（處理雙行表頭）
                    header_cells = list(table[0])
                    data_start = 1
                    if len(table) >= 3:
                        row2 = table[1]
                        is_header2 = all(
                            (not c) or (re.search(r'[一-鿿]', c) and not re.search(r'\d{3,}', c))
                            for c in row2 if c
                        )
                        if is_header2:
                            header_cells = [(a or '') + (b or '') for a, b in zip(table[0], row2)]
                            data_start = 2

                    def _clean(c):
                        return re.sub(r'\s+', '', c or '')

                    cleaned_header = [_clean(h) for h in header_cells]
                    name_idx = None
                    policy_idx = None
                    NAME_HEADERS = ('被保人姓名', '主被保險人', '被保險人姓名', '主被保人姓名',
                                    '主被保人', '被保險人', '被保人')
                    POLICY_HEADERS = ('續保保單號碼', '保單號碼', '保單號')
                    for i, h in enumerate(cleaned_header):
                        if not h:
                            continue
                        if name_idx is None:
                            for kw in NAME_HEADERS:
                                if kw in h:
                                    name_idx = i
                                    break
                        if policy_idx is None:
                            for kw in POLICY_HEADERS:
                                if kw in h:
                                    policy_idx = i
                                    break

                    if name_idx is None and policy_idx is None:
                        continue

                    # 逐列抽出
                    for row in table[data_start:]:
                        if not row or len(row) <= max(name_idx or 0, policy_idx or 0):
                            continue
                        name = None
                        policy = None
                        if name_idx is not None and name_idx < len(row):
                            raw = row[name_idx]
                            if raw:
                                c = _clean(raw)
                                if re.fullmatch(r'[一-鿿豈-﫿*○Ｏ＊]{2,5}', c):
                                    if c not in ('鼎綸恩宇', '恩宇', '鼎綸'):
                                        name = c
                        if policy_idx is not None and policy_idx < len(row):
                            raw = row[policy_idx]
                            if raw:
                                c = _clean(raw)
                                if re.fullmatch(r'[A-Z]{0,5}\d{6,15}', c) or re.fullmatch(r'\d{10,12}', c):
                                    policy = c
                        if name or policy:
                            key = (name, policy)
                            if key not in seen:
                                seen.add(key)
                                results.append(key)
                    if results:
                        return results
        return results
    except Exception:
        return results


def get_best_date_for_naming(file_path: Path,
                             pdf_text: Optional[str] = None,
                             original_filename: Optional[str] = None,
                             excel_rows: Optional[List[List[str]]] = None) -> str:
    """依優先級找出最適合用於命名的日期，回傳民國年月日字串（YYYMMDD）

    優先級：
    1. PDF 內文「照會日期」
    2. Excel/CSV 內「照會日期」「受理日期」欄
    3. 檔名中的日期（如 20260512）
    4. 原始檔名（如果有傳入 original_filename）中的日期
    5. 檔案修改時間
    6. 今天日期（最後 fallback）
    """
    candidate_dt = None

    # 1. PDF 內文：抓多種日期格式，依優先級
    if pdf_text and not candidate_dt:
        # 先把字間空格清掉
        text_clean = re.sub(r'(?<=[\u4e00-\u9fff\uf900-\ufaff])\s+(?=[\u4e00-\u9fff\uf900-\ufaff])', '', pdf_text)
        # 也把數字間的空格清掉（115 / 04 / 13）
        text_clean = re.sub(r'(?<=\d)\s+(?=\d)', '', text_clean)
        text_clean = re.sub(r'(?<=\d)\s+(?=[/\-年月日])', '', text_clean)
        text_clean = re.sub(r'(?<=[/\-年月日])\s+(?=\d)', '', text_clean)

        # 日期關鍵字優先級（前面的優先）
        # 注意：「製表日期」優先級低，因為它常含時:分:秒；用「照會日期」「處理日」等更精確
        date_keywords = [
            '照會日期',  # 大多數照會單
            '受理日期', '受理日',
            '處理日',    # 宏泰批註保單郵寄一覽表
            '理賠日期',  # 台壽理賠通知書
            '取消日期',  # 宏泰保件取消通知單
            '通知日期',  # 宏泰逾期未取消通知書
            '通知日',    # v2.28.9 #18：全球體檢照會通知單（無「期」字）
            '催辦日期',  # v2.28.9：宏泰催辦
            '製表日期',  # 宏泰各類報表
            '日期',      # 一般日期（如體檢照會單）
        ]
        patterns_with_keyword = []
        for kw in date_keywords:
            patterns_with_keyword.extend([
                # 民國年月日：115年04月13日
                rf'{kw}\s*[:：]\s*(\d{{3}})\s*年\s*(\d{{1,2}})\s*月\s*(\d{{1,2}})\s*日',
                # 民國 / 或 -：115/04/13、115-04-13
                rf'{kw}\s*[:：]\s*(\d{{3}})\s*[/\-]\s*(\d{{1,2}})\s*[/\-]\s*(\d{{1,2}})',
                # 西元年月日：2026-04-13
                rf'{kw}\s*[:：]\s*(20\d{{2}})\s*[/\-]\s*(\d{{1,2}})\s*[/\-]\s*(\d{{1,2}})',
            ])

        for p in patterns_with_keyword:
            m = re.search(p, text_clean)
            if m:
                y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
                if 100 < y < 200:  # 民國年
                    y += 1911
                if 2000 <= y <= 2100 and 1 <= mo <= 12 and 1 <= d <= 31:
                    try:
                        candidate_dt = datetime(y, mo, d)
                        break
                    except ValueError:
                        continue

    # 2. Excel/CSV 表頭抓「照會日期」「受理日期」等欄位
    if excel_rows and not candidate_dt and len(excel_rows) >= 2:
        header = [str(c).strip() for c in excel_rows[0]]
        first_data = excel_rows[1]
        date_idx = None
        # 優先級：照會日期 > 受理日期 > 結案日期 > 起保日
        for keyword in ['照會日期', '受理日期', '結案日期', '起保日']:
            for i, h in enumerate(header):
                if keyword in h:
                    date_idx = i
                    break
            if date_idx is not None:
                break
        if date_idx is not None and date_idx < len(first_data):
            val = str(first_data[date_idx]).strip()
            candidate_dt = _parse_date_string(val)

    # 3. 檔名（傳入的 file_path）中的日期
    if not candidate_dt:
        candidate_dt = extract_date_from_text(file_path.name)

    # 4. 原始檔名（與 file_path 不同時，例如 zip 內檔名）
    if not candidate_dt and original_filename:
        candidate_dt = extract_date_from_text(original_filename)

    # 5. 檔案修改時間
    if not candidate_dt:
        try:
            mtime = file_path.stat().st_mtime
            candidate_dt = datetime.fromtimestamp(mtime)
        except Exception:
            pass

    # 6. 最後 fallback：今天
    if not candidate_dt:
        candidate_dt = datetime.now()

    # 民國年月日（YYYMMDD）
    roc_year = candidate_dt.year - 1911
    return f"{roc_year:03d}{candidate_dt.month:02d}{candidate_dt.day:02d}"


def _parse_date_string(s: str) -> Optional[datetime]:
    """解析各種日期字串：1150512, 20260512, 115/05/12, 2026-05-12 等
    
    民國年（100~200 之間）會自動 +1911 轉成西元
    """
    if not s:
        return None
    s = s.strip()
    # 純數字 7-8 位（民國年 YYYMMDD 或西元 YYYYMMDD）
    m = re.match(r'^(\d{3,4})(\d{2})(\d{2})$', s)
    if m:
        y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if 100 < y < 200:  # 民國年
            y += 1911
        if 2000 <= y <= 2100 and 1 <= mo <= 12 and 1 <= d <= 31:
            try:
                return datetime(y, mo, d)
            except ValueError:
                return None
    # 帶分隔符的 民國/西元 年/月/日
    m = re.match(r'^(\d{3,4})[/\-年](\d{1,2})[/\-月](\d{1,2})[日]?$', s)
    if m:
        y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if 100 < y < 200:
            y += 1911
        if 2000 <= y <= 2100 and 1 <= mo <= 12 and 1 <= d <= 31:
            try:
                return datetime(y, mo, d)
            except ValueError:
                return None
    return None


def build_smart_filename(file_path: Path, company: Optional[str],
                         original_ext: str) -> Optional[str]:
    """根據 PDF 內容組出智慧命名：YYYMMDD-公司-被保險人-文件類型-保單號碼.pdf
    
    回傳 None 表示資訊不足、退回原命名邏輯
    
    company 來源優先級：傳入的 company（從密碼規則辨識）> PDF 內文偵測
    這確保「原台新」「原新光」這類細分能被保留
    """
    if not PDFPLUMBER_AVAILABLE:
        return None

    # 讀 PDF 內容
    text = extract_text_from_pdf(file_path)
    if not text:
        return None

    # 民國年月日（依優先級從多處來源找）
    roc_date = get_best_date_for_naming(file_path, pdf_text=text)

    name = parse_insured_name(text)
    doctype = parse_doctype(text)
    policy = parse_policy_number(text)

    # v2.28：寬表格 fallback（保誠保戶服務名冊類，extract_text 會打散，但 extract_tables 行）
    if not name or doctype == '文件' or not policy:
        wide = _parse_wide_table(file_path)
        if wide:
            if not name and wide.get('name'):
                name = wide['name']
            if (not doctype or doctype == '文件') and wide.get('doctype'):
                doctype = wide['doctype']
            if not policy and wide.get('policy'):
                policy = wide['policy']

    # v2.28.13：多筆清單 fallback — 用 _parse_all_rows_from_list 或 _parse_wide_table_rows 補資料
    # 適用：富邦單位照會明細表（2 筆同檔，但只關心檔名 hint 的那筆）/ 元大保全變更結案 / 凱基理賠結案
    if not name or not policy:
        rows = []
        if text:
            try:
                rows = _parse_all_rows_from_list(text)
            except Exception:
                rows = []
        if not rows:
            try:
                rows = _parse_wide_table_rows(file_path)
            except Exception:
                rows = []
        if rows:
            # 嘗試用「原檔名第 3 段被保人」找匹配
            fname_name_hint = None
            try:
                fparts = file_path.stem.split('-')
                if len(fparts) >= 4 and not fparts[2].startswith('【'):
                    fname_name_hint = fparts[2]
            except Exception:
                pass
            matched = None
            if fname_name_hint:
                for n_, p_ in rows:
                    if n_ and (n_ == fname_name_hint or fname_name_hint == n_):
                        matched = (n_, p_)
                        break
            if not matched:
                # 沒 hint 或對不上 → 取第 1 筆
                matched = rows[0]
            if not name and matched[0]:
                name = matched[0]
            if not policy and matched[1]:
                policy = matched[1]

    # 如果 PDF 內的保單號可能被屏蔽（從原文還含 *），從檔名找完整版補回
    if policy and len(policy) < 8:
        # 看檔名有沒有更長的完整號碼包含這個前綴
        fname = file_path.stem
        for m in re.finditer(r'(\d{8,15})', fname):
            longer = m.group(1)
            if longer.startswith(policy[:4]):
                policy = longer
                break

    # 如果 PDF 完全抓不到保單號，嘗試從檔名前綴抓（如「1114207565_體檢照會單.pdf」）
    if not policy:
        fname = file_path.stem
        # 模式 A: 檔名開頭就是 10 碼數字（宏泰保單號格式）
        m = re.match(r'^(\d{10,12})[_\-\s]', fname)
        if m:
            policy = m.group(1)
        else:
            # 模式 B: 檔名中含「保單號=xxx」「policy=xxx」這種顯式標示
            m = re.search(r'(?:保單號|policy)\s*[=:]\s*([A-Z]{0,5}\d{6,15})', fname, re.IGNORECASE)
            if m:
                policy = m.group(1)
            else:
                # 模式 C: 檔名中有獨立的 10-12 碼數字（避開電話、地址等）
                # 只在「沒有其他長數字」的情況下使用
                numbers = re.findall(r'\b(\d{10,12})\b', fname)
                if len(numbers) == 1:  # 僅 1 個才用，避免誤抓
                    policy = numbers[0]

    # === 公司判斷：「PDF 內文」優先於「密碼規則辨識」===
    # 因為檔名可能含「鼎綸恩宇」這種組織名（非公司名），密碼規則可能誤判
    # PDF 內文中的「XX人壽保險股份有限公司」最權威
    company_from_text = parse_company_from_pdf_text(text)
    if company_from_text:
        company = company_from_text
    elif not company or company in ("無密碼", "手動輸入", "未辨識"):
        # 退而求其次：從 PDF 內文用較寬鬆規則找
        for keyword, comp in [
            ('全球人壽', '全球'), ('凱基人壽', '凱基'), ('新光人壽', '新光'),
            ('台灣人壽', '台灣'), ('富邦人壽', '富邦'), ('宏泰人壽', '宏泰'),  # v2.28.9
            ('元大人壽', '元大'), ('安聯人壽', '安聯'), ('友邦人壽', '友邦'),
            ('保誠人壽', '保誠'), ('法巴人壽', '法巴'), ('安達人壽', '安達'),
            ('台新人壽', '台新'), ('第一金人壽', '第一金'), ('台灣產物', '台灣產物'),
        ]:
            if keyword in text:
                company = comp
                break

    # 最後 fallback：從「檔名」抓公司關鍵字（適用於 PDF 內文很短的清冊類）
    if not company:
        fname = file_path.name
        for keyword, comp in [
            ('凱基', '凱基'), ('宏泰', '宏泰'), ('台灣', '台灣'), ('台壽', '台灣'), ('富邦', '富邦'),  # v2.28.9：台壽→台灣
            ('元大', '元大'), ('安聯', '安聯'), ('保誠', '保誠'), ('全球', '全球'),
            ('新光', '新光'), ('台新', '台新'), ('安達', '安達'), ('法巴', '法巴'),
            ('友邦', '友邦'), ('第一金', '第一金'), ('台灣產物', '台灣產物'),
            # 報表代號 fallback (寬鬆匹配)
            ('RL037', '台灣'), ('VCN0034', '元大'),  # v2.28.9
            ('BR052', '保誠'), ('811D2', '凱基'), ('S830', '安聯'),
            ('Y43R00', '新光'), ('Br052', '保誠'), ('R35', '台新'),
        ]:
            if keyword in fname:
                company = comp
                break

    # 簡化公司名稱
    if company:
        if '原台新' in company:
            company = '台新'
        elif '原新光' in company:
            company = '新光'
        company = company.replace('人壽', '').replace('保險', '').strip()

    # 至少要有公司才用智慧命名（姓名不一定有，清冊類可能沒有）
    if not company:
        return None

    # === 文件種類從檔名 fallback ===
    # 當 PDF 內文抓不到文件種類，但檔名本身就是文件種類時（如「續期應繳保件一覽表.pdf」）
    if not doctype or doctype == '文件':
        fname = file_path.stem
        # 富邦類：「保全照會單」「保全退件單」「結案明細」「單位照會2」「契約變更明細表」
        # 「續期保險費尚未繳費通知」「電子保單已簽收通知」「催告通知」「停效通知明細表」
        # 「非新契約案件結案通知-7L2220」「保單簽收追蹤第一次通知」「承保後電訪清單」
        # 「新契約核保通過通知」
        fname_doctype_map = [
            # 完整匹配的文件種類關鍵字（從長到短，優先匹配長的）
            ('非新契約案件結案通知', '非新契約案件結案通知'),
            ('保險費授權變更之保單已停效或自動墊繳通知', '保險費授權變更之保單已停效或自動墊繳通知'),
            ('續期保險費尚未繳費通知', '續期保險費尚未繳費通知'),
            ('富邦人壽紙本保單以電子方式簽收之完成簽收通知', '紙本保單以電子方式簽收之完成簽收通知'),
            ('富邦人壽客戶通知連續寄發失敗3次', '客戶通知連續寄發失敗3次以上之通知單'),
            ('富邦人壽核保通過暨電子保單發單', '核保通過暨電子保單發單通知'),
            ('保單簽收追蹤第一次通知', '保單簽收追蹤第一次通知'),
            ('契約變更補費扣款通知', '契約變更補費扣款通知'),
            ('富邦人壽續期應繳保件一覽表', '續期應繳保件一覽表'),
            ('富邦人壽催告通知', '催告通知'),
            ('新契約核保通過通知', '新契約核保通過通知'),
            ('保險金理賠給付通知書', '保險金理賠給付通知書'),
            ('保險費自動扣款約定銀行核驗結果通知書', '保險費自動扣款約定銀行核驗結果通知書'),
            ('電子保單簽收回條回執日明細表', '電子保單簽收回條回執日明細表'),
            ('保全照會單', '保全照會單'),
            ('保全退件單', '保全退件單'),
            ('契約變更明細表', '契約變更明細表'),
            ('電子保單已簽收通知', '電子保單已簽收通知'),
            ('停效通知明細表', '停效通知明細表'),
            ('承保後電訪清單', '承保後電訪清單'),
            ('結案明細', '結案明細'),
            # v2.28.13 新增 ↓
            ('富邦人壽單位照會明細表', '富邦人壽單位照會明細表'),
            ('單位照會明細表', '單位照會明細表'),
            ('續期應繳保件一覽表', '續期應繳保件一覽表'),
            ('核保照會催辦通知', '核保照會催辦通知'),
            ('理賠結案通知', '理賠結案通知'),
            ('電子保單發單明細', '電子保單發單明細'),
            ('保費扣款失敗通知', '保費扣款失敗通知'),
            ('電子保單簽收回條回執日明細表', '電子保單簽收回條回執日明細表'),
            ('一年期個人傷害險到期通知明細表', '一年期個人傷害險到期通知明細表'),
            ('單位照會2', '單位照會'),
            ('單位照會', '單位照會'),
            # 富邦理賠類
            ('理賠通知單', '理賠通知單'),
            ('理賠照會單', '理賠照會單'),
            ('給付通知書', '保險給付通知書'),
            # 一般類
            ('核保照會單', '核保照會單'),
            ('核保通知單', '核保通知單'),
        ]
        for keyword, dt in fname_doctype_map:
            if keyword in fname:
                doctype = dt
                break

    # v2.28.13：原檔名 doctype 優先級保護
    # 場景：PDF 內文有多個「XX管理報表」「XX通知書」之類爛標題，但原檔名第 4 段才是真正 doctype
    try:
        _orig_parts = file_path.stem.split('-')
        if len(_orig_parts) >= 4:
            _orig_dt = _orig_parts[3]
            # 排除：含【缺】、_更新版、純報表代號（L001861822/VVCN000103）、純數字、保單號等
            if (_orig_dt and 
                '【缺' not in _orig_dt and 
                '_更新版' not in _orig_dt and
                not re.match(r'^[A-Z]{1,5}\d{4,}', _orig_dt) and
                not re.match(r'^\d{4,}', _orig_dt) and
                len(_orig_dt) >= 3):
                # 若新抓 doctype 是「次要標題」（如安達 PDF 標題是『保單簽收管理報表』，但檔名是『保費扣款失敗通知』），用原檔名
                _bad_doctypes = ('保單簽收管理報表', '非結構債現金配息日報表', '文件', '保戶服務通知書')
                if doctype in _bad_doctypes:
                    doctype = _orig_dt
                # 或：新抓的是 None / 空字串，用原檔名
                elif not doctype:
                    doctype = _orig_dt
    except Exception:
        pass

    # === 缺失欄位以「【需手動】」標記，方便使用者一眼看出要補資料 ===
    # 注意：「【】」這對全形括號在 Windows 檔名是合法的

    # 1. 日期：如果是用「今天」當 fallback，標記
    if _is_date_from_today_fallback(roc_date, text, file_path):
        roc_date = f"{roc_date}【日期需確認】"

    # 特殊狀況：「當日無數據/無照會事項」（清冊類沒任何資料）
    is_empty_list = (not name and not policy and
                     bool(re.search(r'本日無數據|本日無資料|當日無照會|當日無資料|無\s*資料|無\s*照會事項', text or '')))

    parts = [roc_date, sanitize_filename(company)]

    if is_empty_list:
        parts.append('當日無照會事項')
    else:
        # 2. 被保人
        if name:
            parts.append(sanitize_filename(name))
        else:
            parts.append('【缺被保人】')

        # 3. 文件種類
        if doctype and doctype != '文件':
            parts.append(sanitize_filename(doctype))
        else:
            parts.append('【缺文件種類】')

        # 4. 保單號（v2.28.9：用 sanitize_policy 保留屏蔽長度）
        if policy:
            parts.append(sanitize_policy(policy))
        else:
            parts.append('【缺保單號】')

    base = '-'.join(parts)
    return f"{base}{original_ext}"


def _is_date_from_today_fallback(roc_date: str, pdf_text: Optional[str],
                                  file_path: Path) -> bool:
    """判斷「日期」是否是用「今天」當 fallback 而非從來源真實抓到的

    回傳 True 表示日期值得懷疑（需手動確認）
    """
    if not roc_date:
        return True

    from datetime import datetime
    today = datetime.now()
    today_roc = f"{today.year - 1911:03d}{today.month:02d}{today.day:02d}"

    # 如果命名日期 ≠ 今天，肯定不是 fallback
    if roc_date != today_roc:
        return False

    # 是今天 — 看是否能從來源「真的抓到」今天日期
    # 1. PDF 內文有沒有今天的日期？
    if pdf_text:
        today_patterns = [
            f"{today.year - 1911}年{today.month:02d}月{today.day:02d}日",
            f"{today.year - 1911}/{today.month:02d}/{today.day:02d}",
            f"{today.year}-{today.month:02d}-{today.day:02d}",
            today_roc,  # 純數字
        ]
        text_clean = re.sub(r'\s+', '', pdf_text)
        if any(p.replace('/', '').replace('-', '').replace('年', '').replace('月', '').replace('日', '') in
               text_clean.replace('/', '').replace('-', '').replace('年', '').replace('月', '').replace('日', '')
               for p in today_patterns):
            return False

    # 2. 檔名有沒有日期關鍵字？
    fname = file_path.name
    if re.search(r'\d{8}|\d{3}[/\-]\d{1,2}[/\-]\d{1,2}|1\d{6}', fname):
        return False

    # 3. 檔案修改時間是不是今天？
    try:
        mtime = datetime.fromtimestamp(file_path.stat().st_mtime)
        if mtime.date() == today.date():
            return False
    except Exception:
        pass

    # 都沒找到 → 真的是 fallback
    return True


def _cross_reference_policy(target_dir: Path, return_map: bool = False):
    """跨檔交叉比對：從同資料夾的「簽收表/清冊」反查【缺保單號】的檔案

    例：簽收表 1150511-宏泰-簡嘉均-新契約照會簽收表-1114207565.pdf 已有完整資訊
        其他同資料夾的「1150515-宏泰-簡嘉均-核保通知單-【缺保單號】.pdf」
        (日期 5/15 是 fallback 來的，不是真正日期)
        可以反查補回保單號 + 修正日期 → 1150511-宏泰-簡嘉均-核保通知單-1114207565.pdf

    比對規則：
    1. 嚴格模式：(日期, 被保人) 都相同 → 直接補保單號
    2. 寬鬆模式：(被保人) 相同，但缺保單號方檔案日期 ±7 天 → 修正日期 + 補保單號

    回傳：
    - return_map=False (預設)：成功補回保單號的檔案數 (int)
    - return_map=True：(成功數, {舊檔名: 新檔名})
    """
    if not target_dir.is_dir():
        if return_map:
            return 0, {}
        return 0
    import datetime

    # 建立查找表：(日期, 被保人) → 保單號  和  被保人 → [(日期, 保單號)]
    lookup_strict = {}  # {(date, name): policy}
    lookup_by_name = {}  # {name: [(date, policy)]}
    # v2.28：反向查找（缺被保人 / 缺日期時用）
    lookup_by_policy = {}  # {policy: [(date, name)]}

    # 智慧命名格式正則：「日期-公司-被保人-文件種類-保單號.pdf」
    smart_name_pattern = re.compile(
        r'^(\d{7})-([^-]+)-([^-]+)-(.+)-([A-Z]{0,5}\d{6,15})\.(pdf|PDF)$'
    )

    # 1. 蒐集所有「有完整保單號」的檔案
    for pdf_file in list(target_dir.glob('*.pdf')) + list(target_dir.glob('*.PDF')):
        m = smart_name_pattern.match(pdf_file.name)
        if not m:
            continue
        date_str = m.group(1)
        name = m.group(3)
        policy = m.group(5)
        if name.startswith('【') or '缺' in name:
            continue
        key = (date_str, name)
        if key not in lookup_strict:
            lookup_strict[key] = policy
        lookup_by_name.setdefault(name, []).append((date_str, policy))
        # v2.28：建立 policy → name 反查表
        lookup_by_policy.setdefault(policy, []).append((date_str, name))

    if not lookup_strict and not lookup_by_policy:
        return (0, {}) if return_map else 0

    # 2. 找「【缺保單號】」的檔案，反查補上
    missing_pattern = re.compile(
        r'^(\d{7}(?:【日期需確認】)?)-([^-]+)-([^-]+)-(.+)-【缺保單號】\.(pdf|PDF)$'
    )

    def _date_diff_days(d1: str, d2: str) -> int:
        """兩個民國年月日字串相差天數"""
        try:
            # 去掉「【日期需確認】」標記
            d1 = re.sub(r'【.*?】', '', d1)
            d2 = re.sub(r'【.*?】', '', d2)
            y1, m1, day1 = int(d1[:3]) + 1911, int(d1[3:5]), int(d1[5:7])
            y2, m2, day2 = int(d2[:3]) + 1911, int(d2[3:5]), int(d2[5:7])
            return abs((datetime.date(y1, m1, day1) - datetime.date(y2, m2, day2)).days)
        except Exception:
            return 999

    fix_count = 0
    rename_map = {}  # 紀錄 {舊檔名: 新檔名}
    for pdf_file in list(target_dir.glob('*.pdf')) + list(target_dir.glob('*.PDF')):
        m = missing_pattern.match(pdf_file.name)
        if not m:
            continue
        date_str_raw = m.group(1)
        company = m.group(2)
        name = m.group(3)
        doctype = m.group(4)
        ext = m.group(5)

        if name.startswith('【') or '缺' in name:
            continue

        # 取出純日期（去掉【日期需確認】標記）
        date_str_pure = re.sub(r'【.*?】', '', date_str_raw)
        date_is_uncertain = '【日期需確認】' in date_str_raw

        # 嚴格模式：日期+被保人完全相符
        key = (date_str_pure, name)
        matched_date = None
        matched_policy = None

        if key in lookup_strict:
            matched_date = date_str_pure
            matched_policy = lookup_strict[key]
        elif name in lookup_by_name:
            # 寬鬆模式：被保人相符，找最近日期
            # 如果原本日期不確定，放寬到 14 天；若確定則限 7 天
            max_days = 30 if date_is_uncertain else 7
            best = None
            best_diff = max_days + 1
            for cand_date, cand_policy in lookup_by_name[name]:
                diff = _date_diff_days(cand_date, date_str_pure)
                if diff < best_diff:
                    best = (cand_date, cand_policy)
                    best_diff = diff
            if best:
                matched_date = best[0]
                matched_policy = best[1]

        if not matched_date:
            continue

        # 改名：用簽收表的日期 + 補上保單號
        new_name = f"{matched_date}-{company}-{name}-{doctype}-{matched_policy}.{ext}"
        new_path = pdf_file.parent / new_name

        # 如果目標檔已存在，看是否同一檔（大小相同就視為重複，刪除這個就好）
        if new_path.exists():
            try:
                if new_path.stat().st_size == pdf_file.stat().st_size:
                    # 內容相同，刪除這個重複的
                    old_name = pdf_file.name
                    pdf_file.unlink()
                    fix_count += 1
                    rename_map[old_name] = new_path.name  # 改名對照 (此檔已刪，指向已存在的目標)
                    write_log(f"跨檔去重 | 刪除重複: {old_name}")
                    continue
                else:
                    # 不同內容，加序號後綴
                    counter = 2
                    while True:
                        alt_name = f"{matched_date}-{company}-{name}-{doctype}-{matched_policy}_{counter}.{ext}"
                        alt_path = pdf_file.parent / alt_name
                        if not alt_path.exists():
                            new_path = alt_path
                            new_name = alt_name
                            break
                        counter += 1
                        if counter > 20:
                            break
            except Exception:
                continue

        try:
            old_name = pdf_file.name
            pdf_file.rename(new_path)
            fix_count += 1
            rename_map[old_name] = new_path.name
            write_log(f"跨檔補保單號 | {old_name} → {new_name}")
        except Exception as e:
            write_log(f"跨檔補保單號失敗 | {pdf_file.name}: {e}")

    # ===== v2.28：第三輪反查 — 用「保單號」反查【缺被保人】 =====
    # 適用：凱基核保通知書 / 新契約照會催辦單 等圖層 PDF（抓不到被保人）
    # 命名格式：「日期-公司-【缺被保人】-文件種類-保單號.pdf」
    missing_name_pattern = re.compile(
        r'^(\d{7}(?:【日期需確認】)?)-([^-]+)-【缺被保人】-(.+)-([A-Z]{0,5}\d{6,15})\.(pdf|PDF)$'
    )
    for pdf_file in list(target_dir.glob('*.pdf')) + list(target_dir.glob('*.PDF')):
        m = missing_name_pattern.match(pdf_file.name)
        if not m:
            continue
        date_str_raw = m.group(1)
        company = m.group(2)
        doctype = m.group(3)
        policy = m.group(4)
        ext = m.group(5)

        if policy not in lookup_by_policy:
            continue

        # 取出純日期
        date_str_pure = re.sub(r'【.*?】', '', date_str_raw)
        date_is_uncertain = '【日期需確認】' in date_str_raw

        # 從候選中挑被保人（同保單號通常只對應 1 個被保人）
        candidates = lookup_by_policy[policy]
        # 優先挑日期相近的
        best = None
        best_diff = 999
        for cand_date, cand_name in candidates:
            diff = _date_diff_days(cand_date, date_str_pure)
            if diff < best_diff:
                best = (cand_date, cand_name)
                best_diff = diff

        if not best:
            continue

        matched_date, matched_name = best
        # 若原本日期不確定，用簽收表日期；否則保留原日期
        final_date = matched_date if date_is_uncertain else date_str_pure
        new_name = f"{final_date}-{company}-{matched_name}-{doctype}-{policy}.{ext}"
        new_path = pdf_file.parent / new_name

        if new_path.exists():
            try:
                if new_path.stat().st_size == pdf_file.stat().st_size:
                    old_name = pdf_file.name
                    pdf_file.unlink()
                    fix_count += 1
                    rename_map[old_name] = new_path.name
                    write_log(f"跨檔去重 | 刪除重複: {old_name}")
                    continue
                else:
                    counter = 2
                    while True:
                        alt_name = f"{final_date}-{company}-{matched_name}-{doctype}-{policy}_{counter}.{ext}"
                        alt_path = pdf_file.parent / alt_name
                        if not alt_path.exists():
                            new_path = alt_path
                            new_name = alt_name
                            break
                        counter += 1
                        if counter > 20:
                            break
            except Exception:
                continue

        try:
            old_name = pdf_file.name
            pdf_file.rename(new_path)
            fix_count += 1
            rename_map[old_name] = new_path.name
            write_log(f"跨檔補被保人 | {old_name} → {new_name}")
        except Exception as e:
            write_log(f"跨檔補被保人失敗 | {pdf_file.name}: {e}")

    if return_map:
        return fix_count, rename_map
    return fix_count


def _try_split_list_pdf(pdf_path: Path) -> int:
    """嘗試把「清冊類」PDF 拆分為多份（每筆保單一份）

    拆分條件：
    1. 必須是 PDF
    2. PDF 含 >= 2 筆 (被保人, 保單號) 配對（用 _parse_all_rows_from_list）
    3. 檔名是「日期-公司-...-文件種類-保單號」格式（已智慧命名）

    回傳拆分出來的份數（不含原檔）；如不拆則回傳 0
    拆分後會：
    - 為每筆建立一份「日期-公司-被保人-文件種類-保單號.pdf」
    - 刪除原檔（避免重複/混淆）
    - 內容完全複製原檔
    """
    if not PDFPLUMBER_AVAILABLE:
        return 0
    try:
        text = extract_text_from_pdf(pdf_path)
        if not text:
            return 0

        # 抽出所有 (被保人, 保單號) 配對
        rows = _parse_all_rows_from_list(text)

        # v2.28.10：若文字 pattern 抓不到，試用 pdfplumber.extract_tables() 多列解析
        # 適用新光無授權書通知 / 台灣 RL037 匯總 等寬表格
        if len(rows) < 1:
            rows = _parse_wide_table_rows(pdf_path)

        if len(rows) < 1:
            return 0

        # 看原檔名能拆出哪些部分
        stem = pdf_path.stem
        # 期待格式：「日期-公司-...-文件種類-保單號」或「日期-公司-...-文件種類-【缺保單號】」
        parts = stem.split('-')
        if len(parts) < 4:
            return 0  # 不是智慧命名格式

        # 抓「日期」「公司」「文件種類」
        date_str = parts[0]
        company = parts[1]

        # 文件種類：倒數第二個（如果最後是【缺保單號】或保單號）
        # 或最後一個（如果最後是文件種類本身）
        last = parts[-1]
        if last.startswith('【缺') or re.match(r'^[A-Z]?\d{6,}$', last):
            doctype = parts[-2] if len(parts) >= 3 else None
        else:
            doctype = last

        if not doctype:
            return 0

        # 不拆的文件種類（這些本來就是「1個保戶 多文件」或單一文件）
        no_split_doctypes = ['新契約照會簽收表', '體檢照會單', '核保通知單',
                             '核保照會單', '理賠照會單', '保險金理賠通知書',
                             '逾期未取消通知書', '保件取消通知單',
                             '新契約照會逾期通知書', '幼童問卷', '通用疾病問卷']
        if doctype in no_split_doctypes:
            return 0

        # 判斷檔名是否含【缺】（決定 1 筆時要不要補名）
        has_missing = '【缺' in stem

        # 1 筆且檔名沒缺 → 無需動作
        if len(rows) == 1 and not has_missing:
            return 0

        # 開始拆分：為每筆 (name, policy) 建立一份檔案
        import shutil
        split_count = 0
        for name, policy in rows:
            # 構造新檔名
            safe_name = sanitize_filename(name) if name else '【缺被保人】'
            safe_policy = sanitize_policy(policy) if policy else '【缺保單號】'  # v2.28.9
            new_filename = f"{date_str}-{company}-{safe_name}-{doctype}-{safe_policy}.pdf"
            new_path = pdf_path.parent / new_filename

            # 避免覆蓋現有檔案
            if new_path.exists() and new_path != pdf_path:
                continue

            # 複製檔案
            try:
                if new_path != pdf_path:
                    shutil.copy2(pdf_path, new_path)
                    split_count += 1
            except Exception as e:
                write_log(f"拆分時複製失敗 {new_filename}: {e}")
                continue

        # 拆分成功就刪除原檔
        if split_count > 0:
            try:
                pdf_path.unlink()
            except Exception:
                pass

        return split_count
    except Exception as e:
        write_log(f"_try_split_list_pdf 失敗 {pdf_path.name}: {e}")
        return 0


# ============ Excel 處理 ============
def is_excel_encrypted(file_path: Path) -> bool:
    try:
        with open(file_path, 'rb') as f:
            return msoffcrypto.OfficeFile(f).is_encrypted()
    except Exception:
        return False


def crack_excel(input_path: Path, output_path: Path, password: str) -> bool:
    try:
        with open(input_path, 'rb') as f:
            office_file = msoffcrypto.OfficeFile(f)
            if not office_file.is_encrypted():
                shutil.copy2(input_path, output_path)
                return True
            office_file.load_key(password=password)
            with open(output_path, 'wb') as out:
                office_file.decrypt(out)
        return True
    except (msoffcrypto.exceptions.InvalidKeyError,
            msoffcrypto.exceptions.DecryptionError):
        return False
    except Exception as e:
        write_log(f"Excel 破解錯誤 {input_path.name}: {e}")
        return False


def _read_excel_data(excel_path: Path) -> Optional[List[List[str]]]:
    """通用 Excel/CSV 讀取：支援 .xlsx/.xlsm、.xls、.csv

    回傳資料的二維陣列，每格都是字串；讀失敗或空檔回 None
    """
    suffix = excel_path.suffix.lower()
    data = []

    # === CSV 處理 ===
    if suffix == '.csv':
        return _read_csv(excel_path)

    # 先看真實檔頭判斷格式（副檔名可能寫錯）
    real_format = None
    try:
        with open(excel_path, 'rb') as f:
            head = f.read(8)
        if head[:4] == b'PK\x03\x04':
            real_format = 'xlsx'  # ZIP/XLSX 格式
        elif head[:4] == b'\xd0\xcf\x11\xe0':
            real_format = 'xls'   # OLE/XLS 格式
    except Exception:
        pass

    # 依「真實格式」優先決定讀法，副檔名只當作備援判斷
    if real_format == 'xlsx' or (real_format is None and suffix in ('.xlsx', '.xlsm')):
        if not EXCEL_TO_PDF_AVAILABLE:
            return None
        try:
            wb = openpyxl.load_workbook(str(excel_path), data_only=True)
            ws = wb.active
            for row in ws.iter_rows(values_only=True):
                if all(c is None or str(c).strip() == '' for c in row):
                    continue
                data.append([str(c) if c is not None else '' for c in row])
        except Exception as e:
            write_log(f"openpyxl 讀失敗 {excel_path.name}: {e}")
            # openpyxl 失敗就試 xlrd（可能是檔頭騙人的）
            if XLRD_AVAILABLE:
                return _read_with_xlrd(excel_path)
            return None

    elif real_format == 'xls' or (real_format is None and suffix == '.xls'):
        if not XLRD_AVAILABLE:
            return None
        result = _read_with_xlrd(excel_path)
        if result is None and EXCEL_TO_PDF_AVAILABLE:
            # xlrd 失敗就試 openpyxl
            try:
                wb = openpyxl.load_workbook(str(excel_path), data_only=True)
                ws = wb.active
                for row in ws.iter_rows(values_only=True):
                    if all(c is None or str(c).strip() == '' for c in row):
                        continue
                    data.append([str(c) if c is not None else '' for c in row])
            except Exception:
                return None
        else:
            return result
    else:
        return None

    return data if data else None


def _read_with_xlrd(excel_path: Path) -> Optional[List[List[str]]]:
    """純 xlrd 讀取"""
    if not XLRD_AVAILABLE:
        return None
    data = []
    try:
        wb = xlrd.open_workbook(str(excel_path))
        ws = wb.sheet_by_index(0)
        for row_idx in range(ws.nrows):
            row = [ws.cell_value(row_idx, c) for c in range(ws.ncols)]
            if all(str(c).strip() == '' for c in row):
                continue
            row_str = []
            for c in row:
                if isinstance(c, float) and c.is_integer():
                    row_str.append(str(int(c)))
                else:
                    row_str.append(str(c))
            data.append(row_str)
        return data if data else None
    except Exception as e:
        write_log(f"xlrd 讀失敗 {excel_path.name}: {e}")
        return None


def _read_csv(csv_path: Path) -> Optional[List[List[str]]]:
    """讀取 CSV 檔，自動偵測編碼（big5/utf-8/cp950 等）和分隔符號"""
    import csv as csv_module

    # 嘗試多種編碼（保險公司 CSV 常用 big5）
    encodings_to_try = ['utf-8-sig', 'utf-8', 'big5', 'cp950', 'gbk', 'latin1']
    text = None
    for encoding in encodings_to_try:
        try:
            with open(csv_path, 'r', encoding=encoding) as f:
                text = f.read()
            # 簡單驗證：含中文或常見英文字母
            if text and (re.search(r'[\u4e00-\u9fff\uf900-\ufaff]', text) or text.isascii()):
                break
        except (UnicodeDecodeError, UnicodeError):
            continue

    if text is None:
        write_log(f"CSV 編碼偵測失敗 {csv_path.name}")
        return None

    # 偵測分隔符號（保險公司多用逗號）
    delimiter = ','
    if '\t' in text and text.count('\t') > text.count(','):
        delimiter = '\t'

    try:
        # 處理 BOM 與奇怪的空白
        import io
        reader = csv_module.reader(io.StringIO(text), delimiter=delimiter)
        data = []
        for row in reader:
            # 跳過全空行
            if all(c.strip() == '' for c in row):
                continue
            # 去掉值前後的單引號（保險公司 CSV 常用 '811D2 這種防 Excel 自動轉數字格式）
            cleaned = [c.strip().lstrip("'") for c in row]
            data.append(cleaned)
        return data if data else None
    except Exception as e:
        write_log(f"CSV 解析失敗 {csv_path.name}: {e}")
        return None


def excel_to_pdf(xlsx_path: Path, pdf_path: Path, title: str = "") -> bool:
    """把 Excel 轉成橫式 PDF，內容壓在同一頁，自動調整欄寬
    支援 .xlsx / .xlsm / .xls 三種格式

    回傳 True 表示成功，False 表示失敗（需要套件未安裝或檔案格式不支援）
    """
    if not EXCEL_TO_PDF_AVAILABLE:
        return False

    data = _read_excel_data(xlsx_path)
    if not data:
        return False

    try:
        max_cols = max(len(r) for r in data)
        for r in data:
            while len(r) < max_cols:
                r.append('')

        # === 刪除「整欄都是空值」的欄位（讓畫面更寬鬆）===
        # 規則：除了表頭以外，所有資料列都是空字串/星號 → 整欄刪除
        if len(data) >= 2:
            cols_to_keep = []
            for col_idx in range(max_cols):
                # 看資料列（不含表頭）這一欄是不是全空
                values = [data[row_idx][col_idx].strip()
                          for row_idx in range(1, len(data))]
                is_empty = all(v == '' or v == '*' for v in values)
                if not is_empty:
                    cols_to_keep.append(col_idx)
            # 重組 data 只保留有資料的欄
            if len(cols_to_keep) < max_cols:
                data = [[row[i] for i in cols_to_keep] for row in data]
                max_cols = len(cols_to_keep)
                write_log(f"已自動刪除 {len(cols_to_keep)} 個非空欄之外的空欄")

        # 計算每欄所需寬度（中文每字 ~10pt，英文 ~6pt）
        col_widths_text = [0] * max_cols
        for row in data:
            for i, cell in enumerate(row):
                w = sum(10 if ord(c) > 127 else 6 for c in str(cell))
                col_widths_text[i] = max(col_widths_text[i], w)
        # 加上 padding，設定最小寬度
        col_widths = [max(w + 8, 25) for w in col_widths_text]

        # A4 橫式可用寬度 = 842pt - 2*30pt 邊界
        page_width = landscape(A4)[0] - 60

        # 限制單欄最大寬度（不超過總頁寬的 30%，避免極長內容把其他欄擠扁）
        max_single_col = page_width * 0.30
        col_widths = [min(w, max_single_col) for w in col_widths]

        total_w = sum(col_widths)

        # 等比例縮放讓所有欄壓在一頁寬度內
        if total_w > page_width:
            scale = page_width / total_w
            col_widths = [w * scale for w in col_widths]

        # 確保每欄至少有 25pt（不會出現負寬度）
        col_widths = [max(w, 25) for w in col_widths]

        # 建立 PDF
        doc = SimpleDocTemplate(str(pdf_path), pagesize=landscape(A4),
                                leftMargin=30, rightMargin=30,
                                topMargin=30, bottomMargin=30)

        cell_style = ParagraphStyle('cell', fontName='STSong-Light', fontSize=8,
                                    leading=10, alignment=1)

        # 用 Paragraph 包裝每格，讓文字能自動換行
        wrapped_data = []
        for row in data:
            wrapped_row = [Paragraph(str(cell), cell_style) for cell in row]
            wrapped_data.append(wrapped_row)

        elements = []
        if title:
            title_style = ParagraphStyle('title', fontName='STSong-Light',
                                         fontSize=14, alignment=1, spaceAfter=10)
            elements.append(Paragraph(title, title_style))

        table = Table(wrapped_data, colWidths=col_widths, repeatRows=1)
        table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), rl_colors.lightgrey),
            ('GRID', (0, 0), (-1, -1), 0.5, rl_colors.black),
            ('FONTNAME', (0, 0), (-1, -1), 'STSong-Light'),
            ('FONTSIZE', (0, 0), (-1, -1), 8),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('TOPPADDING', (0, 0), (-1, -1), 4),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 4),
        ]))
        elements.append(table)
        doc.build(elements)
        return True
    except Exception as e:
        write_log(f"Excel 轉 PDF 失敗 {xlsx_path.name}: {e}")
        return False


def build_smart_filename_from_excel(xlsx_path: Path, company: Optional[str],
                                    original_filename: str) -> Optional[str]:
    """從 Excel 內容組智慧檔名。
    
    從第一筆資料抓被保險人；文件類型用「原檔名」推斷（因為 Excel 通常沒標題）
    """
    if not EXCEL_TO_PDF_AVAILABLE:
        return None

    try:
        # 通用讀取（支援 .xlsx / .xls / .csv）
        rows = _read_excel_data(xlsx_path)
        if not rows:
            return None

        # 取得日期（依優先級從多處找）
        roc_date = get_best_date_for_naming(
            xlsx_path,
            original_filename=original_filename,
            excel_rows=rows
        )

        header = rows[0]
        # 找欄位 index
        name_idx = None
        policy_idx = None
        report_id_idx = None  # 報表編號（如凱基 C26）
        change_item_idx = None  # 變更項目（凱基保全變更的具體類型）
        for i, h in enumerate(header):
            if '被保險人' in h or '被保險' in h or '被保人' in h:
                name_idx = i
            elif '保單號碼' in h or '保單號' in h:
                policy_idx = i
            elif '報表編號' in h or '報表代號' in h:
                report_id_idx = i
            elif '變更項目' in h:
                change_item_idx = i

        # 從第一筆資料抓（沒有資料列也沒關係，留空）
        first_data = rows[1] if len(rows) > 1 else None
        name = None
        policy = None
        report_id = None
        change_items = None
        if first_data:
            if name_idx is not None and name_idx < len(first_data) and first_data[name_idx]:
                raw_name = str(first_data[name_idx]).strip()
                # 驗證：必須是中文姓名（2-4 字純中文），不能是身分證號碼、業務員代號等
                # 排除：純數字（如 620530）、英數混合（如 H224326163）
                if re.fullmatch(r'[\u4e00-\u9fff\uf900-\ufaff＊*Ｏ]{2,4}', raw_name):
                    name = raw_name
                # 否則保留 None,讓後續標記【缺被保人】
            if policy_idx is not None and policy_idx < len(first_data) and first_data[policy_idx]:
                policy = str(first_data[policy_idx]).strip()
            if report_id_idx is not None and report_id_idx < len(first_data) and first_data[report_id_idx]:
                report_id = str(first_data[report_id_idx]).strip()
            if change_item_idx is not None and change_item_idx < len(first_data) and first_data[change_item_idx]:
                change_items = str(first_data[change_item_idx]).strip()

        # === 決定文件種類，優先級：變更項目 > 原檔名 > 報表編號 ===
        doctype = None
        # 1. 凱基保全變更：用「變更項目」代號翻譯（如 28 = 保單借款）
        if change_items:
            translated = _translate_kgi_change_items(change_items)
            if translated:
                doctype = translated
        # 2. 從檔名抓
        if not doctype:
            doctype = _extract_doctype_from_filename(original_filename)
        # 3. 檔名抓不到（變「文件」），用報表編號 fallback（如台壽 RL037 → 新契約照會清單）
        if doctype == '文件' and report_id:
            doctype = _translate_report_code(report_id)
        # 4. 還抓不到 → 從原檔名直接找報表代號（如 DEL_144005.xls → DEL → 保費扣款失敗通知）
        if doctype == '文件':
            doctype = _translate_report_code(original_filename)

        # 簡化公司名
        if company:
            if '原台新' in company: company = '台新'
            elif '原新光' in company: company = '新光'
            company = company.replace('人壽', '').replace('保險', '').strip()

        # 公司辨識不到時，從 Excel 內容找特徵詞
        if not company:
            # 把所有資料連起來找特徵
            all_text = ' '.join(' '.join(str(c) for c in row) for row in rows[:5])
            for keyword, comp in [
                # 公司名稱直接出現
                ('全球人壽', '全球'), ('凱基人壽', '凱基'), ('新光人壽', '新光'),
                ('台灣人壽', '台灣'), ('Taiwanlife', '台灣'), ('TaiwanLife', '台灣'),  # v2.28.9
                ('富邦人壽', '富邦'), ('宏泰人壽', '宏泰'),
                ('元大人壽', '元大'), ('安聯人壽', '安聯'), ('友邦人壽', '友邦'),
                ('保誠人壽', '保誠'), ('法巴人壽', '法巴'), ('安達人壽', '安達'),
                ('台新人壽', '台新'), ('第一金人壽', '第一金'), ('台灣產物', '台灣產物'),
                # 表頭特徵詞（用於辨識報表來源）
                ('銀行受理號', '台灣'),  # v2.28.9：台壽→台灣（RL_RL037 報表特徵）
                ('扣款不成功原因', '安達'),  # 安達 DEL 報表特徵
            ]:
                if keyword in all_text:
                    company = comp
                    break

        # 最後 fallback：從原檔名抓公司關鍵字 / 報表代號
        if not company:
            fname = original_filename or xlsx_path.name
            for keyword, comp in [
                ('凱基', '凱基'), ('宏泰', '宏泰'), ('台灣', '台灣'), ('台壽', '台灣'), ('富邦', '富邦'),  # v2.28.9
                ('元大', '元大'), ('安聯', '安聯'), ('保誠', '保誠'), ('全球', '全球'),
                ('新光', '新光'), ('台新', '台新'), ('安達', '安達'), ('法巴', '法巴'),
                ('友邦', '友邦'), ('第一金', '第一金'), ('台灣產物', '台灣產物'),
                # 報表代號 fallback
                ('RL037', '台灣'), ('VCN0034', '元大'),  # v2.28.9
                ('BR052', '保誠'), ('Br052', '保誠'),
                ('811D2', '凱基'), ('S830', '安聯'),
                ('Y43R00', '新光'), ('R35', '台新'),
            ]:
                if keyword in fname:
                    company = comp
                    break

        # 必要欄位
        if not company:
            return None

        # === 缺失欄位以「【需手動】」標記，方便使用者一眼看出要補資料 ===

        # 特殊狀況：「當日無照會事項」（清冊類沒任何資料）— 不是缺失，是有意義的狀態
        # 1. first_data 全空
        is_empty_list = (not name and not policy and
                         (first_data is None or all(str(c).strip() == '' for c in first_data)))
        # 2. 或者 Excel 內容含有「本日無數據」/「無資料」等語意（即使 first_data 不是空）
        if not is_empty_list and not name and not policy:
            all_text = ' '.join(' '.join(str(c) for c in row if c is not None) for row in rows)
            if re.search(r'本日無數據|本日無資料|當日無照會|當日無資料|無\s*資料|無\s*照會', all_text):
                is_empty_list = True

        parts = [roc_date, sanitize_filename(company)]

        if is_empty_list:
            # 當日無照會事項：直接加標記，跳過後續欄位
            parts.append('當日無照會事項')
        else:
            # 被保人
            if name:
                parts.append(sanitize_filename(name))
            else:
                parts.append('【缺被保人】')
            # 文件種類
            if doctype and doctype != '文件':
                parts.append(sanitize_filename(doctype))
            else:
                parts.append('【缺文件種類】')
            # 保單號（v2.28.9：用 sanitize_policy）
            if policy:
                parts.append(sanitize_policy(policy))
            else:
                parts.append('【缺保單號】')

        base = '-'.join(parts)
        return f"{base}.pdf"
    except Exception as e:
        write_log(f"Excel 智慧命名失敗 {xlsx_path.name}: {e}")
        return None


def _extract_doctype_from_filename(filename: str) -> str:
    """從原檔名推斷文件種類

    新策略「切片過濾」：
    1. 用底線/破折號/空白切片
    2. 丟掉「日期、純數字、英數代號、業務員名、通訊處名、公司名」
    3. 留下「含中文且不在黑名單」的片段
    4. 用「_」串回去

    範例：
      「電子保單完成簽收明細表20260504_VCN0034」→「電子保單完成簽收明細表」
      「BR052鼎綸保險_鼎綸保經恩宇_簽收回條已回清冊20260330_1796」→「簽收回條已回清冊」

    v2.28：支援「zip 父名|內部檔名」組合（用 | 分隔），
    逐段嘗試，回傳第一個非「文件」的結果。
    解決元大 VCN0034 / 保誠 NB1/NB3 等「文件種類藏在 zip 名」的情境。
    """
    # v2.28：處理 | 分隔的組合檔名（zip 父名|內部檔名）
    if filename and '|' in filename:
        for part in filename.split('|'):
            if not part.strip():
                continue
            result = _extract_doctype_from_filename(part)
            if result and result != '文件':
                return result
        return '文件'

    name = Path(filename).stem

    # 去掉常見公司名前綴
    for prefix in ['元大人壽', '凱基人壽', '全球人壽', '新光人壽', '台新人壽',
                   '富邦人壽', '宏泰人壽', '安聯人壽', '友邦人壽', '保誠人壽',
                   '法巴人壽', '安達人壽', '第一金人壽', '台灣人壽', '台灣產物',
                   '元大', '凱基', '全球', '新光', '台新', '富邦', '宏泰',
                   '安聯', '友邦', '保誠', '法巴', '安達', '第一金', '台灣', '台壽']:  # v2.28.9：加台灣
        if name.startswith(prefix):
            name = name[len(prefix):]
            break

    # 切片：用底線、破折號、空白切
    parts = re.split(r'[_\-\s]+', name)
    parts = [p.strip() for p in parts if p.strip()]

    # 黑名單關鍵字（出現在片段中就跳過）
    blacklist_keywords = ['鼎綸', '恩宇', '保經', '保險', '人壽',
                          '營運區', '通訊處', '業務']

    cleaned_parts = []
    for p in parts:
        # 跳過純數字
        if re.fullmatch(r'\d+', p):
            continue
        # 跳過 YYYYMMDD 或 民國年月日（混在文字裡的）
        if re.fullmatch(r'(20\d{6}|1\d{6})', p):
            continue
        # 跳過英數混合代號（如 VCN0034, BR052, R35, S830, BPC23, RL037）
        if re.fullmatch(r'[A-Za-z]{1,5}\d+[A-Za-z]*\d*', p):
            continue
        # 跳過純英文 2-5 個字母（如 RL, VCN, DEL, list）
        if re.fullmatch(r'[A-Za-z]{2,5}', p):
            continue
        # 跳過黑名單關鍵字
        if any(kw in p for kw in blacklist_keywords):
            continue
        # 跳過 list/明細這種無意義結尾用語單獨出現
        if p.lower() in ('list', 'detail', 'report'):
            continue

        # 片段內如果中文後黏著「日期+代號」（如「明細表20260504」），切掉後綴
        # 但只切「結尾的 8 位數字 / 英數代號」，保留前面的中文
        cleaned = re.sub(r'(20\d{6}|1\d{6}).*$', '', p)
        cleaned = re.sub(r'[A-Za-z]+\d+$', '', cleaned)
        cleaned = cleaned.strip()

        # 只保留含中文的片段（純英數視為雜訊）
        if cleaned and re.search(r'[\u4e00-\u9fff\uf900-\ufaff]', cleaned):
            cleaned_parts.append(cleaned)

    # 用底線串回去
    result = '_'.join(cleaned_parts)
    return result if result else '文件'


def _extract_doctype_from_filename_END(): pass  # marker

# 凱基保全「變更項目」代號對照表（每 2 碼一組）
# 摘自凱基官方說明書，例如 010409 = 01地址變更 + 04繳別變更 + 09要保人變更
KGI_CHANGE_ITEM_MAP = {
    '01': '地址變更', '02': '收費管道變更', '03': '簽章方式變更',
    '04': '繳別變更', '05': '紅利選擇權變更', '06': '墊繳狀況變更',
    '07': '彙繳代碼變更', '08': '變更受益人', '09': '要保人變更',
    '10': '基本資料變更', '11': '職業等級變更', '12': '隨身卡補發',
    '13': '展期保險', '14': 'SSP加退保', '15': '主約保障異動',
    '16': '附約保障異動', '17': '單筆增額', '18': '分期增額保費',
    '19': '基金轉換', '20': '投資配置比率變更', '21': '部分終止全部贖回',
    '22': '險種轉換年期縮延', '23': '復效', '24': '附約移轉',
    '26': '繳清保險', '27': '契約終止', '28': '保單借款',
    '29': '體位變更', '30': '補告知取消批註', '31': '提前給付批註',
    '32': '保費異動', '33': '終止保費緩繳期', '34': '其他',
    '35': '保單補發', '36': '進入保費緩繳期', '37': '結清紅利',
    '39': '終止分期增額', '43': '電子通知單', '44': '年金給付資料變更',
    '45': '年金停繳', '46': '年金復繳', '47': '提領年金價準金',
    '48': '結匯授權書', '49': '批註條款申請書', '51': '收益分配給付方式',
    '52': '遞延期滿給付方式', '53': '取消自動增值', '54': '紅利給付方式變更',
    '55': '保險單交遞', '56': 'RVA3轉RVB1', '57': 'RVA3轉RVC1',
    '58': '投資標的收益分配給付方式', '59': '預約轉換申請',
    '60': '紅利領取方式變更', '61': '滿期還本給付方式變更',
    '62': '提領增值回饋金', '63': '回饋金給付方式變更',
    '64': '生存金給付還款變更', '65': '自動機制母標的設定',
    '66': '自動轉換自動加碼設定', '67': '自動停利設定', '68': '指定給付作業',
}


def _translate_kgi_change_items(items_str: str) -> str:
    """把凱基「變更項目」欄位（每 2 碼一組）翻譯成中文
    
    例：'28' → '保單借款'
        '010409' → '地址變更_繳別變更_要保人變更'
    """
    if not items_str:
        return ''
    # 去掉空白和非數字
    items_str = re.sub(r'\D', '', items_str)
    if len(items_str) % 2 != 0 or not items_str:
        return ''
    # 每 2 碼一組查表
    names = []
    for i in range(0, len(items_str), 2):
        code = items_str[i:i+2]
        if code in KGI_CHANGE_ITEM_MAP:
            names.append(KGI_CHANGE_ITEM_MAP[code])
    return '_'.join(names) if names else ''


# 各保險公司報表代號 → 中文名稱對照表（僅用於檔名沒任何中文時的 fallback）
REPORT_CODE_MAP = {
    # 台壽（TaiwanLife）
    'RL037': '新契約照會清單',
    # 安達（Chubb）
    'DEL': '保費扣款失敗通知',
    # 元大
    'VCN': '保單簽收回條逾期',
    # 原台新（新光）
    'R35': '保單簽收回條未回覆',
    'BR3500': '核保照會',
    'REQIR-NOTI': '核保照會',
    # 安聯
    'S830': '每日照會清單',
    # 凱基 ← C26 不放這！因為它只是「報表編號」，真正內容看「變更項目」欄位
}


def _translate_report_code(code: str) -> str:
    """把報表代號（C26、R35 等）翻譯成中文文件種類名稱
    
    若不在對照表中就回傳原值，避免破壞既有命名
    """
    if not code:
        return code
    # 完全相符
    if code in REPORT_CODE_MAP:
        return REPORT_CODE_MAP[code]
    # 部分相符（檔名中含有報表代號）
    for key, value in REPORT_CODE_MAP.items():
        if key in code.upper():
            return value
    return code


# ============ ZIP 處理 ============
def is_zip_encrypted(file_path: Path) -> bool:
    """檢查 zip/rar/7z 是否需要密碼"""
    suffix = file_path.suffix.lower()

    # RAR 檔案
    if suffix == '.rar':
        if not RARFILE_AVAILABLE:
            return False
        # unrar 後端：用 rarfile 套件直接判斷
        if RAR_TOOL_TYPE == "unrar":
            try:
                rf = rarfile.RarFile(str(file_path))
                return rf.needs_password()
            except Exception:
                return False
        # 其他後端：直接假設「可能需要密碼」，讓後續解壓嘗試各種密碼
        else:
            return True

    # 7z 檔案
    if suffix == '.7z':
        if not PY7ZR_AVAILABLE:
            return False
        try:
            # py7zr 載入時不解密；嘗試呼叫 needs_password()（新版有）或試解
            with py7zr.SevenZipFile(str(file_path)) as z:
                if hasattr(z, 'needs_password'):
                    return z.needs_password()
                # 沒這方法就直接視為需要密碼讓主流程試
                return True
        except py7zr.exceptions.PasswordRequired:
            return True
        except Exception:
            # 開啟失敗就假設需要密碼，讓主流程試
            return True

    # ZIP 檔案
    try:
        with zipfile.ZipFile(file_path) as z:
            for info in z.infolist():
                if info.flag_bits & 0x1:
                    return True
        return False
    except Exception:
        return False


def _fix_zip_filename(raw_name: str, flag_bits: int) -> str:
    """修正 zip 內檔名的中文編碼（big5/utf-8/cp950）"""
    if flag_bits & 0x800:  # 已是 UTF-8
        return raw_name
    for encoding in ['big5', 'cp950', 'utf-8', 'gbk']:
        try:
            return raw_name.encode('cp437').decode(encoding)
        except (UnicodeDecodeError, UnicodeEncodeError):
            continue
    return raw_name


def _extract_with_fix(zip_obj, extract_to: Path, pwd_bytes):
    """逐檔解壓並修正中文檔名"""
    for info in zip_obj.infolist():
        fixed_name = _fix_zip_filename(info.filename, info.flag_bits)
        target = extract_to / fixed_name
        # 防止 zip slip 攻擊
        try:
            target.resolve().relative_to(extract_to.resolve())
        except ValueError:
            continue
        if info.is_dir():
            target.mkdir(parents=True, exist_ok=True)
            continue
        target.parent.mkdir(parents=True, exist_ok=True)
        with zip_obj.open(info, pwd=pwd_bytes) as src, open(target, 'wb') as dst:
            shutil.copyfileobj(src, dst)


def extract_zip(zip_path: Path, extract_to: Path, password: Optional[str] = None) -> bool:
    """嘗試用密碼解壓 zip/rar/7z。支援標準 zip、AES zip、RAR、7z，會修正中文檔名"""
    suffix = zip_path.suffix.lower()
    pwd_bytes = password.encode() if password else None

    # RAR 檔案
    if suffix == '.rar':
        if not RARFILE_AVAILABLE:
            return False
        return _extract_rar(zip_path, extract_to, password)

    # 7z 檔案
    if suffix == '.7z':
        if not PY7ZR_AVAILABLE:
            return False
        try:
            with py7zr.SevenZipFile(str(zip_path), password=password) as z:
                z.extractall(str(extract_to))
            return True
        except Exception:
            return False

    # 先試標準 zipfile
    try:
        with zipfile.ZipFile(zip_path) as z:
            if pwd_bytes:
                z.setpassword(pwd_bytes)
            # 測試第一個檔案能否讀取（驗證密碼）
            z.read(z.namelist()[0])
            # 真正解壓（修正中文檔名）
            _extract_with_fix(z, extract_to, pwd_bytes)
        return True
    except (RuntimeError, zipfile.BadZipFile, NotImplementedError):
        pass
    except Exception:
        pass

    # 再試 AES zip (pyzipper)
    try:
        with pyzipper.AESZipFile(zip_path) as z:
            if pwd_bytes:
                z.setpassword(pwd_bytes)
            z.read(z.namelist()[0])
            _extract_with_fix(z, extract_to, pwd_bytes)
        return True
    except Exception:
        return False


def _extract_rar(rar_path: Path, extract_to: Path, password: Optional[str]) -> bool:
    """依目前偵測到的 RAR 工具類型來解壓"""
    if RAR_TOOL_TYPE == "unrar":
        # rarfile 套件原生支援
        try:
            rf = rarfile.RarFile(str(rar_path))
            if password:
                rf.setpassword(password)
            names = rf.namelist()
            if names:
                rf.read(names[0])
            rf.extractall(str(extract_to))
            return True
        except Exception:
            return False

    elif RAR_TOOL_TYPE == "7zip":
        # 7-Zip 命令列：7z x <檔案> -o<目錄> -p<密碼> -y
        try:
            cmd = [RAR_TOOL_PATH, 'x', str(rar_path),
                   f'-o{extract_to}', '-y']
            if password:
                cmd.append(f'-p{password}')
            else:
                cmd.append('-p-')  # 沒密碼也明確指定，避免互動式詢問
            result = subprocess.run(cmd, capture_output=True, timeout=120,
                                    creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
            return result.returncode == 0
        except Exception as e:
            write_log(f"7-Zip 解 RAR 失敗 {rar_path.name}: {e}")
            return False

    elif RAR_TOOL_TYPE == "bandizip":
        # Bandizip 命令列：bz x -o:<目錄> -p:<密碼> -y <檔案>
        try:
            cmd = [RAR_TOOL_PATH, 'x',
                   f'-o:{extract_to}', '-y']
            if password:
                cmd.append(f'-p:{password}')
            cmd.append(str(rar_path))
            result = subprocess.run(cmd, capture_output=True, timeout=120,
                                    creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
            return result.returncode == 0
        except Exception as e:
            write_log(f"Bandizip 解 RAR 失敗 {rar_path.name}: {e}")
            return False

    return False


def list_zip_contents(zip_path: Path) -> List[str]:
    """列出 zip/rar/7z 內檔名（不解壓）"""
    names = []
    suffix = zip_path.suffix.lower()

    # 7z 檔案：py7zr 不需密碼就能列檔名
    if suffix == '.7z':
        if not PY7ZR_AVAILABLE:
            return names
        try:
            with py7zr.SevenZipFile(str(zip_path)) as z:
                return z.getnames()
        except Exception:
            return names

    # RAR 檔案
    if suffix == '.rar':
        if not RARFILE_AVAILABLE:
            return names

        # unrar 後端：用 rarfile 套件
        if RAR_TOOL_TYPE == "unrar":
            try:
                rf = rarfile.RarFile(str(zip_path))
                return rf.namelist()
            except Exception:
                return names

        # 7-Zip 後端：用 7z l 列出檔名
        elif RAR_TOOL_TYPE == "7zip":
            try:
                result = subprocess.run(
                    [RAR_TOOL_PATH, 'l', '-ba', '-slt', str(zip_path)],
                    capture_output=True, text=True, timeout=60,
                    creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0)
                )
                # 7z 輸出格式：Path = filename
                for line in result.stdout.split('\n'):
                    line = line.strip()
                    if line.startswith('Path = '):
                        names.append(line[7:])
                return names
            except Exception:
                return names

        # Bandizip 後端：用 bz l 列出
        elif RAR_TOOL_TYPE == "bandizip":
            try:
                result = subprocess.run(
                    [RAR_TOOL_PATH, 'l', str(zip_path)],
                    capture_output=True, text=True, timeout=60,
                    creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0)
                )
                # Bandizip 列檔名格式比較簡單，每行一個（去掉表頭）
                for line in result.stdout.split('\n'):
                    line = line.strip()
                    # 過濾表頭/分隔線
                    if not line or line.startswith('-') or 'Bandizip' in line:
                        continue
                    # 嘗試取出檔名（最後一個空格後的字串）
                    parts = line.rsplit(None, 1)
                    if parts:
                        name = parts[-1]
                        if '.' in name and not name.startswith('-'):
                            names.append(name)
                return names
            except Exception:
                return names

    # ZIP 檔案
    try:
        with zipfile.ZipFile(zip_path) as z:
            for info in z.infolist():
                # 嘗試修正中文檔名編碼
                name = info.filename
                if not info.flag_bits & 0x800:  # 沒 UTF-8 flag
                    try:
                        name = info.filename.encode('cp437').decode('big5')
                    except Exception:
                        try:
                            name = info.filename.encode('cp437').decode('utf-8')
                        except Exception:
                            pass
                names.append(name)
    except Exception:
        pass
    return names


# ============ 輸出路徑 ============
def build_output_path(input_path: Path, suffix_label: str = "破解",
                      skip_if_exists: bool = True) -> Optional[Path]:
    """產生 -破解 後綴的輸出路徑。
    
    skip_if_exists=True (預設)：若 -破解 已存在則回傳 None（避免重複）
    skip_if_exists=False：若已存在則加 _2、_3 後綴
    """
    stem = input_path.stem
    suffix = input_path.suffix
    parent = input_path.parent
    output = parent / f"{stem}-{suffix_label}{suffix}"
    if not output.exists():
        return output
    if skip_if_exists:
        return None  # 已存在就跳過
    counter = 2
    while output.exists():
        output = parent / f"{stem}-{suffix_label}_{counter}{suffix}"
        counter += 1
    return output


# ============ 手動輸入密碼 ============
# 全域旗標：使用者按 ALL 後，後續都自動跳過手動詢問
_SKIP_ALL_MANUAL = False


def ask_manual_password(file_name: str, file_type: str) -> Optional[str]:
    """自動破解失敗時詢問使用者
    
    - 直接 Enter：跳過此檔案
    - 輸入 ALL：跳過此檔案 + 後續所有手動詢問
    - 對 EOF 錯誤做容錯：若 stdin 被斷，自動視為跳過
    """
    global _SKIP_ALL_MANUAL
    if _SKIP_ALL_MANUAL:
        # 之前已選 ALL，直接跳過
        return None

    print(f"\n   🔑 自動破解失敗，請手動輸入「{file_name}」的{file_type}密碼")
    print(f"      （直接 Enter 跳過此檔案；輸入 ALL 表示後續全部都跳過）")
    try:
        pwd = input(f"      密碼 > ").strip()
    except (EOFError, KeyboardInterrupt):
        print(f"      （已跳過）")
        return None

    # 偵測 ALL 指令
    if pwd.upper() == 'ALL':
        _SKIP_ALL_MANUAL = True
        print(f"      ✅ 已切換到「自動跳過」模式，後續失敗的檔案會自動列入待辦清單")
        return None

    return pwd if pwd else None


# ============ 主處理流程 ============
def process_pdf_or_excel(file_path: Path, rules: dict,
                         hint_company: Optional[List[dict]] = None,
                         allow_manual: bool = True,
                         _in_zip: bool = False) -> dict:
    """處理單一 PDF 或 Excel 檔
    
    _in_zip: 內部參數，標示這是從 zip 內解出來的檔案（在臨時目錄處理，不做智慧命名）
    """
    result = {"檔名": file_path.name, "狀態": "", "公司": "", "密碼": "", "輸出": "", "訊息": ""}
    suffix = file_path.suffix.lower()

    if suffix == '.pdf':
        file_type, is_enc_func, crack_func = "PDF", is_pdf_encrypted, crack_pdf
    elif suffix in ['.xlsx', '.xls', '.xlsm']:
        file_type, is_enc_func, crack_func = "EXCEL", is_excel_encrypted, crack_excel
    elif suffix == '.csv':
        # CSV 沒有加密保護，直接視為無密碼處理
        file_type, is_enc_func, crack_func = "CSV", lambda p: False, None
    else:
        result["狀態"] = "略過"
        result["訊息"] = f"不支援的類型 {suffix}"
        return result

    if not is_enc_func(file_path):
        # 沒密碼就直接複製一份標為 -破解
        output_path = build_output_path(file_path)
        if output_path is None:
            result["狀態"] = "略過"
            result["訊息"] = "破解版已存在，跳過"
            return result
        shutil.copy2(file_path, output_path)
        result["狀態"] = "成功"
        result["公司"] = "無密碼"
        result["密碼"] = "(無)"
        result["輸出"] = output_path.name
        # 直接處理（非 zip 內）才做智慧命名
        if not _in_zip:
            companies = identify_company(file_path.name, rules)
            company_for_name = companies[0]["公司"] if companies else ""
            _apply_smart_naming(output_path, company_for_name, file_path.name, result)
        return result

    candidates = build_password_candidates(file_path.name, file_type, rules, hint_company)

    output_path = build_output_path(file_path)
    if output_path is None:
        result["狀態"] = "略過"
        result["訊息"] = "破解版已存在，跳過"
        return result

    for company, password in candidates:
        if crack_func(file_path, output_path, password):
            result["狀態"] = "成功"
            result["公司"] = company
            result["密碼"] = password
            result["輸出"] = output_path.name
            # 嘗試智慧改名（zip 內的會在搬移時改名，所以這裡只處理直接處理的）
            if not _in_zip:
                _apply_smart_naming(output_path, company, file_path.name, result)
            return result

    # 自動失敗 → 詢問手動
    if allow_manual:
        manual_pwd = ask_manual_password(file_path.name, file_type)
        if manual_pwd:
            if crack_func(file_path, output_path, manual_pwd):
                result["狀態"] = "成功"
                result["公司"] = "手動輸入"
                result["密碼"] = manual_pwd
                result["輸出"] = output_path.name
                if not _in_zip:
                    _apply_smart_naming(output_path, "手動輸入", file_path.name, result)
                return result
            else:
                result["狀態"] = "失敗"
                result["訊息"] = "手動密碼也錯誤"
                return result

    result["狀態"] = "失敗"
    poss = set(c for c, _ in candidates) if candidates else set()
    result["公司"] = ", ".join(poss) if poss else "未辨識"
    result["訊息"] = f"嘗試 {len(candidates)} 組密碼皆失敗"
    return result


def _apply_smart_naming(output_path: Path, company: str, original_filename: str,
                        result: dict):
    """對破解後的檔案做智慧命名（PDF 直接命名，Excel 轉成 PDF 後命名）
    
    會更新 result 字典的「輸出」和「訊息」欄位
    """
    suffix = output_path.suffix.lower()

    try:
        if suffix == '.pdf':
            smart_name = build_smart_filename(output_path, company, output_path.suffix)
            if smart_name:
                new_path = build_output_path_in(output_path.parent, smart_name)
                if new_path is not None:
                    output_path.rename(new_path)
                    result["輸出"] = new_path.name
                    result["訊息"] = "已智慧命名"

                    # 嘗試拆分清冊類 PDF（如果含多筆資料）
                    split_count = _try_split_list_pdf(new_path)
                    if split_count > 0:
                        result["訊息"] = f"已智慧命名並拆分為 {split_count} 份"
                        result["輸出"] = f"(已拆分為 {split_count} 份)"
                else:
                    # 目標已存在，比對大小決定處理方式
                    target = output_path.parent / smart_name
                    if target.exists():
                        try:
                            if target.stat().st_size == output_path.stat().st_size:
                                # 內容相同，刪除這個重複的
                                output_path.unlink()
                                result["輸出"] = smart_name
                                result["訊息"] = "重複檔案已刪除"
                            else:
                                # 內容不同，加序號後綴
                                pdf_target = build_output_path_in(output_path.parent, smart_name, skip_if_exists=False)
                                if pdf_target is not None:
                                    output_path.rename(pdf_target)
                                    result["輸出"] = pdf_target.name
                                    result["訊息"] = "已智慧命名（加序號）"
                        except Exception:
                            pass

        elif suffix in ('.xlsx', '.xlsm', '.xls', '.csv') and EXCEL_TO_PDF_AVAILABLE:
            # Excel → PDF + 智慧命名
            smart_name = build_smart_filename_from_excel(
                output_path, company, original_filename
            )
            if smart_name:
                # 在同資料夾建立 PDF
                pdf_target = build_output_path_in(output_path.parent, smart_name)
                if pdf_target is not None:
                    title = Path(smart_name).stem
                    if excel_to_pdf(output_path, pdf_target, title=title):
                        # 刪掉原 -破解.xlsx，只留新 PDF
                        try:
                            output_path.unlink()
                        except Exception:
                            pass
                        result["輸出"] = pdf_target.name
                        result["訊息"] = "已轉 PDF 並智慧命名"

                        # 嘗試拆分（如果 Excel 轉成的 PDF 也是清冊類）
                        split_count = _try_split_list_pdf(pdf_target)
                        if split_count > 0:
                            result["訊息"] = f"已轉 PDF 並拆分為 {split_count} 份"
    except Exception as e:
        write_log(f"智慧命名失敗 {output_path.name}: {e}")


def process_zip(zip_path: Path, rules: dict, allow_manual: bool = True) -> List[dict]:
    """處理 zip 檔：解壓到臨時資料夾 → 破解內部檔案 → 把破解後的檔案放到 zip 旁邊（不建立資料夾）"""
    results = []
    results_main = {"檔名": zip_path.name, "狀態": "", "公司": "", "密碼": "", "輸出": "", "訊息": ""}

    # 同時看 zip 名稱 + 內部檔名 來辨識
    inner_names = list_zip_contents(zip_path)
    combined_text = zip_path.name + " " + " ".join(inner_names)
    hint_companies = identify_company(combined_text, rules)

    # 解壓到臨時資料夾（處理完會自動刪除）
    tmpdir_obj = tempfile.TemporaryDirectory()
    extract_to = Path(tmpdir_obj.name)

    zip_password_used = None  # 記下成功的 zip 密碼，待會兒用來標記

    try:
        # 檢查是否需要密碼
        if not is_zip_encrypted(zip_path):
            if extract_zip(zip_path, extract_to, None):
                results_main["狀態"] = "成功"
                results_main["公司"] = "無密碼"
                results_main["密碼"] = "(無)"
                results_main["輸出"] = "(已解壓)"
            else:
                results_main["狀態"] = "失敗"
                results_main["訊息"] = "解壓失敗（檔案可能已損壞）"
                results.append(results_main)
                return results
        else:
            # 嘗試各種密碼
            candidates = build_password_candidates(combined_text, "zip", rules, hint_companies)
            cracked = False
            for company, password in candidates:
                with tempfile.TemporaryDirectory() as test_tmp:
                    if extract_zip(zip_path, Path(test_tmp), password):
                        # 測試成功 → 正式解壓到工作區
                        extract_zip(zip_path, extract_to, password)
                        results_main["狀態"] = "成功"
                        results_main["公司"] = company
                        results_main["密碼"] = password
                        results_main["輸出"] = "(已解壓)"
                        zip_password_used = password
                        cracked = True
                        break

            if not cracked and allow_manual:
                manual_pwd = ask_manual_password(zip_path.name, "ZIP")
                if manual_pwd:
                    if extract_zip(zip_path, extract_to, manual_pwd):
                        results_main["狀態"] = "成功"
                        results_main["公司"] = "手動輸入"
                        results_main["密碼"] = manual_pwd
                        results_main["輸出"] = "(已解壓)"
                        zip_password_used = manual_pwd
                        cracked = True
                    else:
                        results_main["狀態"] = "失敗"
                        results_main["訊息"] = "手動密碼錯誤"

            if not cracked:
                if results_main["狀態"] != "失敗":
                    results_main["狀態"] = "失敗"
                    poss = set(c for c, _ in candidates) if candidates else set()
                    results_main["公司"] = ", ".join(poss) if poss else "未辨識"
                    results_main["訊息"] = f"嘗試 {len(candidates)} 組密碼皆失敗"
                results.append(results_main)
                return results

        results.append(results_main)

        # 處理解壓出的檔案
        # 注意：Windows 檔案系統不分大小寫，*.pdf 和 *.PDF 會找到同一個檔案
        # 用 set 去重避免同一個檔被處理多次
        inner_files_set = set()
        for ext in ['*.pdf', '*.PDF', '*.xlsx', '*.xls', '*.xlsm',
                    '*.XLSX', '*.XLS', '*.XLSM', '*.csv', '*.CSV']:
            for f in extract_to.rglob(ext):
                # 用真實路徑去重（Windows 不分大小寫）
                try:
                    real = f.resolve()
                except Exception:
                    real = f.absolute()
                inner_files_set.add(real)
        # 排序讓處理順序穩定
        inner_files = sorted(inner_files_set)

        zip_dir = zip_path.parent  # 破解後要放的目的地

        for inner_file in inner_files:
            print(f"\n   📄 處理內部檔案：{inner_file.name}")

            # 先在臨時目錄破解
            inner_result = process_pdf_or_excel(inner_file, rules, hint_companies, allow_manual, _in_zip=True)

            # 把破解後的檔案搬到 zip 旁邊（已存在就跳過）
            if inner_result["狀態"] == "成功":
                # 找出破解後的檔案（在臨時目錄裡）
                cracked_in_tmp = inner_file.parent / inner_result["輸出"]
                if cracked_in_tmp.exists():
                    # === 判重檢查（保單號碼 + 內容指紋）===
                    if cracked_in_tmp.suffix.lower() == '.pdf' and _DEDUP_HISTORY is not None:
                        try:
                            pdf_text = extract_text_from_pdf(cracked_in_tmp)
                            policy_num = parse_policy_number(pdf_text)
                            content_hash = compute_content_hash(cracked_in_tmp)

                            dup_status, dup_record = check_duplicate(
                                _DEDUP_HISTORY, policy_num, content_hash
                            )

                            if dup_status == "duplicate":
                                # 完全重複：保單+內容都一樣，跳過
                                inner_result["狀態"] = "略過"
                                inner_result["訊息"] = (
                                    f"已處理過相同檔案「{dup_record.get('filename', '')}」"
                                )
                                inner_result["輸出"] = ""
                                results.append(inner_result)
                                continue
                            elif dup_status == "updated":
                                # 保單號碼相同但內容不同 → 可能是更新版，保留兩份
                                inner_result["訊息"] = (
                                    f"⚠️ 保單 {policy_num} 內容已更新（與舊版不同）"
                                )
                                # 改名加上「_更新版」標記，方便辨識
                                if cracked_in_tmp.suffix.lower() == '.pdf':
                                    pass  # 標記會在下面的 smart_name 處理
                        except Exception as e:
                            write_log(f"判重失敗 {cracked_in_tmp.name}: {e}")
                            policy_num = None
                            content_hash = None
                            dup_status = "new"
                    else:
                        policy_num = None
                        content_hash = None
                        dup_status = "new"

                    # 嘗試智慧命名（讀 PDF 內容 → 今天日期-公司-被保人-類型.pdf）
                    smart_name = None
                    inner_co = inner_result.get("公司", "")
                    main_co = results_main.get("公司", "")
                    if inner_co in ("無密碼", "手動輸入", "未辨識", ""):
                        company_for_name = main_co
                    else:
                        company_for_name = inner_co

                    if cracked_in_tmp.suffix.lower() == '.pdf':
                        smart_name = build_smart_filename(
                            cracked_in_tmp,
                            company_for_name,
                            cracked_in_tmp.suffix
                        )
                        # 若是「更新版」，在檔名加標記
                        if dup_status == "updated" and smart_name:
                            stem = smart_name[:-len(cracked_in_tmp.suffix)]
                            smart_name = f"{stem}_更新版{cracked_in_tmp.suffix}"

                    # === Excel 自動轉成橫式 PDF（新功能）===
                    elif cracked_in_tmp.suffix.lower() in ('.xlsx', '.xlsm', '.xls', '.csv') and EXCEL_TO_PDF_AVAILABLE:
                        # v2.28：把外層 zip 名也帶進去（用 | 分隔），
                        # 解決元大 VCN0034 / 保誠 NB1/NB3 等「文件種類藏在 zip 名」的情境
                        combined_name = f"{zip_path.stem}|{inner_file.name}"
                        smart_name = build_smart_filename_from_excel(
                            cracked_in_tmp,
                            company_for_name,
                            combined_name  # zip 父名 | 內部檔名
                        )
                        if smart_name:
                            # 將 Excel 轉成同名的 PDF
                            pdf_in_tmp = cracked_in_tmp.with_suffix('.tmp.pdf')
                            title = Path(smart_name).stem
                            if excel_to_pdf(cracked_in_tmp, pdf_in_tmp, title=title):
                                # 用轉出的 PDF 取代原本的 xlsx 作為輸出
                                try:
                                    cracked_in_tmp.unlink()  # 刪掉臨時 xlsx
                                except Exception:
                                    pass
                                cracked_in_tmp = pdf_in_tmp
                                inner_result["訊息"] = "已轉 PDF 並智慧命名"
                            else:
                                # 轉 PDF 失敗，保留原 Excel 副檔名
                                original_suffix = cracked_in_tmp.suffix
                                if smart_name.endswith('.pdf'):
                                    smart_name = smart_name[:-4] + original_suffix

                    target_name = smart_name if smart_name else cracked_in_tmp.name
                    # 在 zip 旁邊建立目標路徑，遇到同名就跳過（不重複處理）
                    target = build_output_path_in(zip_dir, target_name)
                    if target is None:
                        # 同名已存在，比對大小判斷是否重複
                        existing = zip_dir / target_name
                        try:
                            if existing.exists() and existing.stat().st_size == cracked_in_tmp.stat().st_size:
                                # 重複檔，直接視為略過
                                inner_result["狀態"] = "略過"
                                inner_result["訊息"] = f"已存在「{target_name}」（內容相同，跳過）"
                                inner_result["輸出"] = ""
                            else:
                                # 不同內容，加序號後綴
                                target = build_output_path_in(zip_dir, target_name, skip_if_exists=False)
                                if target is not None:
                                    shutil.move(str(cracked_in_tmp), str(target))
                                    inner_result["輸出"] = target.name
                                    inner_result["訊息"] = (inner_result.get("訊息") or "已智慧命名") + "（加序號）"
                                    if (_DEDUP_HISTORY is not None and policy_num
                                            and content_hash):
                                        add_history(_DEDUP_HISTORY, policy_num,
                                                    content_hash, target.name)
                                    # 拆分清冊類 PDF
                                    if target.suffix.lower() == '.pdf':
                                        split_count = _try_split_list_pdf(target)
                                        if split_count > 0:
                                            inner_result["訊息"] = f"已智慧命名並拆分為 {split_count} 份"
                                            inner_result["輸出"] = f"(已拆分為 {split_count} 份)"
                                else:
                                    inner_result["狀態"] = "略過"
                                    inner_result["訊息"] = f"已存在「{target_name}」，跳過"
                                    inner_result["輸出"] = ""
                        except Exception as e:
                            inner_result["狀態"] = "略過"
                            inner_result["訊息"] = f"已存在「{target_name}」，跳過"
                            inner_result["輸出"] = ""
                    else:
                        try:
                            shutil.move(str(cracked_in_tmp), str(target))
                            inner_result["輸出"] = target.name
                            if smart_name and not inner_result.get("訊息"):
                                inner_result["訊息"] = "已智慧命名"
                            # 記錄到歷史
                            if (_DEDUP_HISTORY is not None and policy_num
                                    and content_hash):
                                add_history(_DEDUP_HISTORY, policy_num,
                                            content_hash, target.name)
                            # 拆分清冊類 PDF（如「下月應收件明細表」拆 8 份）
                            if target.suffix.lower() == '.pdf':
                                split_count = _try_split_list_pdf(target)
                                if split_count > 0:
                                    inner_result["訊息"] = f"已智慧命名並拆分為 {split_count} 份"
                                    # 拆分後，原檔已刪除。輸出改用「拆分總結」（移除【缺】標記避免報告誤判）
                                    inner_result["輸出"] = f"(已拆分為 {split_count} 份)"
                        except Exception as e:
                            inner_result["狀態"] = "失敗"
                            inner_result["訊息"] = f"搬移檔案失敗：{e}"

            results.append(inner_result)

        return results

    finally:
        # 清理臨時資料夾
        try:
            tmpdir_obj.cleanup()
        except Exception:
            pass


def build_output_path_in(target_dir: Path, filename: str,
                         skip_if_exists: bool = True) -> Optional[Path]:
    """在指定資料夾建立輸出路徑。
    
    skip_if_exists=True (預設)：若同名檔已存在則回傳 None（跳過，不重複處理）
    skip_if_exists=False：若已存在則加 _2、_3 後綴
    """
    target = target_dir / filename
    if not target.exists():
        return target
    if skip_if_exists:
        return None
    stem = target.stem
    suffix = target.suffix
    counter = 2
    while True:
        new_target = target_dir / f"{stem}_{counter}{suffix}"
        if not new_target.exists():
            return new_target
        counter += 1


def collect_files(target_paths: List[str]) -> List[Path]:
    """收集所有待處理檔案。自動跳過已破解過或已智慧命名過的檔案
    
    注意：Windows 檔案系統不分大小寫，要用真實路徑去重避免重複
    """
    # 比對「已處理過」的模式：
    # 1. 檔名含「-破解」
    # 2. 智慧命名格式：「民國年月日-公司-...」開頭，如 1150513-全球-...
    smart_name_pattern = re.compile(r'^1[0-9]{2}[01][0-9][0-3][0-9]-')

    files_set = set()
    for p in target_paths:
        path = Path(p)
        if not path.exists():
            print(f"⚠️  找不到：{p}")
            continue
        if path.is_file():
            try:
                files_set.add(path.resolve())
            except Exception:
                files_set.add(path.absolute())
        elif path.is_dir():
            for ext in ['*.pdf', '*.PDF', '*.xlsx', '*.xls', '*.xlsm',
                        '*.XLSX', '*.XLS', '*.XLSM', '*.zip', '*.ZIP',
                        '*.rar', '*.RAR', '*.csv', '*.CSV', '*.7z', '*.7Z']:
                for f in path.glob(ext):
                    # 跳過已破解的檔案（檔名含「-破解」）
                    if "-破解" in f.stem:
                        continue
                    # 跳過已智慧命名的檔案（檔名為「民國年月日-...」格式）
                    # v2.28：含「【缺」標記的（如【缺被保人】）保留，留給 rename 流程處理
                    if smart_name_pattern.match(f.name) and '【缺' not in f.name:
                        continue
                    try:
                        real = f.resolve()
                    except Exception:
                        real = f.absolute()
                    files_set.add(real)
    return sorted(files_set)


def _prevent_sleep_start():
    """阻止 Windows 進入睡眠/休眠/螢幕關閉，讓批次處理不會中斷
    
    回傳一個 handle，程式結束時自動恢復系統設定
    支援 Windows、macOS、Linux
    """
    import sys
    if sys.platform == 'win32':
        try:
            import ctypes
            # ES_CONTINUOUS = 0x80000000
            # ES_SYSTEM_REQUIRED = 0x00000001 (阻止睡眠)
            # ES_DISPLAY_REQUIRED = 0x00000002 (阻止螢幕關閉)
            # ES_AWAYMODE_REQUIRED = 0x00000040 (使用「待機」模式)
            ES_CONTINUOUS = 0x80000000
            ES_SYSTEM_REQUIRED = 0x00000001
            ES_AWAYMODE_REQUIRED = 0x00000040
            ctypes.windll.kernel32.SetThreadExecutionState(
                ES_CONTINUOUS | ES_SYSTEM_REQUIRED | ES_AWAYMODE_REQUIRED
            )
            print("  💤 防睡眠：✅ 已啟用（處理期間電腦不會睡眠）")
            return 'win32'
        except Exception as e:
            print(f"  💤 防睡眠：⚠️  無法啟用（{e}）")
            return None
    elif sys.platform == 'darwin':
        try:
            import subprocess
            # macOS: caffeinate -dimsu （程式結束會自動終止）
            handle = subprocess.Popen(['caffeinate', '-dimsu'])
            print("  💤 防睡眠：✅ 已啟用（macOS caffeinate）")
            return handle
        except Exception:
            return None
    return None


def _prevent_sleep_stop(handle):
    """恢復系統的睡眠設定"""
    import sys
    if handle == 'win32':
        try:
            import ctypes
            ES_CONTINUOUS = 0x80000000
            # 只設定 CONTINUOUS = 取消之前的設定
            ctypes.windll.kernel32.SetThreadExecutionState(ES_CONTINUOUS)
        except Exception:
            pass
    elif hasattr(handle, 'terminate'):
        try:
            handle.terminate()
        except Exception:
            pass


VERSION = "v2.28.15"  # 主版本.次版本.小版次
BUILD_DATE = "2026-05-16"  # 建置日期
VERSION_NOTE = "[已完成] 標記改用「ZIP 解出所有檔都完整」判斷"  # 本版重點功能

def print_banner():
    print("=" * 64)
    print(f"       📂 照會單自動破解工具  {VERSION}  ({BUILD_DATE})")
    print(f"       本版重點：{VERSION_NOTE}")
    print("       鼎綸保經 / 恩宇營運區 專用")
    print("=" * 64)
    # 顯示 RAR 支援狀態
    if RARFILE_AVAILABLE and RAR_TOOL_PATH:
        tool_name = {
            "unrar": "UnRAR / WinRAR",
            "7zip": "7-Zip",
            "bandizip": "Bandizip"
        }.get(RAR_TOOL_TYPE, RAR_TOOL_TYPE)
        print(f"  📦 RAR 支援：✅ 使用 {tool_name}")
    else:
        print(f"  📦 RAR 支援：❌ 未偵測到解壓工具（.rar 檔案將略過）")
    # 顯示 7z 支援狀態
    if PY7ZR_AVAILABLE:
        print(f"  📦 7Z  支援：✅ 使用 py7zr")
    else:
        print(f"  📦 7Z  支援：❌ py7zr 套件未安裝（.7z 檔案將略過）")
    print()


def write_failure_report(failed_results: List[dict], base_dir: Path,
                          partial_results: Optional[List[dict]] = None) -> Optional[Path]:
    """把失敗清單寫到桌面或工具資料夾，方便事後查看
    
    包含：
    - failed_results: 完全失敗（無法破解）
    - partial_results: 破解成功但「命名有【缺】標記」（需手動補）
    """
    has_failed = bool(failed_results)
    has_partial = bool(partial_results)
    if not has_failed and not has_partial:
        return None
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    report_path = base_dir / f"處理待辦清單_{timestamp}.txt"
    try:
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write("=" * 60 + "\n")
            f.write(f"  處理待辦清單  ({datetime.now().strftime('%Y-%m-%d %H:%M:%S')})\n")
            f.write("=" * 60 + "\n\n")

            if has_failed:
                f.write(f"❌ 完全失敗（無法破解）：{len(failed_results)} 個\n")
                f.write("-" * 60 + "\n")
                for i, r in enumerate(failed_results, 1):
                    f.write(f"{i}. {r['檔名']}\n")
                    f.write(f"   可能公司：{r['公司']}\n")
                    f.write(f"   失敗原因：{r['訊息']}\n\n")

            if has_partial:
                f.write(f"\n⚠️ 需手動補資料：{len(partial_results)} 個\n")
                f.write("-" * 60 + "\n")
                f.write("（這些檔案已成功破解，但檔名中含「【缺xxx】」標記）\n\n")
                for i, r in enumerate(partial_results, 1):
                    f.write(f"{i}. 原檔：{r['檔名']}\n")
                    f.write(f"   目前命名：{r['輸出']}\n")
                    # 解析缺什麼
                    output = r.get('輸出', '')
                    missing = []
                    if '【缺被保人】' in output:
                        missing.append('被保險人')
                    if '【缺文件種類】' in output:
                        missing.append('文件種類')
                    if '【缺保單號】' in output:
                        missing.append('保單號碼')
                    if '【日期需確認】' in output:
                        missing.append('日期（目前用今天當預設）')
                    if missing:
                        f.write(f"   缺失欄位：{' / '.join(missing)}\n")
                    f.write("\n")

            f.write("=" * 60 + "\n")
            f.write("處理建議：\n")
            if has_failed:
                f.write("【破解失敗】\n")
                f.write("  1. 確認檔案來自哪家保險公司\n")
                f.write("  2. 查對照表確認密碼\n")
                f.write("  3. 重跑工具，用「手動輸入」模式輸入密碼\n")
                f.write("  4. 如公司密碼變動，請編輯 passwords.json 更新\n\n")
            if has_partial:
                f.write("【需手動補資料】\n")
                f.write("  1. 打開檔案看實際內容，把【缺xxx】手動改成正確資料\n")
                f.write("  2. 如有大量同類型檔案，可以告知工具開發者新增規則\n")
        return report_path
    except Exception:
        return None


def print_summary(all_results: List[dict]) -> int:
    """印出處理結果摘要。回傳失敗數量。"""
    print()
    print("=" * 64)
    print("                          📊 處理結果")
    print("=" * 64)
    success = [r for r in all_results if r["狀態"] == "成功"]
    failed = [r for r in all_results if r["狀態"] == "失敗"]
    skipped = [r for r in all_results if r["狀態"] == "略過"]

    # 把「成功但需手動補」分出來
    partial = [r for r in success if r.get('輸出') and '【' in r['輸出']]
    complete = [r for r in success if not (r.get('輸出') and '【' in r['輸出'])]

    if complete:
        print(f"\n✅ 完全成功 ({len(complete)} 個)")
        for r in complete:
            print(f"   • {r['檔名']}")
            if r['公司'] != '無密碼':
                print(f"     公司：{r['公司']}    密碼：{r['密碼']}")
            print(f"     輸出：{r['輸出']}")

    if partial:
        print()
        print("⚠️" * 32)
        print(f"⚠️  以下 {len(partial)} 個檔案已破解但檔名含【缺xxx】，請手動補資料  ⚠️")
        print("⚠️" * 32)
        for r in partial:
            print(f"   ⚠️ {r['檔名']}")
            print(f"      → {r['輸出']}")
        print("⚠️" * 32)

    if failed:
        # 醒目警告框
        print()
        print("!" * 64)
        print(f"!!  ⚠️  注意！有 {len(failed)} 個檔案破解失敗  ⚠️")
        print("!" * 64)
        for r in failed:
            print(f"   ❌ {r['檔名']}")
            print(f"      可能公司：{r['公司']}")
            print(f"      失敗原因：{r['訊息']}")
        print("!" * 64)

    # 寫待辦清單（含失敗 + 需手動補）
    if failed or partial:
        report = write_failure_report(failed, BASE_DIR, partial_results=partial)
        if report:
            print(f"\n   📝 待辦清單已存到：{report.name}")

    if skipped:
        print(f"\n⏭️  略過 ({len(skipped)} 個)")
        for r in skipped:
            print(f"   • {r['檔名']}  ({r['訊息']})")

    print()
    print(f"📊 總計：✅ 完全成功 {len(complete)}   ⚠️ 需手動 {len(partial)}   ❌ 失敗 {len(failed)}   ⏭️ 略過 {len(skipped)}")
    print("=" * 64)
    return len(failed)


def process_single(file_path: Path, rules: dict, allow_manual: bool = True) -> List[dict]:
    """根據檔案類型決定處理方式，回傳結果清單"""
    suffix = file_path.suffix.lower()
    if suffix in ('.zip', '.rar', '.7z'):
        return process_zip(file_path, rules, allow_manual)
    elif suffix in ['.pdf', '.xlsx', '.xls', '.xlsm', '.csv']:
        return [process_pdf_or_excel(file_path, rules, None, allow_manual)]
    else:
        return [{"檔名": file_path.name, "狀態": "略過", "公司": "", "密碼": "", "輸出": "",
                 "訊息": f"不支援的類型 {suffix}"}]


def interactive_mode(rules: dict):
    print("【互動模式】")
    print("請輸入要處理的檔案或資料夾路徑（可直接拖曳到視窗）")
    print("輸入 q 結束\n")
    all_results = []
    while True:
        user_input = input("📁 路徑 > ").strip().strip('"').strip("'")
        if user_input.lower() in ['q', 'quit', 'exit']:
            break
        if not user_input:
            continue
        files = collect_files([user_input])
        if not files:
            print("⚠️  沒有可處理的檔案\n")
            continue
        session_results = []
        for i, f in enumerate(files, 1):
            print(f"\n[{i}/{len(files)}] 🔍 {f.name}")
            results = process_single(f, rules)
            session_results.extend(results)
            for r in results:
                if r["狀態"] == "成功":
                    suffix_info = ""
                    if r["公司"] != "無密碼":
                        suffix_info = f"  ({r['公司']} / {r['密碼']})"
                    print(f"   ✅ {r['輸出']}{suffix_info}")
                elif r["狀態"] == "失敗":
                    print(f"   ❌ {r['訊息']}")
                write_log(f"{r['狀態']} | {r['檔名']} | {r['公司']} | {r['密碼']} | {r['訊息']}")
        print_summary(session_results)
        # v2.28.8：互動模式每次處理完都跑整理階段
        cleanup_dirs = set()
        for f in files:
            cleanup_dirs.add(f.parent)
        _run_cleanup_phase(cleanup_dirs, session_results=session_results)
        all_results.extend(session_results)
        print()



def _run_cleanup_phase(target_dirs: set, session_results: list = None) -> None:
    """v2.28.8：通用整理階段
    
    任何主處理結束後都該呼叫：
      - 分類缺資料 PDF + 對應 ZIP 到「待手動處理/」
      - 對日期有對應完整 PDF 的 ZIP 加 [已完成] 前綴
    """
    if not target_dirs:
        return
    print()
    print("=" * 64)
    print("📦 整理階段（標記 [已完成] ZIP / 分類待手動處理）")
    print("=" * 64)
    # v2.28.11：先做 [已完成] 標記（在 move 之前），避免好 ZIP 被誤搬走
    marked = _mark_completed_zips(target_dirs, session_results=session_results)
    print(f"   🏷️ 標記 [已完成] ZIP：{marked} 個")
    # 然後再搬「沒救成功」的（已經標 [已完成] 的會被 _move 自動跳過）
    moved_pdf, moved_zip = _move_incomplete_to_triage(target_dirs)
    print(f"   📦 待手動處理/: 📄 PDF {moved_pdf} 個   📦 ZIP {moved_zip} 個")
    print()


def rename_only_mode(targets: list) -> int:
    """v2.28 重新命名模式 (--rename)
    
    對已解密的 PDF 直接 in-place 重命名，套用最新 v2.28 解析邏輯。
    不複製、不解密、不轉檔。專為「過去命名缺資料」的 PDF 補回正確檔名。
    
    參數：
      targets：路徑清單（檔案或資料夾）
    
    流程：
      1. 蒐集所有 PDF
      2. 對每個 PDF 套 build_smart_filename → 取得新名稱
      3. 若新名稱「比舊名稱完整」（缺資料標記變少），就 rename
      4. 重名處理：大小相同 → 刪重複；大小不同 → 加 _2/_3 序號
      5. 最後跑 _cross_reference_policy 補跨檔資料
      6. 回傳 (改名數, 略過數)
    """
    pdfs = []
    for t in targets:
        p = Path(t)
        if p.is_file() and p.suffix.lower() == '.pdf':
            pdfs.append(p)
        elif p.is_dir():
            pdfs.extend(p.glob('*.pdf'))
            pdfs.extend(p.glob('*.PDF'))
    
    # 去重（Windows 不分大小寫）
    seen = set()
    unique = []
    for p in pdfs:
        try:
            rp = str(p.resolve())
        except Exception:
            rp = str(p.absolute())
        if rp not in seen:
            seen.add(rp)
            unique.append(p)
    pdfs = sorted(unique)
    
    print(f"\n📁 重新命名模式：共 {len(pdfs)} 個 PDF\n")
    if not pdfs:
        return 0
    
    renamed = 0
    skipped = 0
    target_dirs = set()  # 紀錄要做跨檔比對的資料夾
    
    for i, pdf in enumerate(pdfs, 1):
        target_dirs.add(pdf.parent)
        try:
            # 從檔名抓公司（如果原檔名是智慧命名格式）
            company = None
            parts = pdf.stem.split('-')
            if len(parts) >= 5 and re.match(r'^\d{7}', parts[0]):
                company = parts[1]
            
            # 用 v2.28 邏輯產生新檔名
            new_name = build_smart_filename(pdf, company, pdf.suffix)
            if not new_name:
                skipped += 1
                continue
            
            # v2.28：安全防線 — 新檔名拒絕條件
            # (a) 跟舊名相同 → 略過
            if pdf.name == new_name:
                skipped += 1
                continue
            # (b) 缺資料變多 → 略過
            old_missing = pdf.name.count('【缺')
            new_missing = new_name.count('【缺')
            if new_missing > old_missing:
                skipped += 1
                continue
            # (c) 新檔名含「條列符號開頭」或「不像文件標題的句子」→ 略過
            new_stem = new_name[:-len(pdf.suffix)] if new_name.endswith(pdf.suffix) else new_name
            new_parts = new_stem.split('-')
            if len(new_parts) >= 4:
                new_doc = new_parts[3]
                # 拒絕：條列符號開頭/英數代碼開頭/句子片段
                if re.match(r'^[０-９0-9]+[、,，.]|^[◎●※□△]', new_doc):
                    skipped += 1
                    continue
                if re.search(r'(上述|所列|所述|本通知|本公司|本批註|請於|請至|請查照|為配合|根據|依據)', new_doc):
                    skipped += 1
                    continue
                # 純英數代碼開頭（如 RNBEPIPA1 富邦...） — 應該被前面 strip 掉
                if re.match(r'^[A-Z]{2,10}\d', new_doc):
                    skipped += 1
                    continue
            
            new_path = pdf.parent / new_name
            
            # 處理重名
            if new_path.exists() and new_path != pdf:
                try:
                    if new_path.stat().st_size == pdf.stat().st_size:
                        # 內容相同 → 刪除這份
                        old_name = pdf.name
                        pdf.unlink()
                        renamed += 1
                        print(f"  [{i}/{len(pdfs)}] 🗑️ 重複已刪：{old_name}")
                        write_log(f"重命名去重 | 刪除：{old_name}（與 {new_name} 相同）")
                        continue
                    # 不同 → 加序號
                    counter = 2
                    while counter <= 99:
                        alt = pdf.parent / f"{new_name[:-len(pdf.suffix)]}_{counter}{pdf.suffix}"
                        if not alt.exists():
                            new_path = alt
                            new_name = alt.name
                            break
                        counter += 1
                except Exception:
                    skipped += 1
                    continue
            
            old_name = pdf.name
            pdf.rename(new_path)
            renamed += 1
            print(f"  [{i}/{len(pdfs)}] ✅ {old_name}")
            print(f"           → {new_name}")
            write_log(f"重命名 | {old_name} → {new_name}")
        
        except Exception as e:
            skipped += 1
            write_log(f"重命名失敗 | {pdf.name}: {e}")
    
    print(f"\n📊 第一輪：✅ 改名 {renamed} 個  ⏭️ 略過 {skipped} 個")
    
    # 第二輪：跨檔比對（補【缺被保人】/【缺保單號】）
    print(f"\n🔗 第二輪：跨檔比對（{len(target_dirs)} 個資料夾）...")
    cross_total = 0
    for td in target_dirs:
        fixed = _cross_reference_policy(td)
        cross_total += fixed
    print(f"   跨檔補回：{cross_total} 個檔案")

    # 第三輪：把「仍缺資料」的 PDF + 對應日期的 ZIP 移到「待手動處理/」
    print(f"\n📦 第三輪：分類「待手動處理」（仍含【缺...】的檔案 + 對應 ZIP）...")
    moved_pdf, moved_zip = _move_incomplete_to_triage(target_dirs)
    print(f"   移到「待手動處理/」：📄 PDF {moved_pdf} 個   📦 ZIP {moved_zip} 個")

    # 第四輪：對日期有對應完整 PDF 的 ZIP 加 [已完成] 前綴
    print(f"\n🏷️  第四輪：標記「已完成」的 ZIP（對應 PDF 已完整命名的）...")
    marked = _mark_completed_zips(target_dirs)
    print(f"   標記 [已完成]：📦 {marked} 個 ZIP")

    print(f"\n📊 總計：✅ 改名 {renamed + cross_total}  ⏭️ 略過 {skipped}  📦 待手動 {moved_pdf}  🏷️ 已完成 ZIP {marked}\n")
    return renamed + cross_total


def _move_incomplete_to_triage(target_dirs: set) -> tuple:
    """v2.28：把仍含【缺】標記的 PDF + 對應日期的 ZIP 移到「待手動處理」子資料夾
    
    回傳 (moved_pdf 數, moved_zip 數)
    """
    moved_pdf = 0
    moved_zip = 0
    for td in target_dirs:
        if not td.is_dir():
            continue
        # 1. 找仍含【缺】的 PDF
        incomplete = [f for f in td.iterdir()
                      if f.is_file() and f.suffix.lower() == '.pdf'
                      and '【缺' in f.name]
        if not incomplete:
            continue

        # 2. 抽出他們的「民國日期」並轉成「西元日期」（用來匹配 ZIP）
        incomplete_ad_dates = set()
        for pdf in incomplete:
            m = re.match(r'^(1\d{2})(0[1-9]|1[0-2])(0[1-9]|[12]\d|3[01])-', pdf.name)
            if m:
                try:
                    y = int(m.group(1)) + 1911
                    incomplete_ad_dates.add(f"{y}{m.group(2)}{m.group(3)}")
                except Exception:
                    pass

        # v2.28.11：抽「完整命名 PDF」的西元日期（有完整 PDF 的日期，ZIP 不該被搬走）
        complete_ad_dates = set()
        for f in td.iterdir():
            if not (f.is_file() and f.suffix.lower() == '.pdf'):
                continue
            if '【缺' in f.name:
                continue
            m = re.match(r'^(1\d{2})(0[1-9]|1[0-2])(0[1-9]|[12]\d|3[01])-', f.name)
            if m:
                try:
                    y = int(m.group(1)) + 1911
                    complete_ad_dates.add(f"{y}{m.group(2)}{m.group(3)}")
                except Exception:
                    pass

        # v2.28.11：只搬「日期僅出現在缺資料 PDF」的 ZIP（避免日期碰撞）
        movable_dates = incomplete_ad_dates - complete_ad_dates

        # 3. 找日期對應的 ZIP/RAR/7z
        zips_match = []
        if movable_dates:
            for f in td.iterdir():
                if not (f.is_file() and f.suffix.lower() in ('.zip', '.rar', '.7z')):
                    continue
                # v2.28.11：已標 [已完成] 的不搬
                if f.name.startswith('[已完成]'):
                    continue
                if any(ad in f.name for ad in movable_dates):
                    zips_match.append(f)

        # 4. 建子資料夾並搬移
        if incomplete or zips_match:
            subdir = td / "待手動處理"
            try:
                subdir.mkdir(exist_ok=True)
            except Exception as e:
                write_log(f"建立待手動處理資料夾失敗 {td}: {e}")
                continue

            for pdf in incomplete:
                try:
                    dest = subdir / pdf.name
                    if dest.exists():
                        # 同名衝突 → 加序號
                        counter = 2
                        while counter < 99:
                            alt = subdir / f"{pdf.stem}_{counter}{pdf.suffix}"
                            if not alt.exists():
                                dest = alt
                                break
                            counter += 1
                    pdf.rename(dest)
                    moved_pdf += 1
                except Exception as e:
                    write_log(f"移動 PDF 失敗 {pdf.name}: {e}")
            
            for z in zips_match:
                try:
                    dest = subdir / z.name
                    if dest.exists():
                        counter = 2
                        while counter < 99:
                            alt = subdir / f"{z.stem}_{counter}{z.suffix}"
                            if not alt.exists():
                                dest = alt
                                break
                            counter += 1
                    z.rename(dest)
                    moved_zip += 1
                except Exception as e:
                    write_log(f"移動 ZIP 失敗 {z.name}: {e}")
    
    return moved_pdf, moved_zip


def _mark_completed_zips(target_dirs: set, session_results: list = None) -> int:
    """v2.28.15：對「解出的所有檔案都成功且無【缺】」的 ZIP 加 [已完成] 前綴
    
    判斷邏輯（v2.28.15 重寫）：
      - 主路徑（有 session_results）：從 session_results 重建「ZIP → 解出的 outputs」對應
        對每個 ZIP：
          - 若 ZIP 本身狀態 != 成功 → 不標
          - 若它解出 0 個檔 → 不標（避免空 zip 被誤標）
          - 若 outputs 任一含【缺】或狀態 != 成功 → 不標
          - 否則 → 標 [已完成]
      - Fallback（沒 session_results 或舊路徑）：用日期匹配（原 v2.28.6 邏輯，但只當沒 session 資訊時用）
    
    回傳：標記 ZIP 數
    """
    count = 0
    
    # ===== 主路徑：用 session_results =====
    if session_results:
        # 重建 ZIP → outputs 對應
        # results 是 flat list，順序為 [ZIP1_result, ZIP1_inner1, ZIP1_inner2, ..., ZIP2_result, ...]
        # 或直接是 PDF 處理結果（沒 ZIP 包裝）
        ZIP_EXTS = {'.zip', '.rar', '.7z'}
        zip_to_outputs = {}  # zip_name → list of (狀態, 輸出, 訊息)
        current_zip = None
        for r in session_results:
            fname = r.get('檔名', '')
            suffix = Path(fname).suffix.lower() if fname else ''
            if suffix in ZIP_EXTS:
                # 這是一個 ZIP 結果
                current_zip = fname
                zip_to_outputs[current_zip] = {
                    'main_status': r.get('狀態', ''),
                    'outputs': []  # list of (狀態, 輸出名)
                }
            else:
                # inner file 結果，掛到目前 ZIP 下
                if current_zip is not None:
                    zip_to_outputs[current_zip]['outputs'].append({
                        '狀態': r.get('狀態', ''),
                        '輸出': r.get('輸出', ''),
                        '訊息': r.get('訊息', '')
                    })
        
        # 對每個 ZIP 判斷是否標記
        for td in target_dirs:
            if not td.is_dir():
                continue
            for f in td.iterdir():
                if not (f.is_file() and f.suffix.lower() in ZIP_EXTS):
                    continue
                if f.name.startswith('[已完成]'):
                    continue
                
                info = zip_to_outputs.get(f.name)
                if not info:
                    continue  # 不在這次處理的結果裡
                if info['main_status'] != '成功':
                    continue  # ZIP 解壓失敗
                outputs = info['outputs']
                if not outputs:
                    continue  # 空 zip，不標（避免誤標）
                
                # 檢查所有 outputs 都成功 + 都沒【缺】
                all_ok = True
                for o in outputs:
                    if o['狀態'] != '成功':
                        all_ok = False
                        break
                    out_name = o['輸出'] or ''
                    if '【缺' in out_name:
                        all_ok = False
                        break
                if not all_ok:
                    continue
                
                # 全部 OK → 標 [已完成]
                new_name = f"[已完成] {f.name}"
                new_path = f.parent / new_name
                if new_path.exists():
                    continue
                try:
                    f.rename(new_path)
                    count += 1
                    write_log(f"標記已完成 | {f.name}")
                except Exception as e:
                    write_log(f"標記已完成失敗 {f.name}: {e}")
        return count
    
    # ===== Fallback：沒 session_results 時用原日期邏輯 =====
    smart_pdf_pattern = re.compile(r'^(1\d{2})(0[1-9]|1[0-2])(0[1-9]|[12]\d|3[01])-')
    for td in target_dirs:
        if not td.is_dir():
            continue
        complete_ad_dates = set()
        for f in td.iterdir():
            if not (f.is_file() and f.suffix.lower() == '.pdf'):
                continue
            if '【缺' in f.name:
                continue
            m = smart_pdf_pattern.match(f.name)
            if m:
                try:
                    y = int(m.group(1)) + 1911
                    complete_ad_dates.add(f"{y}{m.group(2)}{m.group(3)}")
                except Exception:
                    pass
        if not complete_ad_dates:
            continue
        
        # Fallback：用日期匹配（原 v2.28.6 邏輯）
        for f in td.iterdir():
            if not (f.is_file() and f.suffix.lower() in ('.zip', '.rar', '.7z')):
                continue
            if f.name.startswith('[已完成]'):
                continue
            zip_dates = re.findall(r'20\d{6}', f.name)
            if not zip_dates:
                continue
            if any(d in complete_ad_dates for d in zip_dates):
                new_name = f"[已完成] {f.name}"
                new_path = f.parent / new_name
                if new_path.exists():
                    continue
                try:
                    f.rename(new_path)
                    count += 1
                    write_log(f"標記已完成 | {f.name}")
                except Exception as e:
                    write_log(f"標記已完成失敗 {f.name}: {e}")
    return count


def main():
    print_banner()

    # === 防止電腦睡眠（避免大量檔案處理途中被中斷）===
    _prevent_sleep_handle = _prevent_sleep_start()

    # === 執行鎖：避免短時間內被執行兩次（例如 .bat 重複呼叫）===
    import time
    lock_file = BASE_DIR / ".running.lock"
    now = time.time()
    if lock_file.exists():
        try:
            last_run = lock_file.stat().st_mtime
            if now - last_run < 10:  # 10 秒內有另一個實例在跑
                print("⚠️  偵測到另一個程式實例正在執行中（10 秒內）")
                print("    為避免重複處理檔案，本次執行已取消。")
                print("    如果你確定要再跑一次，請刪除「.running.lock」檔案。")
                input("\n按 Enter 結束...")
                return
        except Exception:
            pass
    # 建立/更新鎖檔
    try:
        lock_file.touch()
    except Exception:
        pass

    try:
        rules = load_rules()
        args = sys.argv[1:]

        # v2.28：--rename 模式（in-place 重命名，不複製、不解密）
        if args and args[0] == '--rename':
            rename_targets = args[1:]
            if not rename_targets:
                print("⚠️  --rename 模式需要指定資料夾或檔案路徑")
                input("\n按 Enter 結束...")
                return
            print("=" * 64)
            print("📝 v2.28 重新命名模式")
            print("=" * 64)
            print("    對已解密的 PDF 直接 in-place 重命名")
            print("    使用最新解析邏輯，不複製、不解密、不轉檔")
            print("=" * 64)
            rename_only_mode(rename_targets)
            input("\n按 Enter 結束...")
            return

        fail_count = 0

        # === 載入歷史紀錄（用於判重）===
        global _DEDUP_HISTORY
        _DEDUP_HISTORY = load_history()
        if _DEDUP_HISTORY:
            total_records = sum(len(v) for v in _DEDUP_HISTORY.values())
            print(f"📚 已載入歷史紀錄：{len(_DEDUP_HISTORY)} 個保單，{total_records} 筆檔案指紋")
            print(f"   （保留最近 {HISTORY_RETENTION_DAYS} 天的紀錄，自動去重）")
            print()

        if args:
            # 偵錯：顯示實際傳入的參數
            print(f"🔧 接收到 {len(args)} 個參數：")
            for i, a in enumerate(args, 1):
                print(f"   [{i}] {a}")
            print()

            files = collect_files(args)
            if not files:
                # v2.28：拖資料夾進來但「沒有可解密的檔案」時，掃描可重新命名的 PDF
                # 三類目標：
                #   (a) 含【缺】標記的（智慧命名格式但缺資料）
                #   (b) 含「-破解」後綴但無智慧命名的（已解密但沒命名）
                #   (c) 完全沒智慧命名格式的（如 RL_RL037_..._.pdf）
                smart_pat = re.compile(r'^1[0-9]{2}[01][0-9][0-3][0-9]-')
                rename_targets = []
                for arg in args:
                    p = Path(arg)
                    cands = []
                    if p.is_dir():
                        for ext in ['*.pdf', '*.PDF']:
                            cands.extend(p.glob(ext))
                    elif p.is_file() and p.suffix.lower() == '.pdf':
                        cands.append(p)
                    for f in cands:
                        if smart_pat.match(f.name):
                            # 已智慧命名 → 只有含【缺】才處理
                            if '【缺' in f.name:
                                rename_targets.append(f)
                        else:
                            # 沒智慧命名 → 全部送 rename（含 -破解、原始檔名）
                            rename_targets.append(f)
                if rename_targets:
                    print(f"\n📝 偵測到 {len(rename_targets)} 個可重新命名的 PDF")
                    print("    （含【缺】標記、-破解後綴、或無智慧命名的檔案）")
                    print("    自動切換到「重新命名模式」（不複製、不解密、直接 in-place 改名）\n")
                    rename_only_mode([str(f) for f in rename_targets])
                    input("\n按 Enter 結束...")
                    return
                print("⚠️  沒有可處理的檔案")
                input("\n按 Enter 結束...")
                return

            # v2.28：如果蒐集到的「全是含【缺】PDF」，也自動走 rename
            all_problem_pdfs = all(
                f.suffix.lower() == '.pdf' and '【缺' in f.name for f in files
            )
            if all_problem_pdfs and len(files) > 0:
                print(f"\n📝 偵測到 {len(files)} 個含【缺...】標記的 PDF")
                print("    自動切換到「重新命名模式」（不複製、不解密、直接 in-place 改名）\n")
                rename_only_mode([str(f) for f in files])
                input("\n按 Enter 結束...")
                return

            # 防護機制：用「真實絕對路徑」去重
            seen_paths = set()
            unique_files = []
            for f in files:
                try:
                    real_path = str(f.resolve())
                except Exception:
                    real_path = str(f.absolute())
                if real_path not in seen_paths:
                    seen_paths.add(real_path)
                    unique_files.append(f)
            files = unique_files

            # 計算「資料夾總檔數」vs「待處理數」，提示斷點續跑狀況
            total_in_dirs = 0
            for arg in args:
                p = Path(arg)
                if p.is_dir():
                    for ext in ['*.pdf', '*.PDF', '*.xlsx', '*.xls', '*.xlsm',
                                '*.XLSX', '*.XLS', '*.XLSM', '*.zip', '*.ZIP',
                                '*.rar', '*.RAR', '*.csv', '*.CSV', '*.7z', '*.7Z']:
                        total_in_dirs += len(list(p.glob(ext)))
            if total_in_dirs > len(files) + 5:
                skipped = total_in_dirs - len(files)
                print(f"♻️  斷點續跑：跳過 {skipped} 個已處理過的檔案（智慧命名/含「-破解」字樣）")
                print(f"   只處理剩餘的 {len(files)} 個新檔案\n")

            # 檢查：若有 .rar 但沒裝 unrar 工具，提早警告
            has_rar = any(f.suffix.lower() == '.rar' for f in files)
            if has_rar and not RARFILE_AVAILABLE:
                print()
                print("=" * 64)
                print("⚠️  偵測到 .rar 檔案，但找不到解壓工具！")
                print("=" * 64)
                print()
                print("  .rar 格式需要以下任一工具：")
                print("  1. 安裝 Bandizip（免費）：https://www.bandisoft.com/bandizip/")
                print("  2. 安裝 7-Zip（免費）：https://www.7-zip.org/")
                print("  3. 安裝 WinRAR：https://www.win-rar.com/")
                print("  4. 或將 UnRAR.exe 放到本工具資料夾")
                print()
                print("  安裝完任一工具後，重新跑本程式即可。")
                print("  .rar 檔案將被略過，其他檔案仍會正常處理。")
                print("=" * 64)
                print()

            print(f"🔍 找到 {len(files)} 個檔案，開始處理...\n")

            # 若檔案數超過 20 個，詢問是否啟用「全程自動模式」（不問手動密碼）
            global _SKIP_ALL_MANUAL
            if len(files) >= 20:
                print("=" * 64)
                print(f"📦 偵測到大量檔案（{len(files)} 個）")
                print("=" * 64)
                print("   你想用哪種模式？")
                print("   [Enter] 預設：自動破解失敗時逐一詢問密碼")
                print("   [A]     全程自動：失敗的直接跳過，最後集中列出清單 ⭐ 推薦")
                print("=" * 64)
                try:
                    choice = input("   選擇 > ").strip().upper()
                    if choice == 'A' or choice == 'ALL':
                        _SKIP_ALL_MANUAL = True
                        print("   ✅ 已啟用全程自動模式，失敗的檔案會自動列入待辦清單\n")
                    else:
                        print("   （使用預設模式，失敗時會詢問密碼）\n")
                except (EOFError, KeyboardInterrupt):
                    _SKIP_ALL_MANUAL = True
                    print("\n   ✅ 已啟用全程自動模式\n")

            all_results = []
            for i, f in enumerate(files, 1):
                print(f"[{i}/{len(files)}] 🔍 {f.name}")
                results = process_single(f, rules)
                all_results.extend(results)
                for r in results:
                    if r["狀態"] == "成功":
                        suffix_info = ""
                        if r["公司"] != "無密碼":
                            suffix_info = f"  ({r['公司']} / {r['密碼']})"
                        print(f"   ✅ {r['輸出']}{suffix_info}")
                    elif r["狀態"] == "失敗":
                        print(f"   ❌ {r['訊息']}")
                    write_log(f"{r['狀態']} | {r['檔名']} | {r['公司']} | {r['密碼']} | {r['訊息']}")

                # 每 20 個檔就 save 一次 history，避免中斷後重複處理
                if i % 20 == 0 and _DEDUP_HISTORY is not None:
                    try:
                        save_history(_DEDUP_HISTORY)
                    except Exception:
                        pass

            # 第二輪：跨檔交叉比對（從同資料夾的「簽收表」反查保單號）
            # 蒐集所有目標資料夾
            target_dirs = set()
            for f in files:
                target_dirs.add(f.parent)
            cross_fix_count = 0
            cross_rename_map = {}  # 紀錄改名對照 {舊名: 新名}
            for target_dir in target_dirs:
                fixed, rename_map = _cross_reference_policy(target_dir, return_map=True)
                cross_fix_count += fixed
                cross_rename_map.update(rename_map)
            if cross_fix_count > 0:
                print()
                print(f"🔗 跨檔交叉比對：補回 {cross_fix_count} 個檔案的保單號")

                # 更新 all_results 裡的「輸出」欄位，反映改名結果
                for r in all_results:
                    out = r.get('輸出', '')
                    if out and out in cross_rename_map:
                        r['輸出'] = cross_rename_map[out]
                        r['訊息'] = (r.get('訊息') or '') + ' + 跨檔補保單號'

            fail_count = print_summary(all_results)
            # v2.28.8：args 模式結束後跑整理階段
            cleanup_dirs = set()
            for arg in args:
                pa = Path(arg)
                if pa.is_dir():
                    cleanup_dirs.add(pa)
                elif pa.is_file():
                    cleanup_dirs.add(pa.parent)
            _run_cleanup_phase(cleanup_dirs, session_results=all_results)
        else:
            interactive_mode(rules)

        if fail_count > 0:
            print()
            print("⚠️ " * 20)
            print(f"⚠️  請注意：本次有 {fail_count} 個檔案破解失敗，請查看上方清單")
            print("⚠️ " * 20)

        # === 儲存歷史紀錄 ===
        if _DEDUP_HISTORY is not None:
            save_history(_DEDUP_HISTORY)

        input("\n按 Enter 結束...")

    finally:
        # 清除鎖檔
        try:
            if lock_file.exists():
                lock_file.unlink()
        except Exception:
            pass
        # 恢復睡眠設定
        try:
            _prevent_sleep_stop(_prevent_sleep_handle)
        except Exception:
            pass


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n使用者中斷")
    except Exception as e:
        print(f"\n💥 程式發生未預期錯誤：{e}")
        import traceback
        traceback.print_exc()
        input("\n按 Enter 結束...")
