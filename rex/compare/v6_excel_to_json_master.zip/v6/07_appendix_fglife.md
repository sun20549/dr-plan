# 附錄 07:遠雄人壽 (`fglife/`)

> 遠雄特殊在「**萬元/千元單位陷阱**」(規則 O)、躉繳 demo 標記、養老 protection_period。

---

## 🚫 遠雄補充鐵律

22. **嚴禁把「商品預定利率」當成 declared_rate** —— 那是 `guaranteed_rate`,要查另一個欄位才是宣告利率。

---

## 🔧 規則 O 萬元三重判斷

遠雄部分商品 `base_sa` 用「萬元」單位寫,要正確還原:

```python
def detect_unit_fglife(ws, raw_sa):
    """三重判斷,有任何一重命中就轉成元"""
    # 第 1 重:輸入頁有「萬元」字樣
    for r in range(1, 30):
        for c in range(1, 30):
            v = ws.cell(r, c).value
            if isinstance(v, str) and '萬元' in v:
                # 鎖定主約 SA 區的「萬元」標籤
                if abs(c - sa_col) <= 3:
                    return 'wan'

    # 第 2 重:輸入頁有「保險金額範圍:20~6,000萬元」
    for r in range(1, 50):
        row_text = ' '.join(str(ws.cell(r, c).value or '') for c in range(1, 30))
        if re.search(r'保險金額.*萬元', row_text):
            return 'wan'

    # 第 3 重 fallback:sa < schedule[0].death_benefit / 0.95 → 推測萬元
    if raw_sa < schedule[0]['death_benefit'] / 0.95:
        return 'wan'

    return 'yuan'

# 套用
if unit == 'wan':
    base_sa = raw_sa * 10000
```

---

## 🎯 躉繳 demo 標記

部分商品試算表只跑躉繳情境,但商品本身可能多年期。打兩個 flag:

```python
{
  "premium_mode": "lump_sum",
  "is_lump_sum_demo": true   # 試算僅躉繳,DM 上是 6/10 年期商品
}
```

範例:遠雄 BO1/BB1/BI1/BY1/BT1/BQ1/WQ1/WN1/WR1 共 9 檔。

---

## 🎯 養老型 protection_period

養老商品標記:

```python
{
  "is_endowment": true,
  "product_type": "endowment",
  "protection_period": 10   // Y10 滿期
}
```

範例:
- BY1 protection_period=10
- BT1 protection_period=7
- BQ1 protection_period=10

⚠️ Excel 試算情境是 protection_period,但 **DM 可能 6/10/15/20 都有**(同商品多年期),要查 DM 補齊。

---

## 🆔 unit_size 不一致

遠雄商品 `unit_size` 兩種寫法並存:

| 商品 | unit_size |
|---|---|
| BU1 / SP1(舊批) | `100` |
| 新批 13 個 | `1000` |

前端 STEP2 要按各商品自己的 `unit_size` 算保額,**不可全 force 1000**。

---

## 📥 base_premium 來源優先序

```python
# 優先序: 從 schedule[0]['cum_prem'] 抓(如果 schedule 第一筆是好的)
# 否則 gross × (1-discount)
if schedule and schedule[0].get('cum_prem'):
    base_premium = schedule[0]['cum_prem']
else:
    base_premium = base_premium_gross * (1 - discount)
```

---

## 📦 部署資料夾

`data/fglife/<plan_code>.json`(全小寫)

---

## ⚠️ 遠雄目前 PENDING(2026-05-07)

- 9 個躉繳 demo 商品(BO1/BB1/BI1/BY1/BT1/BQ1/WQ1/WN1/WR1):需要的話另抽多年期版本
- 養老 protection_period 校對(BY1=10/BT1=7/BQ1=10 是 Excel 情境,DM 可能不同)
