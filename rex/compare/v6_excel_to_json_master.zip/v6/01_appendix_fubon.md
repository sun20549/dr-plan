# 附錄 01:富邦人壽 (`fubon/`)

> Master 未涵蓋的富邦特定處理。沒列在這的全部依 master。

---

## 🚫 富邦補充鐵律(編號續 master 18 條)

19. **嚴禁從 R43 之前抽 currency** — 可能撞到「累計新臺幣2000萬」法規條文。先掃 R44+「計價幣別」標籤。
20. **嚴禁全表掃描抽 base_sa** — 必須鎖定「主約險種代號」下方那列(否則會撞到附約保額)。
21. **嚴禁忽略 Y1 vs Y2 cum_prem 差異** — `>1%` 代表附約保費分離,要 SKIP。

---

## 🔍 Step 0 額外偵測

### 0-α:商品全名強制印出(`R2` 必抓)

```python
ws = wb['輸入頁'] if '輸入頁' in wb.sheetnames else wb[wb.sheetnames[0]]
for r in range(1, 5):
    row = list(ws.iter_rows(min_row=r, max_row=r, values_only=True))[0]
    for v in row:
        if v and isinstance(v, str) and len(v) > 5:
            if '專案試算表' in v or '富邦人壽' in v:
                print(f"商品全名:{v}")
```

避免被 sheet 名誤導(sheet 名常是縮寫)。

### 0-β:混合型線索(SKIP 用)

```python
for r in range(5, 15):
    row = list(ws.iter_rows(min_row=r, max_row=r, values_only=True))[0]
    text = ' '.join(str(v) for v in row if v)
    if any(kw in text for kw in ['意外身故', '失能保險金', '燒燙傷', '住院醫療']):
        # AJI 安康如意這種「意外+醫療+生存」混合型 → SKIP
        return 'unsupported'
```

### 0-γ:歲滿期型偵測

```python
for r in range(20, 50):
    text = ' '.join(str(v) for v in
                    list(ws.iter_rows(min_row=r, max_row=r, values_only=True))[0]
                    if v)
    if '歲滿期' in text or '繳費至' in text:
        # 例:PAJ 優富年年「繳費至 55 歲」
        # period = 55 - base_age
```

### 0-δ:富邦 sheet 結構速查

| Sheet 組合 | 引擎 |
|---|---|
| 總表 + 列印頁-簡 + 輸入頁 | `twlife_v1` |
| 總表_分紅_H + _M + _L | `prudential_v2` |
| ROP / tbULMultiple / 計算內容-正/零/負 | ❌ 投資型不支援 |
| 操作主畫面 / AnnFactor | ❌ 年金險不支援 |

---

## 📥 Step 1 額外處理

### 1-α:currency 鎖定 R44+

```python
def find_currency_fubon(ws):
    for r in range(44, ws.max_row + 1):
        for c in range(1, ws.max_column + 1):
            v = ws.cell(r, c).value
            if isinstance(v, str) and '計價幣別' in v:
                # 右側格子是答案
                for cc in range(c+1, c+5):
                    val = ws.cell(r, cc).value
                    if isinstance(val, str) and val.strip() in ('美元', '新台幣', '澳幣', '人民幣'):
                        return {'美元':'USD','新台幣':'TWD','澳幣':'AUD','人民幣':'CNY'}[val.strip()]
    return None
```

### 1-β:base_sa 鎖定主約

```python
def find_base_sa_fubon(ws):
    # 找「主約險種代號」字樣 row,**下一 row** 同 col 才是 base_sa
    for r in range(1, ws.max_row + 1):
        for c in range(1, ws.max_column + 1):
            v = ws.cell(r, c).value
            if isinstance(v, str) and '主約險種代號' in v:
                # 該 row 下一 row 同位置 col + 偏移找 SA
                for cc in range(c, c+10):
                    val = ws.cell(r+1, cc).value
                    if isinstance(val, (int, float)) and val >= 10000:
                        return val
    return None
```

### 1-γ:躉繳獨立 keyword

```python
period_kw = ['繳費年期', '繳別', '繳費期間', '保險年期']
lump_kw   = ['躉繳', '一次繳', 'Single']
# 先看有無 lump_kw,有則 period=1 + premium_mode='lump_sum'
```

---

## 📊 Step 2 額外處理

### 2-α:Y1 vs Y2 cum_prem 差異檢查

```python
diff_pct = abs(sched[1]['cum_prem'] - 2 * sched[0]['cum_prem']) / sched[0]['cum_prem']
if diff_pct > 0.01:
    # >1% 代表 Y1 包含附約保費,Y2 起不包含
    # 整檔 SKIP,因為主約保費被附約污染了
    return 'unsupported_附約污染'
```

### 2-β:simple_print_v1 引擎(部分老 PFA 系列)

某些只有「列印頁-簡」沒「總表」的舊版商品,走 simple_print_v1 流程:
- header 動態範圍判斷:標題列在 R5/R6/R7 之一
- col 全靠 keyword 動態定位

---

## 🧰 富邦引擎程式

```python
import sys
sys.path.insert(0, '/path/to/v6/engines')
from fubon_v5_engine import FubonExtractor

ext = FubonExtractor(xlsx_path)
result = ext.extract()  # 回傳 dict,含 meta + schedule
```

引擎程式位於 `engines/fubon_v5_engine.py`(已驗證 58 個富邦商品)。

---

## 📦 部署資料夾

`data/fubon/<plan_code>.json`(全小寫)

---

## ⚠️ 富邦目前 PENDING(2026-05-07)

- 38 個 `min_sa/max_sa/max_age` 用業界預設,要查 DM
- 13 個分紅商品 `mid_dividend_rate` 業界預設,要查 DM
- FBN 為首個富邦 AUD 商品,前端要支援
- FCG Y17-Y94 DB=0 需查原 Excel
- PFG/PALA_B_C/PFW/PF55_60_65 退休型 cv 中後期下降(規則 M 提示)
- FED/FEF 養老型 schedule 短(規則 M 提示)
- XMM/FEF 含生存金(規則 M 提示)
- XWS5 純壽險 IRR ≈ 0(規則 M 提示)
