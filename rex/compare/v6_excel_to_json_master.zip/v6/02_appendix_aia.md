# 附錄 02:友邦人壽 (`AIA/`,大寫!)

> 友邦特色是 **RV 表手算**(Excel 公式 `MID/DATEVALUE` 解析民國年字串,LibreOffice 重算後仍 #VALUE!,但 FACTOR/PREM 表純數字可讀),master 走 Step 0.5-A 分支進這裡。

---

## 🚀 強制走 aia_engine

**不要自己重寫手算邏輯**,引擎已驗證 18 個友邦商品。

### 處理流程

```bash
# 單檔(.xls,自動先 recalc)
python aia_extract_cli.py UWHL-V2.xls -o ./output --recalc

# 批次(資料夾或 glob)
python aia_extract_cli.py "*.xls" -o ./output --recalc --batch

# 批次並打包成 zip
python aia_extract_cli.py "*.xls" -o ./output --recalc --batch --pack
```

### 程式介面

```python
import sys
sys.path.insert(0, '/path/to/v6/engines')
from aia_engine import AIAExtractor

ext = AIAExtractor(xlsx_path, plan_code='UWHL-V2')
result = ext.extract()    # dict, 含 meta + schedule

# 寫乾淨 JSON
clean = ext.to_clean_dict(result)
```

引擎已包含:
- `aia_engine.py` — 主抽取邏輯(支援 stepped/還本/養老/RV手算)
- `aia_recalc.py` — `.xls → .xlsx` LibreOffice 批次重算(必須在同一 bash call 內)
- `aia_extract_cli.py` — CLI 入口 + manifest/PRODUCTS 自動產出

---

## 🔍 Step 0 偵測(自動分流)

```python
# 偵測友邦 RV 表型
sheet_names = wb.sheetnames
if all(s in sheet_names for s in ['FACTOR', 'PREM']) and \
   any('保險利益分析' in s for s in sheet_names):
    engine = 'aia_rv'  # 走 aia_engine 手算
```

`AIAExtractor` 內部會自動分流:
- RV 表型 → 走 FACTOR + PREM 手算 schedule
- 一般逐年表型(較新商品) → 走 schedule 直抽

---

## 📥 base_age 反推(GP factor 法)

某些友邦商品 base_age 在 Excel 找不到,用 GP factor 反推:

```python
# 範例:base_premium_gross=4180, base_sa=100000
# GP factor = 4180 / (100000/1000) = 41.8 per 1000
# 查 FACTOR 表(M xxx 列):找到 M30 PPP=6 對應 41.8 → base_age = 30
```

`aia_engine.py` 已實作這個反推邏輯,不用自己寫。

---

## 🆔 AIA 商品命名特色

- 檔名格式:`保險利益分析表_UWHL-V2_xxx.xls`
- plan_code 含版本號保留(`UWHL-V2`、`UWHL-V3` 是不同年期版本)
- 多年期商品 → 規則 E 寫多條 entry

---

## 📦 部署資料夾

`data/AIA/<plan_code>.json`(**大寫**!踩雷 #1:寫成 `aia/` 會 404)

manifest path 範例:
```json
{
  "key": "UWHL-V2",
  "path": "AIA/UWHL-V2.json",
  ...
}
```

---

## 📋 引擎產出的 type 字串對應

```python
def infer_type_str(meta):
    cur_zh = {'USD':'美元', 'TWD':'新台幣', 'AUD':'澳幣', 'CNY':'人民幣'}[meta['currency']]
    is_endow_type = meta.get('product_type') == 'endowment'
    is_endow = meta.get('is_endowment', False)
    has_dividend = '分紅' in meta.get('product_name', '')

    if is_endow_type:
        return f"{cur_zh}{'分紅' if has_dividend else '利率變動型'}養老保險"
    if has_dividend:
        return f"{cur_zh}{'分紅還本終身壽險' if is_endow else '分紅終身壽險'}"
    return f"{cur_zh}{'利率變動型還本終身壽險' if is_endow else '利率變動型終身壽險'}"
```

---

## ⚠️ 友邦目前 PENDING(2026-05-07)

- UED 養老險、UDISRI/URO/UWLS/UWLV 還本險、USWLB 倍數型 — 前端展示要規則 M 提示
- UWLS/UWLV 多 plan_cd 起始日問題(同 plan_code 不同 issue date)
