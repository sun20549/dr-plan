# 附錄 05:全球人壽 (`transglobe/`)

> 全球是「通用 twlife_v1」家族成員,master 流程跑得最順。本附錄只記錄已驗證的 32 個 .xls 偵察結果與少量陷阱。

---

## 🔍 全球專屬 Step 0 偵測

```python
# 全球商品 sheet 慣性結構
if '逐年表' in wb.sheetnames or '明細表' in wb.sheetnames:
    if '輸入頁' in wb.sheetnames or '基本資料' in wb.sheetnames:
        engine = 'twlife_v1'
```

---

## 🆔 plan_code 規律

- 一律大寫英數,如 `RPF` / `RPI` / `QJP` / `RPLBR`
- 部分 V2 / V3 後綴(版本號)
- 一個 plan_code = 一個年期(對齊規則 E:多條 entry)

---

## ⚠️ 已知陷阱

1. **資料檢核頁順序錯亂** —— 抽完一律強制 sort(鐵律 14)
2. **某些舊版逐年表 col 17/20/27 漂移** —— 用 keyword 動態偵測(鐵律 12)
3. **QJP 的 currency 推斷為 TWD** —— 原 JSON meta 是 None,要查 DM 確認

---

## 📦 部署資料夾

`data/transglobe/<plan_code>.json`(全小寫)

---

## ⚠️ 全球目前 PENDING(2026-05-07)

- 22 個商品 `min_sa/max_sa/max_age` 用業界預設,要查 DM
- QJP `currency=TWD` 是推斷值,要查 DM 確認
