# 附錄 03:保誠人壽 (`prudential/`)

> 保誠特色是 **layout A / B 兩種版型** + **三情境分紅(L/M/H)**,master 走 `prudential_v2` 引擎進這裡。

---

## 🚀 強制走 prudential_extractor.py

引擎已驗證:layout A 85 欄、layout B 67 欄、分區結構、13 條自洽性驗證、檔名 vs 內容驗證、重複版本檢測、批次模式。

### CLI 用法

```bash
# 單檔
python prudential_extractor.py 檔案.xls --output ./out/

# 批次
python prudential_extractor.py *.xls --batch --output ./out/

# 只驗檔名 vs 內容(不抽)
python prudential_extractor.py 檔案.xls --check-only

# 跳過版本檢查(強制覆蓋)
python prudential_extractor.py 檔案.xls --force-overwrite

# 跳過自洽性驗證(慎用)
python prudential_extractor.py 檔案.xls --skip-validation

# 詳細日誌
python prudential_extractor.py 檔案.xls -v
```

### 退出碼

| Code | 含義 |
|---|---|
| 0 | 成功 |
| 1 | 自洽性驗證失敗 ❌ |
| 2 | 跳過(檔名錯 / 已有更新版本) |
| 3 | 不支援(非 prudential_v2 結構) |
| 4 | 系統錯誤(LibreOffice 失敗、檔不存在) |

---

## 🔍 layout A vs B 偵測(自動分流)

```python
r4_c2 = ws.cell(4, 2).value
r2_c1 = ws.cell(2, 1).value

if isinstance(r4_c2, str) and '保單' in r4_c2:
    layout = 'A'  # 67 欄,分區結構,Profits1/2/3 區段並列
elif r2_c1 == '年期':
    layout = 'B'  # 85 欄,直線排列,Profits_1/2/3 sheet 分離
```

---

## 🎯 prudential_v1 vs v2

| 引擎 | 適用 | 商品 |
|---|---|---|
| `prudential_v1` | 保誠 RV 大表 | 僅 ARLPLU71 |
| `prudential_v2` | 三情境分紅 | 其他 14 個保誠 + 富邦 18 + 台壽 5 + 安達 3 |

`prudential_extractor.py` 只處理 v2。v1 是個案手工處理,沒有自動引擎。

---

## 📋 三情境 schedule 結構

```json
{
  "schema": "v4",
  "meta": {
    "engine": "prudential_v2",
    "scenarios": ["L", "M", "H"],
    "mid_dividend_rate": 0.056,    // 保誠專用預設
    ...
  },
  "schedule":   [...],   // 中分紅(M)
  "schedule_l": [...],   // 低分紅
  "schedule_h": [...]    // 高分紅
}
```

**自洽驗證**:

```python
# H > M > L 每年都成立
for y in range(len(schedule_m)):
    assert schedule_h[y]['cv_total'] >= schedule_m[y]['cv_total']
    assert schedule_m[y]['cv_total'] >= schedule_l[y]['cv_total']
```

---

## 🆔 保誠商品 plan_code 規律

- `ACLPxx` / `ACLPENxx` / `ARLPLUxx` 系列
- 不同年期用不同 plan_code(如 ACLPEN26 / ACLPEN36)→ 規則 E 寫多條 entry

---

## 📦 部署資料夾

`data/prudential/<plan_code>.json`(全小寫)

⚠️ ARLPLU71 因歷史因素**部署在根目錄**:`data/ARLPLU71.json`,manifest path 寫 `ARLPLU71.json`(沒前綴)。

---

## ⚠️ 保誠目前 PENDING(2026-05-07)

- ARLPLU71 `period=1` 為暫定值(已從缺漏修為 1),實際年期需查保誠 DM 確認
