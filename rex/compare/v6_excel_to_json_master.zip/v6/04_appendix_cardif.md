# 附錄 04:法商法國巴黎人壽 (Cardif Life Taiwan)

> 法巴(Cardif)是儲蓄險專業公司,規模小但檔案結構特殊 ——
> **流通的是「公版空白模板」需要先填值才能重算**,跟其他 8 家完全不同。
> 走 `prudential_v2` 引擎,但**前置**處理走本附錄專屬流程。

---

## 0. 何時觸發本附錄

任一條件成立 → company 寫 `Cardif`,engine 強制 `prudential_v2`:

1. 檔名含「美吉鴻運 / 美添鴻運 / 鴻運旺旺來 / 鴻運滿億 / 鴻運金喜 / 鴻運雙享」
2. 檔內 R8 / R3 / R5 含「法商法國巴黎人壽」或「法國巴黎人壽」
3. `面頁` sheet 存在且 R3C3 含「POS Model」字串
4. plan_code 開頭為 `PRU` / `PRT` / `PCT`

---

## 1. 公司命名 (規則 C1-C3)

| 欄位 | 值 |
|---|---|
| `company` | `Cardif`(**不可寫**「法國巴黎人壽」「BNP Paribas Cardif」「巴黎」等變體) |
| `product_name` | 從 `商品摘要表` R3C1 抽,**依序**去除前綴:`● ` / `※ ` / `法商法國巴黎人壽` / `法國巴黎人壽` / `Cardif` |

**禁止**:
- ❌ 用 R6 做商品名來源(R6 是免責聲明,以 `*` / `※` 開頭)
- ❌ 自行翻譯「定期給付型」為 `stepped` / `scheduled` 等英文,保持原中文

---

## 2. 公版空白模板處理(最關鍵)

### C4:辨識空白模板

特徵任一成立:
1. 檔名以「公版_」開頭
2. `輸入頁` R22 / R24 D 欄為 None / 0
3. `商品利益說明表` R5 顯示「保額:0元 / 首期原始保費:0元」
4. schedule sheet Y1 行所有數值欄都是 0 或 None

**遇到空白模板**:
- ❌ 不可直接抽 0 / None 當數據(違反鐵律 13)
- ❌ 不可在沒填值就停下產出空 schedule
- ❌ 不可標 `data_status: "template_only"` 然後交付

**正確流程** → 走 C5 fill+recalc。

### C5:fill+recalc 標準流程

#### C5.1 修補 autofilter(必跑,如果是 .xls 經 LibreOffice 轉來)

```python
import zipfile, re

def fix_autofilter(src_xlsx, dst_xlsx):
    """移除 sheet xml 內的 autoFilter,讓 openpyxl 可寫"""
    with zipfile.ZipFile(src_xlsx, 'r') as zin, \
         zipfile.ZipFile(dst_xlsx, 'w', zipfile.ZIP_DEFLATED) as zout:
        for item in zin.infolist():
            data = zin.read(item.filename)
            if item.filename.startswith('xl/worksheets/sheet') and item.filename.endswith('.xml'):
                txt = data.decode('utf-8')
                txt = re.sub(r'<autoFilter[^/]*/>', '', txt)
                txt = re.sub(r'<autoFilter[^>]*>.*?</autoFilter>', '', txt, flags=re.DOTALL)
                data = txt.encode('utf-8')
            zout.writestr(item, data)
```

原生 `.xlsx` 不需要這步。

#### C5.2 SA 輸入 cell 對應表

| 商品 | SA cell | 單位 | 標準值 | 對應實際保額 |
|---|---|---|---|---|
| 美吉鴻運 | `輸入頁!D24` | 萬元 | `10` | 100,000 USD |
| 美添鴻運 | `輸入頁!D22` | 萬元 | `10` | 100,000 USD |
| 鴻運旺旺來 | `輸入頁!D22` | 萬元 | `100` | 1,000,000 TWD |
| 鴻運滿億 | `輸入頁!D24` | 萬元 | `100` | 1,000,000 TWD |
| 鴻運金喜 | `輸入頁!D22` | 萬元 | `100` | 1,000,000 TWD |
| 鴻運雙享 | `輸入頁!D22` | 萬元 | `100` | 1,000,000 TWD |

⚠️ **`輸入頁` 提示字「以每千元為單位」不可信** —— 實測單位是「萬元」。
- USD 寫 10 → 100,000 USD ✅
- TWD 寫 100 → 1,000,000 TWD ✅
- USD 寫 100 → 1,000,000 USD(超過業界試算量)❌

寫入後驗證:重算後 R5 顯示「保額:100,000元」(USD) 或「保額:1,000,000元」(TWD)。

#### C5.3 寫入 + LibreOffice 重算

```python
import openpyxl, subprocess

def fill_and_recalc(src, sa_cell, sa_value, out_dir):
    wb = openpyxl.load_workbook(src)
    ws = wb['輸入頁']
    ws[sa_cell] = sa_value
    wb.save(src)

    out_dir.mkdir(parents=True, exist_ok=True)
    subprocess.run(
        ['libreoffice', '--headless', '--calc', '--convert-to', 'xlsx',
         '--outdir', str(out_dir), str(src)],
        capture_output=True, timeout=600
    )
    return out_dir / src.name
```

**timeout 設定**:單檔最多 600 秒。Cardif 大檔(如美吉 14 MB)需 3-5 分鐘重算。**不可批次跑 6 檔**(會超時),逐檔處理。

#### C5.4 驗證重算結果

```python
wb = openpyxl.load_workbook(recalc_path, data_only=True, read_only=True)
ws = wb['商品利益說明表(不含紅利部分)']  # 終身壽 OR
ws = wb['建議書']                       # 還本

r5_val = ws.cell(5, 1).value
assert r5_val and '0元' not in r5_val, f"重算未生效: R5={r5_val}"

y1_cum_prem = ws.cell(15, 4).value or ws.cell(16, 4).value
assert isinstance(y1_cum_prem, (int, float)) and y1_cum_prem > 0
```

驗證失敗 → 停下,告訴老闆,**不要繼續**。

---

## 3. Sheet 結構辨識(規則 C6-C7)

| 類型 | 商品 | schedule sheet | 特徵 |
|---|---|---|---|
| **whole_life** | 美吉、美添、旺旺來、金喜 | `商品利益說明表`(無尾隨空格,~421×14) | 終身壽,三情境垂直堆疊 |
| **endowment** | 滿億、雙享 | `建議書`(~393×18) | 還本,三情境垂直堆疊 |

```python
def classify_kind(wb):
    if '建議書' in wb.sheetnames:
        ws = wb['建議書']
        v = ws.cell(2, 5).value
        if isinstance(v, str) and '生存保險金' in v:
            return 'endowment'
    return 'whole_life'
```

### C7:display sheet 不可用作數據來源

| 不可用(display 用 OFFSET/VLOOKUP,重算後失效) | 可用(source) |
|---|---|
| `商品利益說明表(不含紅利部分) ` ⚠️**尾端有空格**,158×26 | `商品利益說明表` 無尾空格,421×14 |
| `紅利彙總表` 166×29 | (取自 schedule) |
| `建議書-簽名送件(基本資料須正確)` 部分版本 | `建議書` 393×18 |

判 sheet 名時注意尾隨空格(用 `repr(name)` 印出檢查)。

---

## 4. 三情境區塊定位(規則 C8-C9)

Cardif schedule sheet 是「三情境垂直堆疊」結構:

```
Y1 H, M, L
Y2 H, M, L
Y3 H, M, L
...
```

而非 prudential_v2 標準的「三 sheet 分離」(Profits_1/2/3)。

抽取時需:
1. 讀完整 schedule
2. 按 row 拆 H/M/L 三組
3. 寫入 JSON 時拆成 `schedule` (M) / `schedule_h` / `schedule_l`

詳細 col 對應見原 v5 法巴 delta 第 4-5 章。

---

## 5. 自洽性驗證(C10)

除 master Step 4 通用驗證外,Cardif 還需:

```python
# 身故倍率寬鬆規則
# Cardif 部分商品 Y1 db = 1.01 × cum_prem(法定最低身故倍率),不算 stepped
# 自洽驗證放寬:Y1 db 在 [base_sa × 0.5, base_sa × 1.05] 範圍內視為正常

# 分紅生效時間寬鬆規則
# Cardif 分紅是 Y3+ 才生效(其他公司多半 Y2+),驗證 H > M > L 從 Y3 開始檢查
```

---

## 📦 部署資料夾

`data/cardif/<plan_code>.json`(全小寫,新建,目前還沒有 Cardif 商品在 manifest)

---

## ⚠️ Cardif 目前 PENDING(2026-05-07)

- 6 個 Cardif 商品(美吉/美添/旺旺來/滿億/金喜/雙享)**尚未部署到 manifest**
- 需先批次跑 fill+recalc + 抽取(逐檔處理 600s timeout)
- 第一批部署時前端要新增 `cardif/` 資料夾識別
