# 附錄 08:安達人壽 (`chubb/`)

> 安達特殊在 **factor 是「每萬元美元」單位**(其他公司是「每千元」)、`section_bounds` 算法、GP 反推 base_age、TODAY() 公式陷阱。

---

## 🚫 安達補充鐵律

23. **嚴禁信任 LibreOffice 的 TODAY() 重算** —— 公式用 `TODAY()` 算保險年齡時,要 patch 寫死整數再重算(見下方「TODAY() 修補法」)。

---

## 🔧 factor 單位差異

| 公司 | factor 單位 |
|---|---|
| 一般 USD 商品 | 每**千**美元 |
| 一般 TWD 商品 | 每**萬**元 |
| **安達** | 每**萬**元美元 |

```python
# 安達 base_premium 反推
# 範例:金多美 base_premium_gross=17080, base_sa=200000
# GP factor = 17080 / (200000/10000) = 854 per 10000(每萬美元)
# 不是 17080 / (200000/1000) = 85.4 per 1000

if company == '安達人壽':
    factor_unit = 10000
else:
    factor_unit = 1000 if currency == 'USD' else 10000
```

---

## 🎯 GP 反推 base_age(安達常用)

安達商品 base_age 在 Excel 有時找不到(`#VALUE!` 或省略),用 GP factor 反查:

```python
# 範例:金多美 base_premium_gross=17080, base_sa=200000
gp_factor = 17080 / (200000 / 10000)   # = 854

# 查 FACTOR 表(MnnPPP 列):
# M40 PPP=6 → 836 (不對)
# M41 PPP=6 → 854 ✓
# 所以 base_age = 41
```

`prudential_extractor.py` 內有實作,安達商品走 prudential_v2 時自動處理。

---

## 🎯 section_bounds 算法

安達 schedule sheet 多區段,每段的 `start_row` 與 `end_row` 要動態算:

```python
def compute_section_bounds(sections):
    """
    sections = [{'name':'男_M40','start_row':10}, {'name':'男_M41','start_row':120}, ...]
    每段 end_row = 下一段 start_row - 6 (header 占用)
    """
    sections = sorted(sections, key=lambda s: s['start_row'])
    for i, s in enumerate(sections):
        if i + 1 < len(sections):
            s['end_row'] = sections[i+1]['start_row'] - 6
        else:
            s['end_row'] = ws.max_row
    return sections
```

---

## 🎯 TODAY() 公式修補法

安達某些商品保險年齡公式用 `=YEAR(TODAY()) - YEAR(出生日)`,LibreOffice 重算後仍 `#VALUE!`:

```python
# patch 寫死整數再重算
def patch_today_formula(xlsx_path):
    wb = openpyxl.load_workbook(xlsx_path)
    ws = wb['輸入頁']

    # 找含 TODAY() 的 cell,改成寫死整數
    for row in ws.iter_rows():
        for cell in row:
            if isinstance(cell.value, str) and 'TODAY()' in cell.value:
                # 計算當前日期序號(Excel epoch:1900-01-01 = 1)
                from datetime import date
                today_serial = (date.today() - date(1900, 1, 1)).days + 2
                cell.value = cell.value.replace('TODAY()', str(today_serial))

    wb.save(xlsx_path)
    # 然後再走 LibreOffice 重算
```

---

## 🔧 規則 C 安達特殊:文字解析投保金額

R31C6 / R17C6 文字含投保金額限制,要 regex 抽:

```python
import re

def parse_sa_limit_chubb(text):
    """
    R31C6: '保險金額:3000美元~250萬美元' / '1萬~1000萬美元' / '2萬美元~300萬美元'
    """
    text = str(text).replace(',', '')
    pat = re.compile(r'(\d+(?:\.\d+)?)\s*(萬)?\s*(?:美元)?\s*[~～]\s*(\d+(?:\.\d+)?)\s*(萬)?\s*(?:美元)?')
    m = pat.search(text)
    if m:
        min_v = float(m.group(1)) * (10000 if m.group(2) else 1)
        max_v = float(m.group(3)) * (10000 if m.group(4) else 1)
        return int(min_v), int(max_v)
    return None
```

抽到的優先用,抽不到再走 master 規則 C 預設值。

---

## 🎯 declared_rate 直接抽

安達商品 R3C9 直接是 `guaranteed_rate`(數字 e.g. 2.25):

```python
r3c9 = ws.cell(3, 9).value
if isinstance(r3c9, (int, float)):
    declared_rate = r3c9 / 100  # 注意要 /100
```

---

## 🎯 base_premium / gross

安達 R4 row 抽 base_premium / gross:

```python
# R4 col 多個位置可能,用 keyword 找
for c in range(1, 30):
    v = ws.cell(4, c).value
    if isinstance(v, str) and '年繳' in v:
        # 右側格子
        for cc in range(c+1, c+5):
            val = ws.cell(4, cc).value
            if isinstance(val, (int, float)) and val > 0:
                base_premium = val
                break
```

---

## 🆔 anim plan_code 規律

- `RPISWLB` / `RPISWLA` / `RPI` 系列
- 多年期通常用不同 plan_code

---

## 📦 部署資料夾

`data/chubb/<plan_code>.json`(全小寫)

---

## ⚠️ 安達目前狀態(2026-05-07)

- 已部署 6 個(RPISWLB 取代 + 5 純新增)
- 5/6 第一輪安達 6 個 JSON 不在工作區,如有 404 需要老闆重新上傳
