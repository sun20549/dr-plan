# Excel → JSON 商品抽取指令 v6.0 完整套件

> **建立**:2026-05-07
> **整合**:6 份 v5 規範文件(富邦/友邦/保誠/全球/台壽/凱基/新光/遠雄/安達/法巴)+ 3 隻引擎程式
> **目的**:儲蓄險分析系統(GitHub `sun20549/dr-plan`)的 Excel 抽取 SOP

---

## 📦 套件結構

```
v6/
├── README.md                    ← 本檔(總索引)
├── 00_MASTER.md                 ← 共通 SOP(1208 行,所有公司必讀)
│
├── 01_appendix_fubon.md         ← 富邦(.xls→xlsx、混合型、歲滿期、3 條補充鐵律)
├── 02_appendix_aia.md           ← 友邦(RV 表手算、aia_engine 接法)
├── 03_appendix_prudential.md    ← 保誠(layout A/B、prudential_extractor 接法)
├── 04_appendix_cardif.md        ← 法巴(公版空白模板 fill+recalc、autofilter 修補)
├── 05_appendix_transglobe.md    ← 全球(已驗證 32 個 .xls,陷阱速查)
├── 06_appendix_twlife.md        ← 台壽(AUD 預設值、真還本判定、stepped/sa_decay)
├── 07_appendix_fglife.md        ← 遠雄(萬元三重判斷、躉繳 demo、養老 protection_period、補充鐵律)
├── 08_appendix_chubb.md         ← 安達(factor 每萬美元、TODAY() 修補、補充鐵律)
├── 09_appendix_kgi.md           ← 凱基(多年期同 plan_code、kgi_rv_v1)
├── 10_appendix_skl.md           ← 新光(直營/保經兩版、taishin_v1)
│
└── engines/
    ├── fubon_v5_engine.py       ← 富邦自動抽取引擎
    ├── aia_engine.py            ← 友邦 RV 表手算引擎
    ├── aia_recalc.py            ← .xls → .xlsx LibreOffice 批次重算
    ├── aia_extract_cli.py       ← 友邦 CLI 入口
    └── prudential_extractor.py  ← 保誠/Cardif 三情境分紅引擎
```

---

## 🚀 怎麼用

### 場景 1:處理一個新公司的單檔商品

1. 讀 `00_MASTER.md`(基礎 SOP)
2. 讀對應的 `0X_appendix_<company>.md`
3. 沒有對應附錄 → 走 master 通用流程,把過程踩到的雷記下來,之後新增附錄

### 場景 2:批次處理 N 個檔

1. 讀 master Step P0(規劃模式)→ 先盤點分類
2. 確認後讀 master Step B0(批次模式)
3. 讀對應公司附錄
4. 同公司一批跑完再換下一公司

### 場景 3:已知公司有現成引擎

| 公司 | 直接用 |
|---|---|
| 富邦 | `engines/fubon_v5_engine.py` |
| 友邦 | `engines/aia_extract_cli.py` |
| 保誠 / Cardif / 富邦分紅 / 台壽分紅 / 安達分紅 | `engines/prudential_extractor.py` |

---

## 📊 v6 vs v5 簡明對比

| 面向 | v5(6 份分散) | v6(本套件) |
|---|---|---|
| 文件數 | 6 份(每份 700~2300 行) | 1 master + 10 附錄 + 5 程式 |
| 總行數 | ~8800 行 markdown | ~1208 行 master + ~1500 行附錄 = **2700 行** |
| 規則編號 | 各家 A~O / A~Q / A~T / 17 條混亂 | 統一 A~Q + 補充鐵律 19~23 |
| 鐵律數 | 各家 12~20 條(重複多) | master 18 條共通 + 各家補充明確標號 |
| 引擎程式 | 散落在 md 內 + 獨立檔混雜 | 統一 `engines/` 目錄 + 附錄裡寫接法 |
| 處理新公司成本 | 改 6 份檔 | 寫一份新附錄 |
| AI 讀取量 | 整批塞 8800 行 | 處理某家只讀 master + 該家附錄(平均 ~1700 行) |

---

## 🔑 18 條共通鐵律(master 抽出,所有公司必須遵守)

1. 嚴禁 view 工具讀整檔 Excel
2. 嚴禁猜欄位語意,逐步確認
3. 嚴禁完整 JSON 貼進對話
4. 嚴禁跳過自洽性驗證
5. 抽不到的欄位**省略 key**
6. 嚴禁自決 engine 類型
7. 嚴禁省略 5 件套(base_sa/premium/age/sex/period)
8. 嚴禁 product_name 帶公司前綴
9. 嚴禁分紅商品省略 mid_dividend_rate
10. 嚴禁 min_sa 用 50000 預設
11. 嚴禁把 base_age=0 / sex='F' 當缺值(用 `is None`)
12. 嚴禁寫死欄位 col 編號
13. 嚴禁 #VALUE! 直接抽 0/None
14. 嚴禁不排序就交付 schedule
15. 嚴禁對 stepped/還本套 Y1 db ≈ sa
16. 嚴禁對還本商品檢查 cv_total 中後期遞增
17. 嚴禁假設 background process 跨 bash call 存活
18. 嚴禁用 subprocess + redirect/pipe(改 capture_output)

**各家補充鐵律**:
- 19~21 富邦(currency 抽取位置、base_sa 鎖定、附約保費分離)
- 22 遠雄(declared_rate vs guaranteed_rate)
- 23 安達(LibreOffice TODAY() 重算)

---

## 🆕 升級指南:從 v5 升 v6

### 對 AI 助理(處理新對話的 Claude)

新對話開場白只要:

```
延續儲蓄險分析系統處理(原對話達上限)。

【現況】
- 217 個商品,9 家公司
- 部署位址:GitHub sun20549/dr-plan
- 規則:走 v6 萬用 master + 各家附錄

【附帶 4 個檔】
1. v6/00_MASTER.md(共通 SOP)
2. v6/0X_appendix_<我這次要處理的公司>.md
3. _manifest.json(217 商品)
4. index.html(217 商品)
+ 必要時帶 v6/engines/<引擎>.py

【今天要做】
[在這裡描述新任務]
```

### 對開發者(老闆本人)

- v5 的 6 份文件可以**保留作為歷史**(出問題回查用),不必刪
- 改規則時改 master(影響全公司)or 改某家附錄(只影響該公司)
- 新公司加進來時建立 `1X_appendix_<新公司>.md`

---

## ⚠️ 套件缺口(老闆需手動補齊)

1. **凱基附錄(09)的 `kgi_rv_v1` 細節** —— 兩個商品個案處理,還沒抽出規則
2. **新光附錄(10)的 `taishin_v1` 細節** —— 三個商品個案處理,還沒抽出規則
3. **法巴(04)Cardif 6 個商品**還沒部署到 manifest(0 個 entry)
4. **跨對話交接文件 v3** —— 等下一輪對話才能寫(本輪數據已寫到 v2)

---

## 📞 後續維護

老闆若要改 master,**全公司都會跟著改**,改前先想清楚是不是 99% 的場景都成立。
若只有某家有的特例,**改該家附錄**,不要動 master。

---

**🔚 v6.0 套件 README 結束**
