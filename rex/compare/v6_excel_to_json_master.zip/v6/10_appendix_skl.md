# 附錄 10:新光人壽 (`skl/` + 根目錄)

> 新光特色:**直營版 vs 保經版兩種 sheet 結構**、`taishin_v1` 引擎(原台新代理留下的 schema)、UPD061 + 5/7 新增 2 個 taishin_v1 商品。

---

## 🎯 直營版 vs 保經版偵測

```python
# 新光直營版
if any(s in wb.sheetnames for s in ['DBV', 'SBN', 'CSV', 'AXT', 'RBN']):
    engine = 'twlife_v1'
    sub_type = 'skl_direct'

# 新光保經版
elif any(s in wb.sheetnames for s in ['GP', 'Corridor Rule', 'FACTOR']) and \
     not any(s in wb.sheetnames for s in ['gp_table', 'uv_table', 'div_table']):
    engine = 'twlife_v1'
    sub_type = 'skl_broker'

# 新光分紅(暫不支援)
elif all(s in wb.sheetnames for s in ['gp_table', 'uv_table', 'div_table']):
    engine = 'taishin_v1'  # 原台新代理 schema
```

---

## 🔧 taishin_v1 引擎

3 個商品(UPD061 + 5/7 新增 2 個)走 taishin_v1。**個案處理,沒有自動 extractor。**

特徵:`gp_table / uv_table / div_table` 三 sheet 結構。

---

## 🆔 新光 plan_code 規律

- 直營:`UPD061` / 三碼字母 + 數字
- 保經:`UPDxxx` / 字母縮寫 + 數字

---

## 📦 部署資料夾

| 類型 | 資料夾 | 範例 |
|---|---|---|
| 主流商品 | `data/skl/` | 大多數 |
| 早期商品 | `data/`(根目錄) | UPD061 等歷史商品 |

新部署一律放 `skl/`。歷史在根目錄的不動。

manifest path 範例:
- 新增:`skl/XXX.json`
- 歷史:`UPD061.json`(無前綴)
