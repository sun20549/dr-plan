# 附錄 06:台灣人壽 (`twlife/`)

> 台壽是 master 的最大用戶(twlife_v1 引擎來源),32 個商品全走通用流程。本附錄記錄 master 沒講的 delta 與已驗證陷阱。

---

## 🔧 規則 C 例外:台壽 AUD 預設值

master 規則 C 預設:`AUD min=10000, max=3000000, max_age=75`。
**台壽家自家 AUD 商品實測**(澳利樂等)應使用:

| 幣別 | min_sa | max_sa | max_age |
|---|---|---|---|
| AUD(台壽自家) | 5000 | 8000000 | 85 |

碰到台壽 AUD 商品優先用這組值,並打 `note: '台壽 AUD 預設'`。

---

## 🎯 台壽分紅商品(prudential_v2)特殊偵測

```python
# 台壽分紅 sheet 組合
if all(s in wb.sheetnames for s in ['比對用']) and \
   any('Profits' in s for s in wb.sheetnames) and \
   '儲存生息計算' in wb.sheetnames:
    engine = 'prudential_v2'
    # 用 prudential_extractor.py 抽
```

台壽分紅 mid_dividend_rate 預設:`0.045`(TWD)/ `0.055`(USD)/ `0.050`(AUD)。

---

## 🎯 台壽養老型(資料檢核頁)放寬筆數

商品名含「養老保險」+ sheet 有「資料檢核頁」+ `protection_period` < 全期 → schedule 筆數可能短(只到 protection_period + 滿期),master Step 2 終止條件要放寬。

---

## 🎯 真還本判定(規則 K 應用範例)

| 商品 | 商品名含「還本」 | 有當年生存金欄 | 處理 |
|---|---|---|---|
| **美年有鑫** | ✅ | ❌(累計增額繳清) | **不**標 `is_endowment`,當 twlife_v1 一般處理 |
| **澳利樂** | ✅ | ✅ | 標 `is_endowment: true` |
| **美紅勝利** | ❌(分紅) | ✅ + Y1-Y2 stepped + Y4+ sa_decay | `db_pattern: 'stepped'` + `sa_decay: true` |
| **美紅鑽** | ❌(分紅) | ✅ + Y3+ sa_decay | `is_endowment: true` + `sa_decay: true` |

---

## 🎯 樂退系列偵測

| sheet 特徵 | 處理 |
|---|---|
| 簡易版 + 明細版 + 費率 + 樂齡日 60/65/70 歲 | `twlife_v1`(可做) |
| 商品名含「樂退」+ `Output2/AnnFactor` | 樂退年金型 → **跳過** |
| 商品名含「樂退」+ `資料檢核頁/明細版` | 利變還本誤標 → 走 `twlife_v1` |

---

## 🆔 台壽 plan_code 規律

- 中文檔名(如 `保利美.xls`)→ 用 plan_code 作中文(罕見,大多英數)
- 多年期通常用不同 plan_code → 規則 E 寫多條

---

## 📦 部署資料夾

`data/twlife/<plan_code>.json`(全小寫)

---

## ⚠️ 台壽目前 PENDING(2026-05-07)

- 16 個既有商品 JSON 本機 OneDrive 缺檔(保利美/吉享紅/吉美富/吉美得/多享利/年年添利/旺美勝/珍多寶/紅利旺/美月有鑫/美紅旺_v5/金多利/金多沛/金得利/金滿利/金福利)
- 6 個 5/6 新增:澳利樂 max_sa 800 萬可能是 50 萬?、傳承富足 discount=0、美紅勝利/美紅鑽 mid_dividend_rate 校對
- 美紅勝利前端展示要規則 M 提示(stepped + sa_decay)
- 美紅鑽前端展示要規則 M 提示(還本 + sa_decay)
