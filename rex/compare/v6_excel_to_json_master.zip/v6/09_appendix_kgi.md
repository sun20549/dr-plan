# 附錄 09:凱基人壽 (`KGI/`,大寫!)

> 凱基特色:**多年期同 plan_code**(規則 E)、特殊引擎 `kgi_rv_v1`(2 個商品)、養老型展示。

---

## 🎯 多年期同 plan_code

凱基商品慣性:同 plan_code 包多年期,JSON 內含所有年期 → manifest 寫 1 條 entry。

範例:
```
6UBS.json
├── meta: { plan_code: "6UBS", periods: [6, 10, 15] }
├── schedule_6:  [...]
├── schedule_10: [...]
└── schedule_15: [...]
```

manifest 只寫 1 條,前端 STEP1 後讓老闆選年期。

---

## 🔧 凱基特殊引擎 kgi_rv_v1

2 個商品(具體 plan_code 待補,可從 manifest 查 `engine='kgi_rv_v1'`)走特殊引擎,**個案處理**,沒有自動 extractor。

---

## 🎯 養老型偵測

```python
# 試算頁 + 商品名「養老」 → 凱基養老
if '試算頁' in wb.sheetnames and '養老' in product_name:
    engine = 'twlife_v1'
    is_endowment_type = True   # 不是 is_endowment(那是定期還本)
    product_type = 'endowment'
```

---

## 🆔 凱基 plan_code 規律

- 一律大寫英數開頭數字,如 `5UEC` / `5UED` / `5UEH` / `6U9Z` / `6UBS`
- 多年期同 code

---

## ⚠️ 凱基踩雷

1. **6U9Z Y10 cv_total=0** —— Y9 後轉繳清增額,正常設計但前端要規則 M 提示
2. **5UEC/5UED/5UEH/6U9Z 養老險前端展示** —— 規則 M 提示「養老型,Y10 滿期僅領回 cv」

---

## 📦 部署資料夾

`data/KGI/<plan_code>.json`(**大寫**!踩雷:寫成 `kgi/` 會 404)

manifest path 範例:
```json
{ "key": "6UBS", "path": "KGI/6UBS.json", ... }
```
