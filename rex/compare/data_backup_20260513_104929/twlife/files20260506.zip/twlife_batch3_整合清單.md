# 台灣人壽 batch3 — 17 個商品整合部署清單

## 路徑
所有 17 個 JSON 放到:`rex/compare/data/twlife/`(跟 batch1/2 同目錄)

```
rex/compare/data/twlife/
├── 保利美.json     (USD 利變,6 期繳)
├── 吉享紅.json     (TWD 分紅還本,2 期繳) ⭐ prudential_v2
├── 吉美富.json     (USD 利變,躉繳)
├── 吉美得.json     (USD 利變,2 期繳)
├── 四海飛揚.json   (CNY 人民幣 ⭐) 利變,4 期繳
├── 多享利.json     (TWD 還本,2 期繳)
├── 年年添利.json   (TWD 還本,6 期繳)
├── 旺美勝.json     (USD 利變,2 期繳)
├── 珍多寶.json     (TWD 增額,6 期繳)
├── 紅利旺.json     (TWD 分紅,6 期繳) ⭐ prudential_v2
├── 美月有鑫.json   (USD 還本,2 期繳)
├── 美紅旺_v5.json  (USD 分紅,6 期繳) ⭐ prudential_v2,跟 batch1 NUPW0102 並存
├── 金多利.json     (TWD 增額,躉繳)
├── 金多沛.json     (TWD 還本,6 期繳)
├── 金得利.json     (TWD 增額,躉繳)
├── 金滿利.json     (TWD 利變,2 期繳)
└── 金福利.json     (TWD 利變,躉繳)
```

---

## 1. `_manifest.json` 要加的 17 條

```json
{
  "key": "保利美",
  "company": "台灣人壽",
  "plan_code": "保利美",
  "product_name": "保利美美元利率變動型終身壽險",
  "currency": "USD",
  "period": 6,
  "engine": "twlife_v1",
  "product_code": "保利美",
  "path": "twlife/保利美.json"
},
{
  "key": "吉享紅",
  "company": "台灣人壽",
  "plan_code": "吉享紅",
  "product_name": "吉享紅分紅終身還本保險",
  "currency": "TWD",
  "period": 2,
  "engine": "prudential_v2",
  "product_code": "吉享紅",
  "path": "twlife/吉享紅.json"
},
{
  "key": "吉美富",
  "company": "台灣人壽",
  "plan_code": "吉美富",
  "product_name": "吉美富美元利率變動型終身壽險",
  "currency": "USD",
  "period": 1,
  "engine": "twlife_v1",
  "product_code": "吉美富",
  "path": "twlife/吉美富.json"
},
{
  "key": "吉美得",
  "company": "台灣人壽",
  "plan_code": "吉美得",
  "product_name": "吉美得美元利率變動型終身壽險",
  "currency": "USD",
  "period": 2,
  "engine": "twlife_v1",
  "product_code": "吉美得",
  "path": "twlife/吉美得.json"
},
{
  "key": "四海飛揚",
  "company": "台灣人壽",
  "plan_code": "四海飛揚",
  "product_name": "四海飛揚人民幣利率變動型終身壽險",
  "currency": "CNY",
  "period": 4,
  "engine": "twlife_v1",
  "product_code": "四海飛揚",
  "path": "twlife/四海飛揚.json"
},
{
  "key": "多享利",
  "company": "台灣人壽",
  "plan_code": "多享利",
  "product_name": "多享利利率變動型還本終身保險",
  "currency": "TWD",
  "period": 2,
  "engine": "twlife_v1",
  "product_code": "多享利",
  "path": "twlife/多享利.json"
},
{
  "key": "年年添利",
  "company": "台灣人壽",
  "plan_code": "年年添利",
  "product_name": "年年添利利率變動型還本終身保險",
  "currency": "TWD",
  "period": 6,
  "engine": "twlife_v1",
  "product_code": "年年添利",
  "path": "twlife/年年添利.json"
},
{
  "key": "旺美勝",
  "company": "台灣人壽",
  "plan_code": "旺美勝",
  "product_name": "旺美勝美元利率變動型終身壽險",
  "currency": "USD",
  "period": 2,
  "engine": "twlife_v1",
  "product_code": "旺美勝",
  "path": "twlife/旺美勝.json"
},
{
  "key": "珍多寶",
  "company": "台灣人壽",
  "plan_code": "珍多寶",
  "product_name": "珍多寶利率變動型增額終身壽險",
  "currency": "TWD",
  "period": 6,
  "engine": "twlife_v1",
  "product_code": "珍多寶",
  "path": "twlife/珍多寶.json"
},
{
  "key": "紅利旺",
  "company": "台灣人壽",
  "plan_code": "紅利旺",
  "product_name": "紅利旺分紅終身壽險",
  "currency": "TWD",
  "period": 6,
  "engine": "prudential_v2",
  "product_code": "紅利旺",
  "path": "twlife/紅利旺.json"
},
{
  "key": "美月有鑫",
  "company": "台灣人壽",
  "plan_code": "美月有鑫",
  "product_name": "美月有鑫美元利率變動型還本終身保險",
  "currency": "USD",
  "period": 2,
  "engine": "twlife_v1",
  "product_code": "美月有鑫",
  "path": "twlife/美月有鑫.json"
},
{
  "key": "美紅旺_v5",
  "company": "台灣人壽",
  "plan_code": "美紅旺_v5",
  "product_name": "美紅旺美元分紅終身壽險",
  "currency": "USD",
  "period": 6,
  "engine": "prudential_v2",
  "product_code": "美紅旺_v5",
  "path": "twlife/美紅旺_v5.json"
},
{
  "key": "金多利",
  "company": "台灣人壽",
  "plan_code": "金多利",
  "product_name": "金多利利率變動型增額終身壽險",
  "currency": "TWD",
  "period": 1,
  "engine": "twlife_v1",
  "product_code": "金多利",
  "path": "twlife/金多利.json"
},
{
  "key": "金多沛",
  "company": "台灣人壽",
  "plan_code": "金多沛",
  "product_name": "金多沛還本終身保險",
  "currency": "TWD",
  "period": 6,
  "engine": "twlife_v1",
  "product_code": "金多沛",
  "path": "twlife/金多沛.json"
},
{
  "key": "金得利",
  "company": "台灣人壽",
  "plan_code": "金得利",
  "product_name": "金得利利率變動型增額終身壽險",
  "currency": "TWD",
  "period": 1,
  "engine": "twlife_v1",
  "product_code": "金得利",
  "path": "twlife/金得利.json"
},
{
  "key": "金滿利",
  "company": "台灣人壽",
  "plan_code": "金滿利",
  "product_name": "金滿利利率變動型終身壽險",
  "currency": "TWD",
  "period": 2,
  "engine": "twlife_v1",
  "product_code": "金滿利",
  "path": "twlife/金滿利.json"
},
{
  "key": "金福利",
  "company": "台灣人壽",
  "plan_code": "金福利",
  "product_name": "金福利利率變動型終身壽險",
  "currency": "TWD",
  "period": 1,
  "engine": "twlife_v1",
  "product_code": "金福利",
  "path": "twlife/金福利.json"
}
```

---

## 2. `index_slim.html` PRODUCTS 註冊表要加的 17 條

```js
{
  plan_code: '保利美',
  company: '台灣人壽',
  product_name: '保利美美元利率變動型終身壽險',
  period: 6,
  currency: 'USD',
  type: '美元利率變動型終身壽險',
  declared_rate: 0.042,
  predicted_rate: 0,
  discount: 0.04,
  discount_method: 'simple',
  engine: 'twlife_v1',
  unit_size: 1000,
  min_sa: 10000,
  max_sa: 10000000,
  min_age: 0,
  max_age: 74
},
{
  plan_code: '吉享紅',
  company: '台灣人壽',
  product_name: '吉享紅分紅終身還本保險',
  period: 2,
  currency: 'TWD',
  type: '新台幣分紅終身還本保險',
  declared_rate: 0,
  predicted_rate: 0,
  discount: 0.025,
  discount_method: 'simple',
  engine: 'prudential_v2',
  mid_dividend_rate: 0.055,
  unit_size: 1000,
  min_sa: 100000,
  max_sa: 60000000,
  min_age: 0,
  max_age: 70
},
{
  plan_code: '吉美富',
  company: '台灣人壽',
  product_name: '吉美富美元利率變動型終身壽險',
  period: 1,
  currency: 'USD',
  type: '美元利率變動型終身壽險',
  declared_rate: 0.0415,
  predicted_rate: 0,
  discount: 0.011,
  discount_method: 'simple',
  engine: 'twlife_v1',
  unit_size: 1000,
  min_sa: 3000,
  max_sa: 6000000,
  min_age: 0,
  max_age: 85
},
{
  plan_code: '吉美得',
  company: '台灣人壽',
  product_name: '吉美得美元利率變動型終身壽險',
  period: 2,
  currency: 'USD',
  type: '美元利率變動型終身壽險',
  declared_rate: 0.043,
  predicted_rate: 0,
  discount: 0.035,
  discount_method: 'simple',
  engine: 'twlife_v1',
  unit_size: 1000,
  min_sa: 10000,
  max_sa: 10000000,
  min_age: 0,
  max_age: 75
},
{
  plan_code: '四海飛揚',
  company: '台灣人壽',
  product_name: '四海飛揚人民幣利率變動型終身壽險',
  period: 4,
  currency: 'CNY',
  type: '人民幣利率變動型終身壽險',
  declared_rate: 0.022,
  predicted_rate: 0,
  discount: 0.02,
  discount_method: 'simple',
  engine: 'twlife_v1',
  unit_size: 1000,
  min_sa: 10000,
  max_sa: 5000000,
  min_age: 0,
  max_age: 70
},
{
  plan_code: '多享利',
  company: '台灣人壽',
  product_name: '多享利利率變動型還本終身保險',
  period: 2,
  currency: 'TWD',
  type: '新台幣利率變動型還本終身壽險',
  declared_rate: 0.025,
  predicted_rate: 0,
  discount: 0.035,
  discount_method: 'simple',
  engine: 'twlife_v1',
  unit_size: 1000,
  min_sa: 100000,
  max_sa: 60000000,
  min_age: 0,
  max_age: 75
},
{
  plan_code: '年年添利',
  company: '台灣人壽',
  product_name: '年年添利利率變動型還本終身保險',
  period: 6,
  currency: 'TWD',
  type: '新台幣利率變動型還本終身壽險',
  declared_rate: 0.0225,
  predicted_rate: 0,
  discount: 0.03,
  discount_method: 'simple',
  engine: 'twlife_v1',
  unit_size: 1000,
  min_sa: 100000,
  max_sa: 60000000,
  min_age: 0,
  max_age: 75
},
{
  plan_code: '旺美勝',
  company: '台灣人壽',
  product_name: '旺美勝美元利率變動型終身壽險',
  period: 2,
  currency: 'USD',
  type: '美元利率變動型終身壽險',
  declared_rate: 0.043,
  predicted_rate: 0,
  discount: 0.015,
  discount_method: 'simple',
  engine: 'twlife_v1',
  unit_size: 1000,
  min_sa: 10000,
  max_sa: 10000000,
  min_age: 0,
  max_age: 75
},
{
  plan_code: '珍多寶',
  company: '台灣人壽',
  product_name: '珍多寶利率變動型增額終身壽險',
  period: 6,
  currency: 'TWD',
  type: '新台幣利率變動型增額終身壽險',
  declared_rate: 0.0235,
  predicted_rate: 0,
  discount: 0,
  discount_method: 'simple',
  engine: 'twlife_v1',
  unit_size: 1000,
  min_sa: 100000,
  max_sa: 60000000,
  min_age: 0,
  max_age: 70
},
{
  plan_code: '紅利旺',
  company: '台灣人壽',
  product_name: '紅利旺分紅終身壽險',
  period: 6,
  currency: 'TWD',
  type: '新台幣分紅終身壽險',
  declared_rate: 0,
  predicted_rate: 0,
  discount: 0.02,
  discount_method: 'simple',
  engine: 'prudential_v2',
  mid_dividend_rate: 0.055,
  unit_size: 1000,
  min_sa: 100000,
  max_sa: 100000000,
  min_age: 0,
  max_age: 80
},
{
  plan_code: '美月有鑫',
  company: '台灣人壽',
  product_name: '美月有鑫美元利率變動型還本終身保險',
  period: 2,
  currency: 'USD',
  type: '美元利率變動型還本終身壽險',
  declared_rate: 0.039,
  predicted_rate: 0,
  discount: 0.02,
  discount_method: 'simple',
  engine: 'twlife_v1',
  unit_size: 1000,
  min_sa: 10000,
  max_sa: 5000000,
  min_age: 0,
  max_age: 75
},
{
  plan_code: '美紅旺_v5',
  company: '台灣人壽',
  product_name: '美紅旺美元分紅終身壽險',
  period: 6,
  currency: 'USD',
  type: '美元分紅終身壽險',
  declared_rate: 0,
  predicted_rate: 0,
  discount: 0,
  discount_method: 'simple',
  engine: 'prudential_v2',
  mid_dividend_rate: 0.055,
  unit_size: 1000,
  min_sa: 10000,
  max_sa: 10000000,
  min_age: 0,
  max_age: 74
},
{
  plan_code: '金多利',
  company: '台灣人壽',
  product_name: '金多利利率變動型增額終身壽險',
  period: 1,
  currency: 'TWD',
  type: '新台幣利率變動型增額終身壽險',
  declared_rate: 0.0275,
  predicted_rate: 0,
  discount: 0.014,
  discount_method: 'simple',
  engine: 'twlife_v1',
  unit_size: 1000,
  min_sa: 100000,
  max_sa: 60000000,
  min_age: 0,
  max_age: 75
},
{
  plan_code: '金多沛',
  company: '台灣人壽',
  product_name: '金多沛還本終身保險',
  period: 6,
  currency: 'TWD',
  type: '新台幣還本終身壽險',
  declared_rate: 0,
  predicted_rate: 0,
  discount: 0.02,
  discount_method: 'simple',
  engine: 'twlife_v1',
  unit_size: 1000,
  min_sa: 100000,
  max_sa: 60000000,
  min_age: 0,
  max_age: 75
},
{
  plan_code: '金得利',
  company: '台灣人壽',
  product_name: '金得利利率變動型增額終身壽險',
  period: 1,
  currency: 'TWD',
  type: '新台幣利率變動型增額終身壽險',
  declared_rate: 0.0275,
  predicted_rate: 0,
  discount: 0,
  discount_method: 'simple',
  engine: 'twlife_v1',
  unit_size: 1000,
  min_sa: 100000,
  max_sa: 60000000,
  min_age: 0,
  max_age: 75
},
{
  plan_code: '金滿利',
  company: '台灣人壽',
  product_name: '金滿利利率變動型終身壽險',
  period: 2,
  currency: 'TWD',
  type: '新台幣利率變動型終身壽險',
  declared_rate: 0.026,
  predicted_rate: 0,
  discount: 0.037,
  discount_method: 'simple',
  engine: 'twlife_v1',
  unit_size: 1000,
  min_sa: 100000,
  max_sa: 100000000,
  min_age: 0,
  max_age: 75
},
{
  plan_code: '金福利',
  company: '台灣人壽',
  product_name: '金福利利率變動型終身壽險',
  period: 1,
  currency: 'TWD',
  type: '新台幣利率變動型終身壽險',
  declared_rate: 0.0245,
  predicted_rate: 0,
  discount: 0.01,
  discount_method: 'simple',
  engine: 'twlife_v1',
  unit_size: 1000,
  min_sa: 100000,
  max_sa: 60000000,
  min_age: 0,
  max_age: 75
}
```

---

## 3. 跨商品已知特殊狀況

| plan_code | 注意事項 |
|---|---|
| 保利美 | Y1-Y3 db ≈ 累積保費(前低後高,Y4 起跳到全額)。跟 batch1 NUIW6502 同商品新版,batch1 是 ver?, 此版是 Final ver9 |
| **吉享紅** | ⭐ 分紅還本(prudential_v2)。base 試算 base_premium 47659949 TWD/年(超大保費)。schedule 20 筆。年度紅利選**儲存生息** |
| 吉美富 | 躉繳。**跟 batch1 NUIW4703 同商品新版**(ver10)。跟 batch1 數字一致 |
| 吉美得 | 2 期繳,折扣 3.5% (高保費 1.5% + 1+1%) |
| **四海飛揚** | ⭐ **唯一 CNY 人民幣商品**。試算 12 歲男 |
| 多享利 | 試算 6 歲女嬰,SA 770萬 TWD,2 期繳完 |
| 年年添利 | 試算 41 歲男,SA 83萬 TWD,6 期繳。schedule 59 筆(高齡到 99 歲) |
| 旺美勝 | 2 期繳,SA 20萬 USD |
| 珍多寶 | 增額型,沒折扣文字 → discount=0 |
| **紅利旺** | ⭐ TWD 分紅(prudential_v2)。Y1-Y3 db < base_sa(階梯成長,Y4 起 = base_sa)。base_premium 由折扣前 663500 × 0.98 反推得 650230 |
| 美月有鑫 | 還本型,Y19 之後 cv_total 微幅波動(±100 USD,容許範圍) |
| **美紅旺_v5** | ⭐ USD 分紅(prudential_v2)。**跟 batch1 NUPW0102 同商品新版**(ver5)。本檔無密碼。試算 3 歲女嬰月繳(77 USD/月) |
| 金多利 | 躉繳,折扣 1.4% (落在 120-150 萬 TWD 區間) |
| 金多沛 | **schedule 只有 28 筆**(試算表只到 Y28,72 歲投保到 99 歲合理)。沒利變欄(declared_rate=0) |
| 金得利 | 躉繳,沒折扣文字 → discount=0 |
| 金滿利 | 折扣 3.7% (高保費 1.7% + 1+1%) |
| 金福利 | 躉繳,折扣 1% |

### ⚠️ 跟前批撞名警示

| 中文 plan_code | 跟前批舊代號 | 處理 |
|---|---|---|
| 吉美富 | batch1 NUIW4703 | **同商品新版** |
| 保利美 | batch1 NUIW6502 | **同商品新版** |
| 美紅旺_v5 | batch1 NUPW0102 | **同商品新版**(用 _v5 後綴避免撞名) |

### ❌ 不交付商品

| 商品 | 原因 |
|---|---|
| 吉美世 | 試算表 base 設 89 歲超出商品費率,全部 #N/A |
| 美利富 | 試算表整個壞掉,逐年表全 ----- |
| 多美富 | 養老 10 期繳完,schedule 只 10 筆 < 30 |

---

## 4. 引擎統計

- **twlife_v1**: 14 個
- **prudential_v2**: 3 個 (吉享紅、紅利旺、美紅旺_v5)

## 5. 幣別統計

- **USD**: 7 個 (保利美、吉美富、吉美得、旺美勝、美月有鑫、美紅旺_v5、四海飛揚不是 USD)
  → 修正:USD 6 個 (保利美、吉美富、吉美得、旺美勝、美月有鑫、美紅旺_v5)
- **CNY**: 1 個 (四海飛揚) ⭐
- **TWD**: 10 個 (吉享紅、多享利、年年添利、珍多寶、紅利旺、金多利、金多沛、金得利、金滿利、金福利)
