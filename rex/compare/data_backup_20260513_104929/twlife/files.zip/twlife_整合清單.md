# 台灣人壽 7 個商品 — 整合部署清單

## 路徑
所有 7 個 JSON 放到:`rex/compare/data/twlife/`

```
rex/compare/data/twlife/
├── NUIW4703.json   (吉美富 - 躉繳)
├── NUIW6502.json   (保利美 - 6年)
├── NUIW6602.json   (美鑫美利 - 6年,試算 base_age=62)
├── NUIW5203.json   (超美利 - 6年,雙折扣 4%)
├── NUIW7302.json   (臻美滿 - 3年)
├── NUPW0202.json   (美世長紅 - 6年,分紅型)
└── NUPW0102.json   (美紅旺 - 6年,分紅型,試算 base 是女嬰月繳)
```

---

## 1. `_manifest.json` 要加的 7 條

把下面 7 個物件加進 `rex/compare/data/_manifest.json` 的陣列裡:

```json
{
  "key": "NUIW4703",
  "company": "台灣人壽",
  "plan_code": "NUIW4703",
  "product_name": "台灣人壽吉美富美元利率變動型終身壽險",
  "currency": "USD",
  "period": 1,
  "engine": "twlife_v1",
  "product_code": "NUIW4703",
  "path": "twlife/NUIW4703.json"
},
{
  "key": "NUIW6502",
  "company": "台灣人壽",
  "plan_code": "NUIW6502",
  "product_name": "台灣人壽保利美美元利率變動型終身壽險",
  "currency": "USD",
  "period": 6,
  "engine": "twlife_v1",
  "product_code": "NUIW6502",
  "path": "twlife/NUIW6502.json"
},
{
  "key": "NUIW6602",
  "company": "台灣人壽",
  "plan_code": "NUIW6602",
  "product_name": "台灣人壽美鑫美利美元利率變動型終身壽險",
  "currency": "USD",
  "period": 6,
  "engine": "twlife_v1",
  "product_code": "NUIW6602",
  "path": "twlife/NUIW6602.json"
},
{
  "key": "NUIW5203",
  "company": "台灣人壽",
  "plan_code": "NUIW5203",
  "product_name": "台灣人壽超美利美元利率變動型終身壽險",
  "currency": "USD",
  "period": 6,
  "engine": "twlife_v1",
  "product_code": "NUIW5203",
  "path": "twlife/NUIW5203.json"
},
{
  "key": "NUIW7302",
  "company": "台灣人壽",
  "plan_code": "NUIW7302",
  "product_name": "台灣人壽臻美滿美元利率變動型終身壽險",
  "currency": "USD",
  "period": 3,
  "engine": "twlife_v1",
  "product_code": "NUIW7302",
  "path": "twlife/NUIW7302.json"
},
{
  "key": "NUPW0202",
  "company": "台灣人壽",
  "plan_code": "NUPW0202",
  "product_name": "台灣人壽美世長紅美元分紅終身壽險",
  "currency": "USD",
  "period": 6,
  "engine": "prudential_v2",
  "product_code": "NUPW0202",
  "path": "twlife/NUPW0202.json"
},
{
  "key": "NUPW0102",
  "company": "台灣人壽",
  "plan_code": "NUPW0102",
  "product_name": "台灣人壽美紅旺美元分紅終身壽險",
  "currency": "USD",
  "period": 6,
  "engine": "prudential_v2",
  "product_code": "NUPW0102",
  "path": "twlife/NUPW0102.json"
}
```

---

## 2. `index_slim.html` PRODUCTS 註冊表要加的 7 條

```js
{
  plan_code: 'NUIW4703',
  company: '台灣人壽',
  product_name: '台灣人壽吉美富美元利率變動型終身壽險',
  period: 1,
  currency: 'USD',
  type: '美元利率變動型終身壽險',
  declared_rate: 0.0415,
  predicted_rate: 0,
  discount: 0.011,
  discount_method: 'simple',
  engine: 'twlife_v1',
  unit_size: 1000,
  min_sa: 3000,
  max_sa: 6000000,
  min_age: 0,
  max_age: 85
},
{
  plan_code: 'NUIW6502',
  company: '台灣人壽',
  product_name: '台灣人壽保利美美元利率變動型終身壽險',
  period: 6,
  currency: 'USD',
  type: '美元利率變動型終身壽險',
  declared_rate: 0.042,
  predicted_rate: 0,
  discount: 0.01,
  discount_method: 'simple',
  engine: 'twlife_v1',
  unit_size: 1000,
  min_sa: 7000,
  max_sa: 10000000,
  min_age: 0,
  max_age: 74
},
{
  plan_code: 'NUIW6602',
  company: '台灣人壽',
  product_name: '台灣人壽美鑫美利美元利率變動型終身壽險',
  period: 6,
  currency: 'USD',
  type: '美元利率變動型終身壽險',
  declared_rate: 0.042,
  predicted_rate: 0,
  discount: 0.01,
  discount_method: 'simple',
  engine: 'twlife_v1',
  unit_size: 1000,
  min_sa: 8000,
  max_sa: 10000000,
  min_age: 0,
  max_age: 74
},
{
  plan_code: 'NUIW5203',
  company: '台灣人壽',
  product_name: '台灣人壽超美利美元利率變動型終身壽險',
  period: 6,
  currency: 'USD',
  type: '美元利率變動型終身壽險',
  declared_rate: 0.042,
  predicted_rate: 0,
  discount: 0.04,
  discount_method: 'simple',
  engine: 'twlife_v1',
  unit_size: 1000,
  min_sa: 6000,
  max_sa: 10000000,
  min_age: 0,
  max_age: 74
},
{
  plan_code: 'NUIW7302',
  company: '台灣人壽',
  product_name: '台灣人壽臻美滿美元利率變動型終身壽險',
  period: 3,
  currency: 'USD',
  type: '美元利率變動型終身壽險',
  declared_rate: 0.0425,
  predicted_rate: 0,
  discount: 0.02,
  discount_method: 'simple',
  engine: 'twlife_v1',
  unit_size: 1000,
  min_sa: 10000,
  max_sa: 5000000,
  min_age: 0,
  max_age: 77
},
{
  plan_code: 'NUPW0202',
  company: '台灣人壽',
  product_name: '台灣人壽美世長紅美元分紅終身壽險',
  period: 6,
  currency: 'USD',
  type: '美元分紅終身壽險',
  declared_rate: 0,
  predicted_rate: 0,
  discount: 0.025,
  discount_method: 'simple',
  engine: 'prudential_v2',
  unit_size: 1000,
  min_sa: 10000,
  max_sa: 10000000,
  min_age: 0,
  max_age: 75
},
{
  plan_code: 'NUPW0102',
  company: '台灣人壽',
  product_name: '台灣人壽美紅旺美元分紅終身壽險',
  period: 6,
  currency: 'USD',
  type: '美元分紅終身壽險',
  declared_rate: 0,
  predicted_rate: 0,
  discount: 0,
  discount_method: 'simple',
  engine: 'prudential_v2',
  unit_size: 1000,
  min_sa: 10000,
  max_sa: 10000000,
  min_age: 0,
  max_age: 74
}
```

---

## 3. 跨商品已知特殊狀況(前端要小心的事)

| plan_code | 注意事項 |
|---|---|
| NUIW4703 | 躉繳 period=1。Y1 死亡給付 ≈ base_premium × 1.4(躉繳保證最低身故金) |
| NUIW6502 | Y1-Y3 死亡給付 ≈ 累積保費 × 1.094,**不是 base_sa**。Y4 起跳到全額 |
| NUIW6602 | 試算 base_age=62(其他多為 41-50),前端反推保額時 base_age 不是固定值 |
| NUIW5203 | 折扣 4% = 高保費 3% + 自轉 1% 雙重疊加。Y1-Y5 db ≈ 累積保費,Y6 起跳到全額 |
| NUIW7302 | schedule 只到 Y30(試算表結構限制)。3 年期繳。Y1-Y6 db < base_sa,Y7 起跳到全額 |
| NUPW0202 | 分紅型,**基本死亡給付逐年遞增**(Y1=base_sa,Y6 跳到 ~1.5×base_sa)。schedule 25 筆 |
| NUPW0102 | 分紅型,試算 base 是「女、3 歲、月繳」特殊範本。Y1-Y2 db=12916 < base_sa=43054。schedule 20 筆 |

---

## 4. 引擎統計

- **twlife_v1**: 5 個 (NUIW4703, NUIW6502, NUIW6602, NUIW5203, NUIW7302)
- **prudential_v2**: 2 個 (NUPW0202, NUPW0102)
