"""
validate_one.py — 單商品完整驗證腳本

用法:
    python3 validate_one.py \
        --excel UPD061_Excel.xls \
        --json  UPD061_corrected.json \
        --plan  UPD061 \
        --period-str '六年期/UPD061' \
        --period 6 \
        --sex M --age 35 --sa-mwan 300

流程:
    1. 改 Excel 輸入頁的關鍵 cell(險種代號 / 保額 / 性別 / 出生日)
    2. LibreOffice 重算
    3. 從「試算_最可能紅利」抽 PDF 真值(AB=身故總和 J、AC=解約總和 K)
    4. 載入修正後 JSON,跑 Python 引擎
    5. 逐年比對 J/K
    6. 輸出 PASS/FAIL 結果

PASS 判準: 全 maxY 年 |J差| < 0.5 且 |K差| < 0.5
"""
import argparse
import json
import os
import shutil
import subprocess
import sys
import time
import uuid
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from engine_taishin_v1 import actuarial_calc_taishin


# === Excel 操作工具 ===

def fill_excel(src_path, work_path, plan, period_str, sex, age, sa_mwan):
    """改輸入頁的 cell。
    
    參數對齊 HOW_TO_VALIDATE.md:
      E21 (R21C5)  險種代號 (例 '六年期/UPD061')
      F24 (R24C6)  保額 (萬元為單位)
      D7  (R7C4)   性別 ('男性' / '女性')
      D8/D9/D10 民國年/月/日 (R8C4 / R9C4 / R10C4)
      D11 (R11C4)  保險年齡
      J7/J8/J9 要保人 民國年/月/日 (R7C10 / R8C10 / R9C10)
    """
    import openpyxl
    shutil.copy(src_path, work_path)
    wb = openpyxl.load_workbook(work_path)
    ws = wb['輸入頁']
    
    sex_str = '男性' if sex == 'M' else '女性'
    # 配合 age 反算民國生年(假設 8/1 出生)
    # 試算日為當年 → 民國年 = 民國今年 - age
    # 民國今年 = 西元 - 1911,假設今天是 2026 = 民國 115
    roc_year = 115 - age
    
    # 用 R/C 寫法(避免 openpyxl A1 解析的歧義)
    ws.cell(21, 5).value = period_str   # E21
    ws.cell(24, 6).value = sa_mwan      # F24 (保額,萬元為單位)
    ws.cell(7, 4).value = sex_str       # D7
    ws.cell(8, 4).value = roc_year      # D8 民國年
    ws.cell(9, 4).value = 8             # D9 月
    ws.cell(10, 4).value = 1            # D10 日
    ws.cell(11, 4).value = age          # D11 年齡(輸入頁有顯示但通常是公式)
    # 要保人也對齊
    ws.cell(7, 10).value = roc_year     # J7
    ws.cell(8, 10).value = 8            # J8
    ws.cell(9, 10).value = 1            # J9
    # 繳費人也對齊(R7C16 - 從 R7-R10 的 3 段結構看,col 16 是繳費人)
    ws.cell(7, 16).value = roc_year
    ws.cell(8, 16).value = 8
    ws.cell(9, 16).value = 1
    
    wb.save(work_path)


def recalc_libreoffice(input_xlsx, out_dir, timeout=180):
    """LibreOffice headless 重算 + 另存。回傳重算後的 .xlsx 路徑"""
    os.makedirs(out_dir, exist_ok=True)
    # 注意: input 必須先是 .xlsx; 如果原檔是 .xls, 先轉
    src_ext = os.path.splitext(input_xlsx)[1].lower()
    if src_ext == '.xls':
        # 直接 convert 進 out_dir,順便重算
        result = subprocess.run(
            ['soffice', '--headless', '--calc', '--convert-to', 'xlsx',
             '--outdir', out_dir, input_xlsx],
            capture_output=True, timeout=timeout
        )
    else:
        # 已經是 xlsx,convert-to xlsx 會在新位置另存(也會重算)
        result = subprocess.run(
            ['soffice', '--headless', '--calc', '--convert-to', 'xlsx',
             '--outdir', out_dir, input_xlsx],
            capture_output=True, timeout=timeout
        )
    if result.returncode != 0:
        raise RuntimeError(f"LibreOffice 失敗: {result.stderr.decode()[:500]}")
    base = os.path.basename(input_xlsx)
    if src_ext == '.xls':
        base = base[:-4] + '.xlsx'
    out_path = os.path.join(out_dir, base)
    if not os.path.exists(out_path):
        raise FileNotFoundError(f"重算未產生: {out_path}")
    return out_path


def extract_truth(xlsx_path, max_year=80):
    """從重算後的 Excel 抽真值。
    
    HOW_TO_VALIDATE.md 寫:
      試算_最可能紅利 sheet
      AB 欄(col 28)= 年度末身故/完全失能保障總和 J
      AC 欄(col 29)= 年度末解約總和 K
      第 2 row 開始是 Y1,B 欄(col 2)是 y
    """
    import openpyxl
    wb = openpyxl.load_workbook(xlsx_path, data_only=True, read_only=True)
    ws = wb['試算_最可能紅利']
    truth = []
    for r in range(2, 2 + max_year + 5):  # 多掃幾 row 容錯
        y = ws.cell(r, 2).value  # B 欄
        if not isinstance(y, (int, float)):
            continue
        y = int(y)
        if y < 1 or y > max_year:
            break
        j_val = ws.cell(r, 28).value  # AB
        k_val = ws.cell(r, 29).value  # AC
        if j_val is None and k_val is None:
            continue
        # #VALUE! 表示已超過商品有效年數(例 35歲+75年=110歲屆滿)
        # 跳出迴圈,不再讀後續 row
        if j_val == '#VALUE!' or k_val == '#VALUE!':
            break
        # 其他非數字情況(罕見),也跳過
        try:
            j_f = float(j_val) if j_val is not None else 0.0
            k_f = float(k_val) if k_val is not None else 0.0
        except (ValueError, TypeError):
            break
        truth.append({
            'y': y,
            'J': j_f,
            'K': k_f,
        })
    return truth


def find_input_page_actual_values(xlsx_path):
    """重算後抽輸入頁的實際 (年齡, 保費) 用來除錯"""
    import openpyxl
    wb = openpyxl.load_workbook(xlsx_path, data_only=True, read_only=True)
    ws = wb['輸入頁']
    return {
        'period_str': ws.cell(21, 5).value,
        'sa_mwan': ws.cell(24, 6).value,
        'sex': ws.cell(7, 4).value,
        'birth_y': ws.cell(8, 4).value,
        'age': ws.cell(11, 4).value,
    }


# === 主比對流程 ===

def validate(excel_path, json_path, plan, period_str, period_int,
             sex, age, sa_mwan, tol=0.5, verbose=False):
    """
    回傳 dict: {
        'plan': str,
        'pass': bool,
        'total_years': int,
        'matched_years': int,
        'max_diff_J': float,
        'max_diff_K': float,
        'fails': [{'y', 'dJ', 'dK', 'engine_J', 'truth_J', 'engine_K', 'truth_K'}],
        'meta_input': dict,
    }
    """
    # 1. 準備工作目錄
    work_dir = f'/tmp/validate_{uuid.uuid4().hex[:8]}'
    os.makedirs(work_dir, exist_ok=True)
    
    # 2. 改 Excel cell
    src_ext = os.path.splitext(excel_path)[1].lower()
    if src_ext == '.xls':
        # .xls 不能直接用 openpyxl 改,要先轉成 .xlsx
        if verbose: print("  [step 1] .xls → .xlsx 中...", end=' ', flush=True)
        t0 = time.time()
        first_xlsx = recalc_libreoffice(excel_path, work_dir)
        if verbose: print(f"{time.time()-t0:.1f}s")
        # 改 cell 在 first_xlsx
        if verbose: print("  [step 2] 改 cell...", end=' ', flush=True)
        t0 = time.time()
        filled_path = first_xlsx[:-5] + '_filled.xlsx'
        fill_excel(first_xlsx, filled_path, plan, period_str, sex, age, sa_mwan)
        if verbose: print(f"{time.time()-t0:.1f}s")
    else:
        if verbose: print("  [step 1] 改 cell...", end=' ', flush=True)
        t0 = time.time()
        filled_path = os.path.join(work_dir, 'filled.xlsx')
        fill_excel(excel_path, filled_path, plan, period_str, sex, age, sa_mwan)
        if verbose: print(f"{time.time()-t0:.1f}s")
    
    # 3. LibreOffice 重算
    if verbose: print("  [step 3] LibreOffice 重算...", end=' ', flush=True)
    t0 = time.time()
    out_dir = os.path.join(work_dir, 'recalc')
    recalc_path = recalc_libreoffice(filled_path, out_dir)
    if verbose: print(f"{time.time()-t0:.1f}s")
    
    # 4. 抽真值
    if verbose: print("  [step 4] 抽真值...", end=' ', flush=True)
    t0 = time.time()
    truth = extract_truth(recalc_path)
    meta_input = find_input_page_actual_values(recalc_path)
    if verbose: print(f"{time.time()-t0:.1f}s, 抽到 {len(truth)} 年")
    
    # 5. 跑 Python 引擎
    if verbose: print("  [step 5] 跑引擎...", end=' ', flush=True)
    t0 = time.time()
    with open(json_path, encoding='utf-8') as f:
        db = json.load(f)
    sum_assured = sa_mwan * 10000
    result = actuarial_calc_taishin(
        db, plan, sex, age, sum_assured, period_int,
        discount=db['meta'].get('discount', 0.01),
        product_meta=db['meta'],
    )
    if verbose: print(f"{time.time()-t0:.1f}s, schedule {len(result['schedule'])} 年")
    
    # 6. 逐年比對
    fails = []
    max_diff_J = 0.0
    max_diff_K = 0.0
    matched = 0
    
    # 按 y 建索引方便 lookup
    sched_by_y = {r['y']: r for r in result['schedule']}
    
    total_years = len(truth)
    for t in truth:
        y = t['y']
        sched = sched_by_y.get(y)
        if not sched:
            fails.append({
                'y': y, 'reason': 'engine 沒有此年',
                'truth_J': t['J'], 'truth_K': t['K'],
            })
            continue
        eng_J = sched['death_total']
        eng_K = sched['surr_total']
        dJ = abs(eng_J - t['J'])
        dK = abs(eng_K - t['K'])
        max_diff_J = max(max_diff_J, dJ)
        max_diff_K = max(max_diff_K, dK)
        if dJ < tol and dK < tol:
            matched += 1
        else:
            fails.append({
                'y': y,
                'engine_J': eng_J, 'truth_J': t['J'], 'dJ': dJ,
                'engine_K': eng_K, 'truth_K': t['K'], 'dK': dK,
            })
    
    return {
        'plan': plan,
        'scenario': f'{age}{sex}/{sa_mwan}萬/{period_int}年期',
        'pass': matched == total_years,
        'total_years': total_years,
        'matched_years': matched,
        'max_diff_J': max_diff_J,
        'max_diff_K': max_diff_K,
        'fails': fails[:10],  # 只保前 10 個 fail 詳情
        'fail_count': len(fails),
        'meta_input': meta_input,
    }


def print_result(r, verbose=False):
    status = '✅ PASS' if r['pass'] else '❌ FAIL'
    print(f"\n{status} {r['plan']} {r['scenario']}")
    print(f"   對齊: {r['matched_years']}/{r['total_years']}  "
          f"max_diff: J={r['max_diff_J']:.4f}, K={r['max_diff_K']:.4f}")
    if not r['pass']:
        print(f"   失敗 {r['fail_count']} 年,差最大的 (top 5):")
        sorted_fails = sorted(r['fails'], key=lambda f: -max(f.get('dJ', 0), f.get('dK', 0)))
        for f in sorted_fails[:5]:
            if 'reason' in f:
                print(f"     Y{f['y']}: {f['reason']}")
            else:
                print(f"     Y{f['y']:>3}: dJ={f['dJ']:>15.2f} (engine={f['engine_J']:.2f}, truth={f['truth_J']:.2f})")
                print(f"            dK={f['dK']:>15.2f} (engine={f['engine_K']:.2f}, truth={f['truth_K']:.2f})")
    if verbose:
        print(f"   Excel 重算後輸入頁: {r['meta_input']}")


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--excel', required=True)
    p.add_argument('--json', required=True)
    p.add_argument('--plan', required=True)
    p.add_argument('--period-str', required=True, help='例: 六年期/UPD061')
    p.add_argument('--period', type=int, required=True)
    p.add_argument('--sex', required=True, choices=['M', 'F'])
    p.add_argument('--age', type=int, required=True)
    p.add_argument('--sa-mwan', type=float, required=True, help='保額(萬元為單位)')
    p.add_argument('--tol', type=float, default=0.5)
    p.add_argument('-v', '--verbose', action='store_true')
    args = p.parse_args()
    
    print(f"=== 驗證 {args.plan} {args.age}{args.sex} {args.sa_mwan}萬 {args.period}年期 ===")
    r = validate(
        args.excel, args.json, args.plan, args.period_str, args.period,
        args.sex, args.age, args.sa_mwan,
        tol=args.tol, verbose=args.verbose
    )
    print_result(r, verbose=args.verbose)
    sys.exit(0 if r['pass'] else 1)


if __name__ == '__main__':
    main()
