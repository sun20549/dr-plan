# 驗證工具 v1.0 — 已完成 + 下一輪你要做什麼

## ✅ 這輪做了什麼

### 1. 把 JS 引擎翻成 Python
`engine_taishin_v1.py` — 從 `engine_taishin_v1.js` 完整翻譯,邏輯 100% 一致。

### 2. 寫了單商品驗證腳本
`validate_one.py` — 吃 1 個 Excel + 1 個 JSON + 1 個情境,完整跑驗證。

### 3. 寫了批次驗證腳本
`validate_batch.py` — 吃多個商品的 manifest,一次跑完輸出 PASS/FAIL 摘要。

### 4. 用 UPD061 跑了 2 個情境驗證

| 情境 | 結果 | 對齊年數 | max_diff (J/K) |
|---|---|---|---|
| UPD061 35M 300萬 6年期 | ✅ PASS | **75/75** | **0.00 / 0.00** |
| UPD061 50F 100萬 6年期 | ✅ PASS | **60/60** | **0.00 / 0.00** |

**完全對齊!不是「< 0.5」,是 0 偏差。** 表示:
- Python 引擎跟 JS 引擎邏輯完全一致
- 修正後的 UPD061 JSON 真的是「對的」

## 📊 性能

每個商品每個情境約 **30 秒**(主要是 LibreOffice 重算 + xlsx 載入):
- step 1: .xls → .xlsx 轉 (~7s,只在第一次跑該商品時需要)
- step 2: 改 cell (~13s,openpyxl 改大檔案有點慢)
- step 3: LibreOffice 重算 (~6s)
- step 4: 抽真值 (~4s)
- step 5: Python 引擎 (~0.2s)

**所以 1 商品 × 1 情境 = 30 秒;2 個情境 = 50 秒(因為第 2 次免轉檔)**

---

## 🎯 下一輪你需要做的事

### Step 1:從 `_manifest.json` 找出所有 `engine == 'taishin_v1'` 的商品

直接搜尋條件:
```
egine: 'taishin_v1'
```

根據前對話交接文件,**taishin_v1 共 3 個商品**(都是新光分紅):
- UPD061(美鴻添富) — 已完成
- UPD012(美鴻世代,1 年躉繳)
- UPD022(美鴻世代,2 年期)

**HOW_TO_VALIDATE.md 提到 UPD012 + UPD022 也已驗證對齊**,所以 **taishin_v1 全 3 個都已驗證 → 修對了 = 不用我再修**。

### Step 2:你下一輪要上傳的東西

**只需要 2 個檔**:

```
UPD012_Excel.xls   ← 美鴻世代 1 年躉繳 的 Excel
UPD022_Excel.xls   ← 美鴻世代 2 年期 的 Excel
```

(JSON 我 manifest 裡找得到,你不用上傳;但如果你有「修正後」版本不在 GitHub repo 裡,要記得帶過來)

### Step 3:我下一輪會做的事

1. 跑 UPD012 / UPD022 各 1 個情境(用 HOW_TO_VALIDATE 寫的標準情境)
2. 確認 PASS → **taishin_v1 全部驗證通過,結案**
3. 接著動手**擴展工具到 twlife_v1**(最大宗,160 個商品)
   - 這部分要你「上傳 1 個你心目中已經對的 twlife_v1 商品 + JSON」當校準範例
   - 我寫 `engine_twlife_v1.py`(從 JS 翻譯)
   - 用該商品驗證 → PASS 後才大規模上 twlife_v1 商品

### Step 4(後續輪)

順序:
1. **twlife_v1**(160 商品,最大宗)
2. **prudential_v2**(51 商品)
3. **kgi_rv_v1**(2 商品)
4. **prudential_v1**(1 商品,最小)

每種引擎需要 **1-2 輪對話** 把工具校準對 + 跑完該引擎所有商品。

**全部 217 商品估計 8-12 輪對話**(分批上傳 + 分類修正)。

---

## 🛠️ 實際命令(讓你心裡有譜)

下一輪你會看到我跑這種命令:

```bash
# Step 1: 把 UPD012 + UPD022 的 Excel/JSON 整理進 manifest
cat > /tmp/taishin_v1_batch.json << EOF
{
  "products": [
    {
      "plan": "UPD012", 
      "excel": "...UPD012_Excel.xls",
      "json": "...UPD012.json",
      "period_str": "一年期/UPD012",  # 一年躉繳
      "period": 1,
      "scenarios": [
        {"sex": "M", "age": 50, "sa_mwan": 100}
      ]
    },
    {
      "plan": "UPD022",
      "excel": "...UPD022_Excel.xls", 
      "json": "...UPD022.json",
      "period_str": "二年期/UPD022",
      "period": 2,
      "scenarios": [
        {"sex": "M", "age": 50, "sa_mwan": 100}
      ]
    }
  ]
}
EOF

# Step 2: 跑批次
python3 validate_batch.py --manifest /tmp/taishin_v1_batch.json
```

如果看到全 PASS:
```
✅ PASS UPD012 50M/100萬/1年期    60/60   max_diff(J/K)=0.00/0.00  (35.2s)
✅ PASS UPD022 50M/100萬/2年期    60/60   max_diff(J/K)=0.00/0.00  (33.8s)
🎉 全部 PASS!
```

→ taishin_v1 結案,進下一個引擎。

---

## 💡 為什麼 taishin_v1 我們很快就完成?

因為**你已經自己把它修對了**!HOW_TO_VALIDATE.md 寫:
- UPD061 35M 300萬 6年期 → 75/75 ✓ ← 我這輪驗了
- UPD061 50F 100萬 6年期 → 60/60 ✓ ← 我這輪驗了
- UPD012 50M 100萬 1年躉繳 → 60/60 ✓ ← 你說已驗
- UPD022 50M 100萬 2年期 → 60/60 ✓ ← 你說已驗
- UPD012 50F 7萬 1年躉繳 → 60/60 ✓ ← 你說已驗

**我只是把你的工作搬到 Python 裡再驗一次。** 真正的功夫從 twlife_v1 才開始。

---

## ⚠️ 給你的提醒

**你下一輪上傳要帶的東西:**

1. **UPD012 的 Excel** + **修正後 JSON**(如果有)
2. **UPD022 的 Excel** + **修正後 JSON**(如果有)
3. **如果 UPD012/UPD022 的 JSON 沒被特別修正過**(預設值),只要 Excel 就好,JSON 我從 manifest 抓
4. **告訴我下一個要驗的引擎是什麼**(建議 twlife_v1 因為最大宗)

**請確認你手上有 UPD012/UPD022 的 Excel 檔。** 如果沒有,我們會卡住。
