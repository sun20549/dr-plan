"""
engine_taishin_v1.py
從 engine_taishin_v1.js 直接翻譯成 Python。
邏輯與 JS 版完全一致(逐行對照),用於後端驗證。

核心:actuarial_calc_taishin(db, plan, sex, age, sumAssured, period, discount, productMeta)

  輸入:
    db (dict)        — 已載入的 JSON,含 gp_table / uv_table / div_table / corridor_polyr / meta
    plan (str)       — plan_code,例 'UPD061'
    sex (str)        — 'M' 或 'F'
    age (int)        — 保險年齡
    sumAssured (num) — 保額(USD,非萬元)
    period (int)     — 繳費年期
    discount (float) — 預設折扣(沒級距時用)
    productMeta      — 產品 meta,有 discount_tiers / has_survival_floor 等欄位

  輸出:
    {
      'gp': ...,
      'sum_assured': ...,
      'annual_premium_orig': ...,
      'annual_premium_real': ...,
      'schedule': [{'y','age','prem','cum_prem','surr_pure','surr_total','death_pure','death_total'}, ...]
    }
"""

def _round_half_up(x, ndigits=0):
    """JS Math.round = banker rounding 在 .5 時往「最近偶數」捨去
    但 JS Math.round(0.5) = 1,Math.round(1.5) = 2(往正無限大方向)
    Python round(0.5) = 0(banker rounding,跟 JS 不一樣)
    所以要用「.5 一律進位」"""
    import math
    if ndigits == 0:
        return math.floor(x + 0.5)
    multi = 10 ** ndigits
    return math.floor(x * multi + 0.5) / multi


def _to_fixed(x, ndigits):
    """JS 的 +x.toFixed(n) 等效"""
    return round(x, ndigits)


def ts_get_gp(db, plan, sex, age):
    return db.get('gp_table', {}).get(plan, {}).get(sex, {}).get(str(age))


def ts_get_uv(db, plan, sex, age, year):
    """回傳 (NFV, CSV, NSP) 或 None"""
    arr = db.get('uv_table', {}).get(f'{plan}|{sex}|{age}')
    if not arr:
        return None
    for row in arr:
        if row[0] == year:
            return {'NFV': row[1], 'CSV': row[2], 'NSP': row[3]}
    return None


def ts_get_div(db, plan, sex, age, year):
    arr = db.get('div_table', {}).get(f'{plan}|{sex}|{age}')
    if not arr:
        return {'AD': 0, 'TD_Death': 0, 'TD_Surr': 0}
    for row in arr:
        if row[0] == year:
            return {'AD': row[1], 'TD_Death': row[2], 'TD_Surr': row[3]}
    return {'AD': 0, 'TD_Death': 0, 'TD_Surr': 0}


def ts_get_max_year(db, plan, sex, age):
    arr = db.get('uv_table', {}).get(f'{plan}|{sex}|{age}')
    if not arr:
        return 0
    return max(r[0] for r in arr)


def resolve_discount(product_meta, annual_premium_gross):
    """級距折扣解析。沒級距 → 用固定 discount。"""
    if not product_meta:
        return 0
    tiers = product_meta.get('discount_tiers')
    if not tiers:
        return product_meta.get('discount', 0)
    # 找最高符合的級距
    sorted_tiers = sorted(tiers, key=lambda t: -t['threshold'])
    for tier in sorted_tiers:
        if annual_premium_gross >= tier['threshold']:
            return tier['rate']
    return product_meta.get('discount', 0)


def actuarial_calc_taishin(db, plan, sex, age, sum_assured, period,
                           discount=0.01, product_meta=None):
    """taishin_v1 引擎。對齊 engine_taishin_v1.js 的 actuarialCalc_taishin"""
    units = sum_assured / 1000
    gp = ts_get_gp(db, plan, sex, age)
    if gp is None:
        return None

    annual_premium_orig = _to_fixed(units * gp, 2)
    # 級距折扣
    if product_meta and product_meta.get('discount_tiers'):
        effective_discount = resolve_discount(product_meta, annual_premium_orig)
    else:
        effective_discount = discount
    annual_premium_real = _round_half_up(annual_premium_orig * (1 - effective_discount))

    # === offset 機制 ===
    meta = db.get('meta', {})
    cum_offset = meta.get('dividend_offset_cum', 1)
    td_offset = meta.get('dividend_offset_td', 1)

    max_y = ts_get_max_year(db, plan, sex, age)

    # === 祝壽金保底 ===
    if meta.get('has_survival_floor') is False:
        survival_nfv = 0
    else:
        u_max = ts_get_uv(db, plan, sex, age, max_y)
        survival_nfv = u_max['NFV'] if u_max else 0
    survival_benefit = units * survival_nfv

    # === criteria_by_age ===
    criteria_by_age = meta.get('criteria_by_age')

    def get_criteria(attained_age):
        if not criteria_by_age:
            return 0
        crit = 0
        for start_age, value in criteria_by_age:
            if attained_age >= start_age:
                crit = value
            else:
                break
        return crit

    # === premium_basis_ratio ===
    premium_basis_ratio = meta.get('premium_basis_ratio', 0)

    # === 主迴圈 ===
    schedule = []
    cum_prem = 0
    cum_inc_face = 0

    for year in range(1, max_y + 1):
        prem = annual_premium_real if year <= period else 0
        cum_prem += prem
        u = ts_get_uv(db, plan, sex, age, year)
        if not u:
            continue

        nfv = units * u['NFV']
        csv = units * u['CSV']
        nsp = u['NSP']
        cor_polyr = db.get('corridor_polyr', {}).get(str(year), 1.0)
        attained_age = age + year - 1
        criteria = get_criteria(attained_age)
        nfv_crit = nfv * criteria
        prem_basis = cum_prem * premium_basis_ratio

        # C 基本身故
        if year >= period:
            death_basic = max(sum_assured * cor_polyr, nfv, nfv_crit, prem_basis, survival_benefit)
        else:
            death_basic = max(sum_assured * cor_polyr, nfv, nfv_crit, prem_basis)

        # cumIncFace
        d_cum = ts_get_div(db, plan, sex, age, year - cum_offset)
        ad_face_year = _to_fixed(units * d_cum['AD'], 2)
        inc_face_year = _round_half_up(ad_face_year / (nsp / 1000)) if nsp > 0 else 0
        cum_inc_face += inc_face_year

        g_inc_surr = _to_fixed(cum_inc_face * nsp / 1000, 2)

        # F 累紅身故
        min_year_period = min(year, period)
        base_gp = ts_get_gp(db, plan, sex, age) or 0
        if premium_basis_ratio > 0:
            u_value = _to_fixed(
                premium_basis_ratio * _round_half_up(base_gp * cum_inc_face / 1000) * min_year_period,
                2
            )
        else:
            u_value = 0
        f_nsp_crit = _to_fixed(cum_inc_face * nsp / 1000 * (criteria if criteria else 1), 2)
        f_cor_p = _round_half_up(cum_inc_face * cor_polyr)
        x_inc_death = max(u_value, f_nsp_crit, f_cor_p)

        # TD
        if td_offset == cum_offset:
            d_td = d_cum
        else:
            d_td = ts_get_div(db, plan, sex, age, year - td_offset)
        td_death = _to_fixed(units * d_td['TD_Death'], 2)
        td_surr = _to_fixed(units * d_td['TD_Surr'], 2)

        schedule.append({
            'y': year,
            'age': age + year - 1,
            'prem': _round_half_up(prem),
            'cum_prem': _round_half_up(cum_prem),
            'surr_pure': _to_fixed(csv, 2),
            'surr_total': _to_fixed(csv + g_inc_surr + td_surr, 2),
            'death_pure': _round_half_up(death_basic),
            'death_total': _to_fixed(death_basic + x_inc_death + td_death, 2),
        })

    return {
        'gp': gp,
        'sum_assured': sum_assured,
        'annual_premium_orig': annual_premium_orig,
        'annual_premium_real': annual_premium_real,
        'schedule': schedule,
        'is_exact': False,
    }
