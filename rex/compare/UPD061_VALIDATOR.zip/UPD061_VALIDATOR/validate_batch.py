"""
validate_batch.py — 批次驗證

用法 1(指定 manifest 檔):
    python3 validate_batch.py --manifest products.json
    
    products.json 格式:
    {
      "products": [
        {
          "plan": "UPD061",
          "excel": "data/UPD061_Excel.xls",
          "json":  "data/UPD061_corrected.json",
          "period_str": "六年期/UPD061",
          "period": 6,
          "scenarios": [
            {"sex": "M", "age": 35, "sa_mwan": 300},
            {"sex": "F", "age": 50, "sa_mwan": 100}
          ]
        }
      ]
    }

用法 2(用 wildcard 自動掃資料夾):
    python3 validate_batch.py --excel-dir data/excels --json-dir data/jsons \
                              --default-scenario M,35,300 \
                              --default-period-str-template "{period}年期/{plan}"

輸出:
    results.json — 完整結果
    summary.txt  — 給人看的摘要
"""
import argparse
import json
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from validate_one import validate, print_result


def run_batch(products):
    """跑一批商品,每個商品跑所有 scenarios。回傳結果列表。"""
    all_results = []
    total_start = time.time()
    
    total_runs = sum(len(p.get('scenarios', [{'sex':'M','age':35,'sa_mwan':100}])) for p in products)
    completed = 0
    
    for prod in products:
        plan = prod['plan']
        excel = prod['excel']
        json_p = prod['json']
        period_str = prod['period_str']
        period = prod['period']
        scenarios = prod.get('scenarios', [{'sex': 'M', 'age': 35, 'sa_mwan': 100}])
        
        print(f"\n[{plan}] 開始驗證 ({len(scenarios)} 個情境)")
        for sc in scenarios:
            completed += 1
            print(f"  [{completed}/{total_runs}] {sc['age']}{sc['sex']}/{sc['sa_mwan']}萬...",
                  end=' ', flush=True)
            t0 = time.time()
            try:
                r = validate(
                    excel, json_p, plan, period_str, period,
                    sc['sex'], sc['age'], sc['sa_mwan'],
                    tol=0.5, verbose=False,
                )
                elapsed = time.time() - t0
                status = '✅' if r['pass'] else '❌'
                print(f"{status} {r['matched_years']}/{r['total_years']}  "
                      f"max_diff(J/K)={r['max_diff_J']:.2f}/{r['max_diff_K']:.2f}  "
                      f"({elapsed:.1f}s)")
                all_results.append(r)
            except Exception as e:
                elapsed = time.time() - t0
                print(f"💥 ERROR: {type(e).__name__}: {str(e)[:100]} ({elapsed:.1f}s)")
                all_results.append({
                    'plan': plan,
                    'scenario': f'{sc["age"]}{sc["sex"]}/{sc["sa_mwan"]}萬/{period}年期',
                    'pass': False,
                    'error': f'{type(e).__name__}: {str(e)}',
                    'fail_count': -1,
                })
    
    total_elapsed = time.time() - total_start
    print(f"\n=== 全部跑完 {total_runs} 個情境,耗時 {total_elapsed:.1f}s "
          f"({total_elapsed/total_runs:.1f}s/情境) ===")
    return all_results


def categorize_failures(results):
    """根據 fail 模式分類,讓對方批次修同類錯誤。"""
    pass_count = sum(1 for r in results if r.get('pass'))
    fail_count = len(results) - pass_count
    
    # 簡單分類:看 J/K 哪個錯、錯多大、哪幾年錯
    categories = {
        'all_K_zero_diff': [],      # K 完全對,但 J 錯 → 通常是 死亡保底邏輯不對
        'all_J_zero_diff': [],      # J 完全對,但 K 錯 → 通常是 紅利索引/解約金邏輯不對
        'both_diff': [],            # 都錯 → 可能 meta 有問題
        'engine_error': [],         # 引擎異常
    }
    
    for r in results:
        if r.get('pass'):
            continue
        if 'error' in r:
            categories['engine_error'].append(r)
            continue
        if r.get('max_diff_K', 0) < 0.5 and r.get('max_diff_J', 0) >= 0.5:
            categories['all_K_zero_diff'].append(r)
        elif r.get('max_diff_J', 0) < 0.5 and r.get('max_diff_K', 0) >= 0.5:
            categories['all_J_zero_diff'].append(r)
        else:
            categories['both_diff'].append(r)
    
    return categories, pass_count, fail_count


def print_summary(results, categories, pass_count, fail_count):
    print("\n" + "=" * 70)
    print(f"📊 批次驗證總結")
    print("=" * 70)
    print(f"PASS: {pass_count} / {len(results)}")
    print(f"FAIL: {fail_count} / {len(results)}")
    
    if fail_count == 0:
        print("\n🎉 全部 PASS!")
        return
    
    print(f"\n失敗分類:")
    print(f"  K 完全對但 J 錯 (死亡保底邏輯問題): {len(categories['all_K_zero_diff'])}")
    print(f"  J 完全對但 K 錯 (解約金/紅利問題):   {len(categories['all_J_zero_diff'])}")
    print(f"  J 跟 K 都錯:                         {len(categories['both_diff'])}")
    print(f"  引擎異常:                             {len(categories['engine_error'])}")
    
    # 列出失敗詳情
    print("\n--- 失敗詳情 ---")
    for cat_name, items in categories.items():
        if not items:
            continue
        print(f"\n[{cat_name}] {len(items)} 個:")
        for r in items[:20]:  # 最多列 20
            if 'error' in r:
                print(f"  {r['plan']:<10} {r.get('scenario','?'):<20} ERROR: {r['error'][:60]}")
            else:
                print(f"  {r['plan']:<10} {r.get('scenario','?'):<20} "
                      f"{r['matched_years']}/{r['total_years']}  "
                      f"max_diff(J/K)={r.get('max_diff_J',0):.2f}/{r.get('max_diff_K',0):.2f}")


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--manifest', help='products.json 路徑')
    p.add_argument('--out-json', default='/tmp/validate_results.json')
    p.add_argument('--out-summary', default='/tmp/validate_summary.txt')
    args = p.parse_args()
    
    if not args.manifest:
        print("錯誤: 必須指定 --manifest")
        sys.exit(1)
    
    with open(args.manifest, encoding='utf-8') as f:
        manifest = json.load(f)
    products = manifest['products']
    
    print(f"載入 {len(products)} 個商品")
    
    results = run_batch(products)
    categories, pass_c, fail_c = categorize_failures(results)
    print_summary(results, categories, pass_c, fail_c)
    
    # 存結果
    with open(args.out_json, 'w', encoding='utf-8') as f:
        json.dump({
            'results': results,
            'summary': {
                'total': len(results),
                'pass': pass_c,
                'fail': fail_c,
            },
        }, f, ensure_ascii=False, indent=2, default=str)
    print(f"\n📁 完整結果: {args.out_json}")


if __name__ == '__main__':
    main()
