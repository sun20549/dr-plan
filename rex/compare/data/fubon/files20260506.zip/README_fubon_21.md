# 富邦人壽 21 商品 JSON 包

打包日期:2026-05-06
轉換流程:excel_to_json_轉換指令_v2_1.md

## 包含商品(21 檔)

| 代號 | 商品名 | 引擎 | 幣別 | 年期 |
|---|---|---|---|---|
| FBM | 順順美利外幣利率變動型終身壽險 | twlife_v1 | USD | 6年 |
| PFA | 美富紅運外幣分紅終身壽險 | prudential_v2 | USD | 3年 |
| FBP | 美好利外幣利率變動型增額終身壽險 | twlife_v1 | USD | 6年 |
| FAZ | 美利大心外幣利率變動型終身壽險 | twlife_v1 | USD | 6年 |
| FBO | 美利大運外幣利率變動型終身壽險 | twlife_v1 | USD | 2年 |
| PAN | 享滿富分紅終身保險 | prudential_v2 | TWD | 20年 |
| IBP | 吉利好運外幣利率變動型終身壽險 | twlife_v1 | USD | 7年 |
| IAP | 吉鑽利外幣利率變動型終身壽險 | twlife_v1 | USD | 6年 |
| PFG | 星美富足分紅終身壽險 | prudential_v2 | TWD | 1年 |
| PAK | 月月紅富分紅終身壽險 | prudential_v2 | TWD | 2年 |
| PALA_B_C | 活利優退分紅終身壽險 | prudential_v2 | TWD | 6年 |
| PAP | 紅富年年外幣分紅終身壽險 | prudential_v2 | USD | 2年 |
| PFD | 紅富美好外幣分紅終身壽險 | prudential_v2 | USD | 10年 |
| PAC | 紅旺年年分紅終身壽險 | prudential_v2 | USD | 6年 |
| PFNA_B_C | 紅運優外幣分紅終身壽險 | prudential_v2 | USD | 20年 |
| PAG | 紅運多多分紅終身壽險 | prudential_v2 | USD | 3年 |
| PAE | 紅運年代分紅終身壽險 | prudential_v2 | USD | 10年 |
| PFI | 紅運滿滿外幣分紅終身壽險 | prudential_v2 | TWD | 10年 |
| PAF | 紅運長樂分紅終身壽險 | prudential_v2 | TWD | 20年 |
| FCG | 金好美滿外幣終身保險 | twlife_v1 | USD | 2年 |
| FCF | 金盈美滿外幣增額終身壽險 | twlife_v1 | USD | 1年 |

## 跳過的商品(不轉,3 檔)

| 代號 | 商品名 | 原因 |
|---|---|---|
| UND | 年年吉祥變額萬能壽險 | 變額萬能壽險,引擎不支援投資型 |
| UOP | 金富裕變額壽險 | 變額壽險,引擎不支援投資型 |
| FDC | 美好安心外幣重大傷病保險 | 重大傷病險,引擎不支援 |

## 部署步驟

### 1. 把 21 個 JSON 放進 fubon 子目錄
```
mkdir -p rex/compare/data/fubon/
cp *.json rex/compare/data/fubon/
```

### 2. 更新 _manifest.json
把 `_manifest_fragment.json` 裡的 21 條 entry 加進現有 `_manifest.json`

### 3. 更新 index_slim.html PRODUCTS 註冊表
把 `_products_fragment.js` 裡的 21 個物件加進現有 PRODUCTS 陣列

## ⚠️ 部署前必校對的事項

1. **min_sa / max_sa / max_age 用了預設值**:
   - USD 商品:min_sa=10000, max_sa=5000000
   - TWD 商品:min_sa=300000, max_sa=100000000
   - max_age:75
   - **真實限額要查商品 DM 投保規則章節校對**

2. **mid_dividend_rate 用業界預設**(分紅型 14 檔):
   - USD:5.50%
   - TWD:4.50%
   - **務必校對 DM 中分紅情境假設投資報酬率,前端顯示用**

3. **特殊商品事項提醒**(下游引擎):
   - **FBM(順順美利)**:Y1-Y5 基本保額為 base_sa 的 10/20/30/40/50%,Y6 起 100%
   - **FBP(美好利)**:增額終身壽,基本保額逐年遞增至 Y110 達 7.3× base_sa
   - **PFA(美富紅運)**:0 歲投保 + 三情境分紅
   - **PALA_B_C(活利優退)**:Y65 後進入領回階段,cv_total 會逐年遞減
   - **PFG(星美富足)**:躉繳(period=1)
   - **PFD(紅富美好)**:只有 85 筆 schedule(切到滿期 110 歲)

## 子分類統計

- 引擎分布:twlife_v1 8 檔, prudential_v2 13 檔
- 幣別分布:USD 15 檔, TWD 6 檔