# 新光人壽 5 商品 JSON 包

## 內含檔案

- **TBA.json** — 美好人生（2 年期，定期給付型，base_sa 1,998,000 USD）
- **P2A.json** — 美利多倍（8 年期，stepped，base_sa 174,000 USD）
- **WZA.json** — 美鑽長青（6 年期，stepped，base_sa 1,000,000 USD）
- **P3A.json** — 美鑽傳世（6 年期，stepped，半年繳，base_sa 3,086,444 USD）
- **JZA.json** — 美鑽傳家（5 年期，stepped，base_sa 10,000 USD）
- **_manifest_entries.json** — 5 條 manifest 條目，直接 append 到你的 _manifest.json
- **PRODUCTS_snippet.js** — index_slim.html PRODUCTS 註冊表片段
- **README.md** — 本檔

## 部署步驟

### 1. JSON 檔放置
建議目錄結構：`rex/compare/data/skl/<plan_code>.json`

```
rex/compare/data/skl/TBA.json
rex/compare/data/skl/P2A.json
rex/compare/data/skl/WZA.json
rex/compare/data/skl/P3A.json
rex/compare/data/skl/JZA.json
```

### 2. 更新 `_manifest.json`
打開 `_manifest_entries.json`，把 5 條 append 到既有 `_manifest.json` 的陣列。

### 3. 更新 `index_slim.html`
打開 `PRODUCTS_snippet.js`，把 5 個物件 append 到 PRODUCTS 註冊表。

## 重要技術備註

### 引擎選擇
全部用 `twlife_v1`。指令文件原本標示「新光分紅型 taishin_v1 不支援」，但這 5 檔是**利率變動型（非分紅）**，可套用 twlife_v1 schema 並通過驗證。

### db_pattern: "stepped"
P2A / WZA / P3A / JZA 都標記為 stepped，意思是 **Y1 死亡保險金不等於 base_sa**，會逐年累進，到 period 末才達標：

| 商品 | 達 base_sa 年度 |
|---|---|
| TBA | Y1 |
| P2A | Y3 |
| WZA | Y6 |
| P3A | Y7 |
| JZA | Y5 |

⚠️ 前端如果用 db 反推保額（例如「預算反推保額」功能），**對 stepped 商品不能用 Y1 的 db**，要用 period+1 後的 db 或 base_sa 直接讀 meta。

### P3A 半年繳特殊處理
P3A meta 有 `premium_mode: "half_year"`。`base_premium = 110,934`（年繳概念，半年繳 55,467 × 2）。前端如要顯示「期繳金額」需自行除 2。

### TBA 抵繳保費差異
TBA Y2 cum_prem = 520,918.48 ≠ base_premium × 2 = 525,554，差 4,635.52 是 Y2 用增加回饋金抵繳保費。這是 Excel 顯示「保戶實際繳出」的金額。前端使用時 cum_prem 直接讀即可。

### dividend_cum 線性插值
dividend_cum 採用簡易版 sheet 的「累計增加回饋金利益分析」欄位，連續年度為 Excel 原值，跳號年度（如 Y26-Y29、Y31-Y34）為相鄰兩點線性插值。所有商品的 cv_total cross-check 100% 通過（與 Excel 簡易版「年度末解約總領金額」逐筆零差異）。

### 投保限額（min_sa / max_sa / max_age）
| 商品 | min_sa | max_sa | max_age |
|---|---|---|---|
| TBA | 10,000 | 3,000,000 | 78 |
| P2A | 10,000 | 7,500,000 | 72 |
| WZA | 10,000 | 7,500,000 | 74 |
| P3A | 10,000 | 5,000,000 | 74 |
| JZA | 10,000 | 5,000,000 | 75 |

注意 max_sa 不一致（300萬 / 500萬 / 750萬 三種），不要互抄。

## 驗證結果

| 商品 | 通用檢查 | 額外驗證 | warning |
|---|---|---|---|
| TBA | 7/8 ✅ | — | 1 (Y2 cum_prem 抵繳差異) |
| P2A | 8/8 ✅ | — | 1 (Y8 cum_prem 抵繳差異) |
| WZA | 8/8 ✅ | — | 0 |
| P3A | 8/8 ✅ | — | 0 |
| JZA | 8/8 ✅ | — | 0 |

驗證規則第 6 項從原本「Y1 db ≈ base_sa」放寬為「**任一年 db 達 base_sa**」，因應 stepped 商品。

## 原始檔對應

- TBA → `新光人壽美好人生外幣利率變動型終身壽險_定期給付型__TBA_20251126-試算表20251127.xls`
- P2A → `新光人壽美利多倍外幣利率變動型終身壽險_定期給付型__P2A_20251110-試算表20251207.xls`
- WZA → `新光人壽美鑽長青外幣利率變動型終身壽險_定期給付型__WZA_20250915-試算表20251010.xls`
- P3A → `新光人壽美鑽傳世外幣利率變動型終身壽險_P3A_20251120-試算表20251207.xls`
- JZA → `新光人壽美鑽傳家外幣利率變動型終身壽險_定期給付型__JZA_20251120-試算表20251125.xls`
