# 台灣人壽 — 今日交付整合清單(batch4 + batch5,共 6 個商品)

**日期**:2026-05-06
**規格**:v4 萬用整合版
**目錄**:`rex/compare/data/twlife/`(跟前 3 批同目錄)

---

## 📁 6 個 JSON 一覽

```
rex/compare/data/twlife/
├── 澳利樂.json       ⭐ AUD 第一個澳幣商品!養老 7 期
├── 傳承富足.json     TWD 利變,7 期繳
├── 美年有鑫.json     USD 利變,4 期繳(98 筆 schedule)
├── 美紅勝利.json     ⭐ USD 分紅 stepped + sa_decay,躉繳
├── 美紅鑽.json       ⭐ USD 分紅還本 sa_decay,2 期繳,儲存生息
└── 美鑫樂退.json     USD 利變還本,3 期繳(Y4 起生存金)
```

---

## 1. `_manifest.json` 要新增的 6 條

```json
{
  "key": "澳利樂",
  "company": "台灣人壽",
  "plan_code": "澳利樂",
  "product_name": "澳利樂澳幣利率變動型養老保險",
  "currency": "AUD",
  "period": 1,
  "engine": "twlife_v1",
  "product_code": "澳利樂",
  "path": "twlife/澳利樂.json"
},
{
  "key": "傳承富足",
  "company": "台灣人壽",
  "plan_code": "傳承富足",
  "product_name": "傳承富足利率變動型終身壽險",
  "currency": "TWD",
  "period": 7,
  "engine": "twlife_v1",
  "product_code": "傳承富足",
  "path": "twlife/傳承富足.json"
},
{
  "key": "美年有鑫",
  "company": "台灣人壽",
  "plan_code": "美年有鑫",
  "product_name": "美年有鑫美元利率變動型還本終身保險",
  "currency": "USD",
  "period": 4,
  "engine": "twlife_v1",
  "product_code": "美年有鑫",
  "path": "twlife/美年有鑫.json"
},
{
  "key": "美紅勝利",
  "company": "台灣人壽",
  "plan_code": "美紅勝利",
  "product_name": "美紅勝利美元分紅終身壽險",
  "currency": "USD",
  "period": 1,
  "engine": "prudential_v2",
  "product_code": "美紅勝利",
  "path": "twlife/美紅勝利.json"
},
{
  "key": "美紅鑽",
  "company": "台灣人壽",
  "plan_code": "美紅鑽",
  "product_name": "美紅鑽美元分紅終身還本保險",
  "currency": "USD",
  "period": 2,
  "engine": "prudential_v2",
  "product_code": "美紅鑽",
  "path": "twlife/美紅鑽.json"
},
{
  "key": "美鑫樂退",
  "company": "台灣人壽",
  "plan_code": "美鑫樂退",
  "product_name": "美鑫樂退美元利率變動型還本終身保險",
  "currency": "USD",
  "period": 3,
  "engine": "twlife_v1",
  "product_code": "美鑫樂退",
  "path": "twlife/美鑫樂退.json"
}
```

---

## 2. `index_slim.html` PRODUCTS 註冊表要新增的 6 條

```js
{
  plan_code: '澳利樂',
  company: '台灣人壽',
  product_name: '澳利樂澳幣利率變動型養老保險',
  period: 1,
  currency: 'AUD',
  type: '澳幣利率變動型養老保險',
  declared_rate: 0.042,
  predicted_rate: 0,
  discount: 0,
  discount_method: 'simple',
  engine: 'twlife_v1',
  unit_size: 10000,
  min_sa: 5000,
  max_sa: 8000000,
  min_age: 0,
  max_age: 85
},
{
  plan_code: '傳承富足',
  company: '台灣人壽',
  product_name: '傳承富足利率變動型終身壽險',
  period: 7,
  currency: 'TWD',
  type: '新台幣利率變動型終身壽險',
  declared_rate: 0.023,
  predicted_rate: 0,
  discount: 0,
  discount_method: 'simple',
  engine: 'twlife_v1',
  unit_size: 1000,
  min_sa: 400000,
  max_sa: 100000000,
  min_age: 0,
  max_age: 73
},
{
  plan_code: '美年有鑫',
  company: '台灣人壽',
  product_name: '美年有鑫美元利率變動型還本終身保險',
  period: 4,
  currency: 'USD',
  type: '美元利率變動型還本終身壽險',
  declared_rate: 0.042,
  predicted_rate: 0,
  discount: 0.02,
  discount_method: 'simple',
  engine: 'twlife_v1',
  unit_size: 1000,
  min_sa: 3000,
  max_sa: 2000000,
  min_age: 0,
  max_age: 76
},
{
  plan_code: '美紅勝利',
  company: '台灣人壽',
  product_name: '美紅勝利美元分紅終身壽險',
  period: 1,
  currency: 'USD',
  type: '美元分紅終身壽險',
  declared_rate: 0,
  predicted_rate: 0,
  discount: 0.015,
  discount_method: 'simple',
  engine: 'prudential_v2',
  mid_dividend_rate: 0.055,
  unit_size: 1000,
  min_sa: 10000,
  max_sa: 5000000,
  min_age: 0,
  max_age: 80
},
{
  plan_code: '美紅鑽',
  company: '台灣人壽',
  product_name: '美紅鑽美元分紅終身還本保險',
  period: 2,
  currency: 'USD',
  type: '美元分紅還本終身壽險',
  declared_rate: 0,
  predicted_rate: 0,
  discount: 0.025,
  discount_method: 'simple',
  engine: 'prudential_v2',
  mid_dividend_rate: 0.055,
  unit_size: 1000,
  min_sa: 3000,
  max_sa: 2000000,
  min_age: 0,
  max_age: 78
},
{
  plan_code: '美鑫樂退',
  company: '台灣人壽',
  product_name: '美鑫樂退美元利率變動型還本終身保險',
  period: 3,
  currency: 'USD',
  type: '美元利率變動型還本終身壽險',
  declared_rate: 0.042,
  predicted_rate: 0,
  discount: 0.03,
  discount_method: 'simple',
  engine: 'twlife_v1',
  unit_size: 1000,
  min_sa: 3000,
  max_sa: 2000000,
  min_age: 0,
  max_age: 76
}
```

---

## 3. 自洽性驗證總表

| plan_code | engine | schedule | base | period | 狀態 |
|---|---|---|---|---|---|
| 澳利樂 | twlife_v1 | 7 | AUD M41/300k | 1 | ✅(養老放寬) |
| 傳承富足 | twlife_v1 | 70 | TWD M41/22.5M | 7 | ✅ |
| 美年有鑫 | twlife_v1 | 98 | USD M2/350k | 4 | ✅ |
| 美紅勝利 | prudential_v2 | 25 | USD M41/295k | 1 | ✅(stepped+decay) |
| 美紅鑽 | prudential_v2 | 30 | USD M51/65k | 2 | ✅(decay+還本) |
| 美鑫樂退 | twlife_v1 | 55 | USD M41/350k | 3 | ✅(還本) |

---

## 4. v4 規格新欄位使用情況

| 欄位 | 使用商品 |
|---|---|
| `product_type: endowment` | 澳利樂 |
| `premium_mode: lump_sum` | 澳利樂、美紅勝利 |
| `protection_period: 7` | 澳利樂 |
| `is_endowment: true` | 美鑫樂退、美紅鑽 |
| `survival_benefit_age` | 美鑫樂退(44)、美紅鑽(51) |
| `survival_payout_type: yearly` | 美鑫樂退、美紅鑽 |
| `db_pattern: stepped` | 美紅勝利 |
| `sa_decay: true` | 美紅勝利、美紅鑽 |
| `dividend_option: 儲存生息` | 美紅鑽 |
| `guaranteed_rate` | 美年有鑫(2.25%)、美紅勝利、美紅鑽、美鑫樂退 |

---

## 5. 上線部署步驟(給工程師)

1. **解壓 zip**:把 `twlife/` 資料夾下 6 個 JSON 拖到 `rex/compare/data/twlife/`
2. **編輯 manifest**:把上面 6 條 JSON entry 加入 `_manifest.json`(注意 JSON array 逗號)
3. **編輯 PRODUCTS**:把上面 6 條 JS 物件加入 `index_slim.html` 的 PRODUCTS 陣列
4. **commit + push** 到 GitHub
5. **驗證**:STEP1 篩選找得到、STEP2 預算反推不會卡死、STEP3 比較表正常顯示

---

## 6. ⚠️ 待校對

- **澳利樂** `max_sa: 8000000`:Excel 寫「澳幣 5,000~50/800 萬」,15 歲以上 800 萬,請以 DM 為準
- **傳承富足** discount=0:R28/R29 全 -----,試算表沒給折扣後保費,直接用 Y1 cum_prem。實際可能有 1-3% 折扣
- **美年有鑫** `base_premium_gross: 277,632`:gross 是 net/0.98 反推,實際可能有 ±1 美元誤差
- **美紅勝利 / 美紅鑽** `mid_dividend_rate: 0.055`:從 Excel R10/R14「中分紅5.5%」標題抽,可信
- **美鑫樂退** `discount: 0.03`:gross 466,340 → net 452,350 推算的(高保費 1% + 自匯 1% + 自轉 1%)
