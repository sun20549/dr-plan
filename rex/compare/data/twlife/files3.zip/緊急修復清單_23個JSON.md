# 🚨 台壽 23 個 JSON 緊急補檔包

**問題**:你 GitHub repo 的 `rex/compare/data/twlife/` 缺 16-17 個 JSON 檔(顯示 404),導致前端讀檔失敗。

**原因**:OneDrive 同步問題或誤刪,batch3 的 17 個 JSON 沒推上去。

**修復**:這個 zip 包含全部 23 個 JSON(batch3 + batch4 + batch5),直接覆蓋 `rex/compare/data/twlife/` 即可。

---

## 📦 23 個 JSON 一覽

### 來自 batch3 (17 個 - 你失敗列表的 16 個 + 四海飛揚)
- 保利美.json
- 吉享紅.json
- 吉美富.json
- 吉美得.json
- **四海飛揚.json** ⭐ (CNY 人民幣,如 manifest 沒這條 entry 請補)
- 多享利.json
- 年年添利.json
- 旺美勝.json
- 珍多寶.json
- 紅利旺.json
- 美月有鑫.json
- 美紅旺_v5.json
- 金多利.json
- 金多沛.json
- 金得利.json
- 金滿利.json
- 金福利.json

### 來自 batch4 (5 個 - 今天上午)
- 澳利樂.json (AUD ⭐)
- 傳承富足.json
- 美紅勝利.json
- 美紅鑽.json
- 美鑫樂退.json

### 來自 batch5 (1 個 - 今天下午)
- 美年有鑫.json

---

## 🚀 部署步驟

### 1. 解壓 zip
取出 `twlife/` 資料夾。

### 2. 全部覆蓋
把 23 個 JSON 全部複製到:
```
rex/compare/data/twlife/
```
**直接覆蓋現有檔案**(若有同名)。

### 3. Git push 確認
```bash
cd <你的 repo>
git add rex/compare/data/twlife/
git status                     # 確認 23 個檔都在 staged
git commit -m "fix: 補上缺失的 23 個台壽 JSON"
git push origin main           # 或 master
```

### 4. GitHub 上驗證
開瀏覽器到 GitHub repo → `rex/compare/data/twlife/` 目錄,**用眼睛數**:
- 應該有 30 個 .json 檔案(7 NUIW/NUPW + 7 batch2 + 17 batch3 + 5 batch4 + 1 batch5 - 重複舊版)

或用命令:
```bash
ls rex/compare/data/twlife/*.json | wc -l
```

### 5. 重新整理前端網頁
強制重新整理(Ctrl+Shift+R 清快取),失敗列表應該全部消失。

---

## ⚠️ 若 manifest 還缺「四海飛揚」 entry

打開 `_manifest.json`,搜尋 `四海飛揚`,**沒找到**就把這條加進去:

```json
{
  "key": "四海飛揚",
  "company": "台灣人壽",
  "plan_code": "四海飛揚",
  "product_name": "四海飛揚人民幣利率變動型終身壽險",
  "currency": "CNY",
  "period": 4,
  "engine": "twlife_v1",
  "product_code": "四海飛揚",
  "path": "twlife/四海飛揚.json"
}
```

對應 PRODUCTS 註冊也要有(在 `index_slim.html`):
```js
{
  plan_code: '四海飛揚',
  company: '台灣人壽',
  product_name: '四海飛揚人民幣利率變動型終身壽險',
  period: 4,
  currency: 'CNY',
  type: '人民幣利率變動型終身壽險',
  declared_rate: 0.022,
  predicted_rate: 0,
  discount: 0.02,
  discount_method: 'simple',
  engine: 'twlife_v1',
  unit_size: 1000,
  min_sa: 10000,
  max_sa: 5000000,
  min_age: 0,
  max_age: 70
},
```

---

## 🔍 如何避免下次再發生

1. **不要只仰賴 OneDrive 同步** — Git push 後到 GitHub 網站親眼確認檔案在
2. **commit 前先 `git status`** — 看清楚哪些檔被 stage 了
3. **批次部署時打開 GitHub 網頁直接拖檔** — 比 Git CLI 不容易漏(對小檔案 OK)
4. **每批部署完寫一份清單** — 方便日後對帳(本對話的 batch3/4/5 整合清單可保留)
